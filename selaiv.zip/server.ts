import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, ThinkingLevel } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini client with standard user agent header for telemetry
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || "dummy-key-for-compilation",
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// API chat route for Gemini AI assistant
app.post("/api/chat", async (req, res) => {
  try {
    const { message, history, userContext, cartContext, ordersContext, productsContext } = req.body;
    
    if (!process.env.GEMINI_API_KEY) {
      return res.json({ 
        text: "Hi there! I'm Dipa, the Selai Ghor AI Assistant. Please configure the `GEMINI_API_KEY` in the secrets settings panel to enable my smart replies! In the meantime, feel free to ask me anything about our premium hand-stitched creations."
      });
    }

    let customerInfoPrompt = "\n\n--- CURRENT VISITOR / CUSTOMER DETAILS ---\nThe user is currently browsing as a Guest (not logged in). Politely advise them to log in if they ask about their personal order history, account profile, or want to submit a custom order.";
    if (userContext) {
      customerInfoPrompt = `\n\n--- CURRENT VISITOR / CUSTOMER DETAILS ---
The user is logged in. Use their name and greet them warmly if appropriate.
- Customer Name: ${userContext.fullName}
- Email: ${userContext.email}
- Phone Number: ${userContext.phoneNumber}
- Saved Shipping Address: ${userContext.address}`;
    }

    let cartInfoPrompt = "\n\n--- CUSTOMER ACTIVE SHOPPING CART ---\nThe user's shopping cart is currently empty.";
    if (cartContext && cartContext.length > 0) {
      const itemsStr = cartContext.map((c: any) => `- ${c.productName} (${c.color}) x ${c.quantity} - price: ₹${c.price} each`).join('\n');
      cartInfoPrompt = `\n\n--- CUSTOMER ACTIVE SHOPPING CART ---
The user's shopping cart contains the following items:
${itemsStr}`;
    }

    let ordersInfoPrompt = "\n\n--- CUSTOMER ORDER HISTORY ---\nThe user has not placed any orders yet.";
    if (ordersContext && ordersContext.length > 0) {
      const ordersStr = ordersContext.map((o: any) => `- Order ID: ${o.orderId} (Placed on: ${o.date})
  Status: ${o.status}
  Total: ₹${o.total}
  Tracking Code: ${o.trackingNumber}
  Items purchased: ${o.items.join(', ')}`).join('\n');
      ordersInfoPrompt = `\n\n--- CUSTOMER ORDER HISTORY ---
The user has placed the following previous orders:
${ordersStr}`;
    }

    let catalogInfoPrompt = "";
    if (productsContext && productsContext.length > 0) {
      const catalogStr = productsContext.map((p: any) => `- Name: "${p.name}" | ID: ${p.id} | Category: ${p.category} | Current Price: ₹${p.discountPrice || p.price}${p.discountPrice ? ` (Original Price: ₹${p.price})` : ''} | Stock Status: ${p.availability === 'Pre-order' ? 'Pre-order / Craft on demand' : 'In stock'}`).join('\n');
      catalogInfoPrompt = `\n\n--- CURRENT LIVE PRODUCTS CATALOG ---
Use this catalog to suggest exact matching products if they browse or inquire about what we sell:
${catalogStr}`;
    }

    const systemInstruction = `You are "Dipa", the friendly, expert AI Assistant for "Selai Ghor" (which means 'Sewing Room' in Bengali).
Selai Ghor is an elite handmade boutique specializing in hand-knit, premium crochet, wool, and yarn products.
Your tone should be warm, helpful, polite, and enthusiastic about handmade crafts and yarn work.
You can communicate in English, Bengali, or a mix of both (Banglish), matching the customer's language preference.

Key information about Salai Ghor:
1. Product categories: Crochet Handbags, Woolen Sweaters, Balaclavas, Handmade Toys/Amigurumi, Custom Portrait Dolls, and Winter Mufflers.
2. Materials: 100% premium quality milk cotton yarn, soft merino wool, and organic materials. Hand-knit with precision and love.
3. Custom Orders: Customers can request custom designs through the "Custom Order" tab. They can describe their designs, sizes, and colors, and we contact them on WhatsApp to confirm details. Note: placing a custom order requires the user to log in first.
4. Delivery details: We ship in-stock products in 1-2 days. Free delivery for orders above ₹1000. Under ₹1000, shipping is a flat ₹60 inside West Bengal, or ₹100 for rest of India. Delivery is through reliable courier services with live tracking numbers.
5. WhatsApp integration: All orders are finalized and confirmed over WhatsApp.${customerInfoPrompt}${cartInfoPrompt}${ordersInfoPrompt}${catalogInfoPrompt}

Navigation Support:
You can dynamically navigate the user to different areas of the website depending on their intent! To trigger an automatic redirect, append the appropriate tag EXACTLY at the end of your message:
- To take the user to the Shop / product listings: append "[NAVIGATE:shop]"
- To take the user to Custom Order requests: append "[NAVIGATE:custom-order]"
- To take the user to their Shopping Cart: append "[NAVIGATE:cart]"
- To take the user to their My Account (orders, address, tracking, wishlist): append "[NAVIGATE:account]"
- To take the user to the About & Contact page: append "[NAVIGATE:about-us]"
- To take the user back to the Home page: append "[NAVIGATE:home]"

Strict Constraint: Under no circumstances should you trigger or mention navigation to the Admin Panel. You are forbidden from appending "[NAVIGATE:admin]".

Keep your answers extremely concise, neat, beautifully formatted with markdown, and direct (normally 1-2 paragraphs max, under 3-4 sentences where possible) so they look great in a chat bubble and load extremely quickly. Avoid unnecessary filler or overly long greetings.`;

    const contents = [];
    if (history && Array.isArray(history)) {
      for (const h of history) {
        contents.push({
          role: h.role === "user" ? "user" : "model",
          parts: [{ text: h.text }]
        });
      }
    }
    contents.push({ role: "user", parts: [{ text: message }] });

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        systemInstruction,
        temperature: 0.7
      }
    });

    res.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini API Error:", error);
    res.status(500).json({ error: error.message || "Something went wrong" });
  }
});

// In-memory/file-based cache for Google Sheets config to enable seamless sync for all users
let sheetsConfig = {
  spreadsheetId: "",
  accessToken: ""
};

const CONFIG_FILE = path.join(process.cwd(), "sheets-config.json");
try {
  if (fs.existsSync(CONFIG_FILE)) {
    sheetsConfig = JSON.parse(fs.readFileSync(CONFIG_FILE, "utf-8"));
  }
} catch (err) {
  console.error("Error loading sheets-config.json:", err);
}

// Get Google Sheets configuration status safely
app.get("/api/sheets/config", (req, res) => {
  res.json({
    spreadsheetId: sheetsConfig.spreadsheetId,
    hasToken: !!sheetsConfig.accessToken
  });
});

// Update Google Sheets configuration
app.post("/api/sheets/config", (req, res) => {
  try {
    const { spreadsheetId, accessToken } = req.body;
    if (spreadsheetId !== undefined) sheetsConfig.spreadsheetId = spreadsheetId;
    if (accessToken !== undefined) sheetsConfig.accessToken = accessToken;

    fs.writeFileSync(CONFIG_FILE, JSON.stringify(sheetsConfig, null, 2), "utf-8");
    res.json({ success: true, spreadsheetId: sheetsConfig.spreadsheetId });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// Proxy route to append order to Google Sheets
app.post("/api/sheets/append", async (req, res) => {
  try {
    const { order } = req.body;
    const { spreadsheetId, accessToken } = sheetsConfig;

    if (!spreadsheetId || !accessToken) {
      return res.json({
        success: false,
        error: "not_configured",
        message: "Google Sheets integration is not configured or authenticated by Admin."
      });
    }

    const productDetails = order.items.map((item: any) => `${item.product.name} (${item.selectedColor}) x${item.quantity}`).join(', ');
    
    const rowData = [
      order.id,
      order.orderDate,
      order.address.fullName,
      order.address.phoneNumber,
      order.userEmail || 'Guest / Unregistered',
      order.address.fullAddress,
      order.address.landmark || '',
      `${order.address.district}, ${order.address.state}`,
      order.address.pinCode,
      productDetails,
      order.totalPrice,
      order.deliveryCharge,
      order.discountApplied,
      order.grandTotal,
      order.paymentMethod,
      order.status,
      order.trackingNumber || ''
    ];

    // 1. Fetch spreadsheet metadata to check which sheet/tab titles exist
    console.log(`Checking sheet tabs for Spreadsheet ID: ${spreadsheetId}...`);
    const sheetInfoResponse = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties.title`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      }
    });

    if (!sheetInfoResponse.ok) {
      const errBody = await sheetInfoResponse.json().catch(() => ({}));
      console.warn("Failed to fetch spreadsheet details from Google Sheets:", errBody);
      const errMsg = errBody.error?.message || `HTTP ${sheetInfoResponse.status}`;
      
      const isAuthError = sheetInfoResponse.status === 401 || sheetInfoResponse.status === 403 || (errBody.error?.status === "UNAUTHENTICATED");
      return res.json({
        success: false,
        error: isAuthError ? "auth_expired" : "connection_error",
        message: `Google Sheets Connection Error: ${errMsg}. Please ensure your Admin Google session is active or re-authenticate in the Admin Panel.`
      });
    }

    const sheetData = await sheetInfoResponse.json();
    const sheetTitles = sheetData.sheets?.map((s: any) => s.properties?.title) || [];
    console.log(`Available sheet tabs: [${sheetTitles.join(", ")}]`);

    // Choose the best tab to append to (Prefer "Orders" or the first available sheet tab)
    let targetTab = "Orders";
    if (sheetTitles.includes("Orders")) {
      targetTab = "Orders";
    } else if (sheetTitles.length > 0) {
      targetTab = sheetTitles[0];
      console.warn(`"Orders" tab not found, falling back to first available sheet tab: "${targetTab}"`);
    }

    // 2. Perform the append operation on the resolved tab name
    console.log(`Appending order row to sheet tab: "${targetTab}"...`);
    const appendResponse = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(targetTab)}:append?valueInputOption=USER_ENTERED`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        range: targetTab,
        majorDimension: 'ROWS',
        values: [rowData],
      }),
    });

    if (!appendResponse.ok) {
      const errBody = await appendResponse.json().catch(() => ({}));
      console.warn(`Google Sheets Append failed for tab "${targetTab}":`, errBody);
      const errMsg = errBody.error?.message || `HTTP ${appendResponse.status}`;
      
      const isAuthError = appendResponse.status === 401 || appendResponse.status === 403;
      return res.json({
        success: false,
        error: isAuthError ? "auth_expired" : "connection_error",
        message: `Failed to append order to tab "${targetTab}": ${errMsg}`
      });
    }

    console.log(`Successfully appended order to Google Sheet tab "${targetTab}"`);
    res.json({ success: true });
  } catch (err: any) {
    console.warn("Server-side Google Sheets append warning:", err);
    res.json({ success: false, error: "unexpected_error", message: err.message });
  }
});

// Vite middleware for development and server listener wrapped in an async function to support CJS bundling
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
