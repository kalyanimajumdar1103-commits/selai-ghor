import React, { useState } from 'react';
import { Mail, Phone, MapPin, MessageCircle, Send, CheckCircle2, AlertCircle, HelpCircle } from 'lucide-react';
import { motion } from 'motion/react';
import { FAQ_ITEMS } from '../data';

export default function AboutContact() {
  const [contName, setContName] = useState('');
  const [contEmail, setContEmail] = useState('');
  const [contMsg, setContMsg] = useState('');
  const [formSent, setFormSent] = useState(false);

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contName.trim() || !contEmail.trim() || !contMsg.trim()) return;

    setFormSent(true);
    setContName('');
    setContEmail('');
    setContMsg('');
    setTimeout(() => setFormSent(false), 5000);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 text-left space-y-16" id="about-contact-views">
      
      {/* 1. About Us Section */}
      <section className="grid grid-cols-1 gap-12 lg:grid-cols-2 lg:items-center" id="about-us-section">
        
        {/* Left Column: Visual crochet arrangement */}
        <div className="relative">
          <div className="aspect-video w-full overflow-hidden rounded-[2.5rem] border-8 border-white bg-zinc-100 shadow-lg dark:border-zinc-800">
            <img
              src="https://images.unsplash.com/photo-1544816155-12df9643f363?q=80&w=600"
              alt="Artisan sewing wool yarn"
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover"
            />
          </div>
          
          <div className="absolute -bottom-6 -right-6 aspect-square w-32 overflow-hidden rounded-3xl border-4 border-white bg-white shadow-md dark:border-zinc-800 hidden sm:block">
            <img
              src="https://images.unsplash.com/photo-1599447421416-3414500d18a5?q=80&w=250"
              alt="Knitted details close up"
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover"
            />
          </div>
        </div>

        {/* Right Column: Artisan Brand message */}
        <div className="space-y-6">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-pink">Our Story & Craft</span>
          <h2 className="font-display text-3xl font-extrabold text-zinc-900 dark:text-white">
            About Selai Ghor
          </h2>
          
          <p className="text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed">
            Selai Ghor creates beautiful handmade crochet products using premium quality yarn with love and care. Every product is handmade and unique.
          </p>

          <p className="text-sm text-zinc-500 dark:text-zinc-400 leading-relaxed">
            Our workshop was founded with a single crochet hook and a vision to revive the traditional, slow, organic art of hand-knitting. Every daisy stitch, sunflower loop, and doll dress is painstakingly woven petal by petal by local women artisans, providing them with livelihood, respect, and creative expression.
          </p>

          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-pink-50 dark:border-zinc-800">
            <div>
              <span className="block text-sm font-bold text-zinc-800 dark:text-white">🌸 Premium Soft Yarn</span>
              <span className="block text-xs text-zinc-400 mt-0.5">Non-pilling combed cotton thread</span>
            </div>
            <div>
              <span className="block text-sm font-bold text-zinc-800 dark:text-white">💝 Made with Love</span>
              <span className="block text-xs text-zinc-400 mt-0.5">Each creation is uniquely yours</span>
            </div>
          </div>
        </div>

      </section>

      {/* 2. Frequently Asked Questions */}
      <section className="py-8 border-t border-pink-50 dark:border-zinc-800" id="faqs-container">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-purple">Got Questions?</span>
          <h2 className="font-display text-2xl font-bold text-zinc-900 dark:text-white mt-1">Frequently Asked Questions</h2>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 max-w-5xl mx-auto">
          {FAQ_ITEMS.map((faq, idx) => (
            <div
              key={idx}
              className="p-6 rounded-3xl border border-zinc-100 bg-zinc-50/50 hover:bg-zinc-100/50 transition-colors dark:border-zinc-800 dark:bg-zinc-950/20"
            >
              <div className="flex items-start space-x-3">
                <HelpCircle className="h-5 w-5 text-brand-pink mt-0.5 flex-shrink-0" />
                <div className="text-left space-y-2">
                  <h4 className="font-display text-sm font-bold text-zinc-800 dark:text-white">
                    {faq.question}
                  </h4>
                  <p className="text-xs text-zinc-500 leading-relaxed">
                    {faq.answer}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Contact Page Section */}
      <section className="py-8 border-t border-pink-50 dark:border-zinc-800" id="contact-section">
        
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-widest text-brand-green font-mono">Let's Connect</span>
          <h2 className="font-display text-2xl font-bold text-zinc-900 dark:text-white mt-1">Contact Us</h2>
          <p className="text-xs text-zinc-400 mt-2">Have a question about your order, shipping, or custom requests? We are here to help!</p>
        </div>

        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 items-start">
          
          {/* Contact Details (lg:span-5) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-3xl border border-zinc-100 bg-white dark:border-zinc-800 dark:bg-zinc-900 space-y-5">
              <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white border-b pb-2">
                Selai Ghor Headquarters
              </h3>

              <div className="space-y-4">
                <a
                  href="tel:+918100226410"
                  className="flex items-center space-x-3.5 text-xs font-semibold text-zinc-600 hover:text-brand-pink transition-colors dark:text-zinc-300"
                >
                  <Phone className="h-5 w-5 text-brand-pink" />
                  <span>+91 81002 26410</span>
                </a>

                <a
                  href="https://wa.me/918100226410"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center space-x-3.5 text-xs font-semibold text-zinc-600 hover:text-brand-green transition-colors dark:text-zinc-300"
                >
                  <MessageCircle className="h-5 w-5 text-brand-green" />
                  <span className="bg-emerald-500 text-white rounded-full px-3 py-1 text-[10px] font-bold">
                    Chat on WhatsApp
                  </span>
                </a>

                <div className="flex items-center space-x-3.5 text-xs font-semibold text-zinc-600 dark:text-zinc-300">
                  <Mail className="h-5 w-5 text-brand-purple" />
                  <span>support@salaighor.com</span>
                </div>

                <a
                  href="https://www.google.com/maps/place/Kalyani+9+no.+Bus+Stand/@22.9771559,88.4254074,3a,65.2y,37.17h,88.23t/data=!3m7!1e1!3m5!1smAaQxeaytObibOh9LgC3Jg!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fcb_client%3Dmaps_sv.tactile%26w%3D900%26h%3D600%26pitch%3D1.767054184513512%26panoid%3DmAaQxeaytObibOh9LgC3Jg%26yaw%3D37.17391542755566!7i16384!8i8192!4m6!3m5!1s0x39f895002b543ca3:0xb24c1db2fc8d00f0!8m2!3d22.9799114!4d88.4254417!16s%2Fg%2F11yd7mgpb2?entry=ttu&g_ep=EgoyMDI2MDcxNC4wIKXMDSoASAFQAw%3D%3D"
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-start space-x-3.5 text-xs font-semibold text-zinc-600 hover:text-brand-pink transition-colors dark:text-zinc-300"
                >
                  <MapPin className="h-5 w-5 text-zinc-500 mt-0.5 flex-shrink-0 text-brand-pink" />
                  <div className="text-left">
                    <span className="block font-bold">Kalyani Workshop</span>
                    <span>Kalyani 9 no. Bus Stand, Kalyani, West Bengal 741235, India</span>
                  </div>
                </a>
              </div>
            </div>

            {/* Custom Styled Google Map Visual Container */}
            <div className="rounded-3xl border border-zinc-100 overflow-hidden shadow-sm aspect-video relative group" id="google-map-box">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3674.6853767839353!2d88.42286647597148!3d22.9799162179836!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39f895002b543ca3%3A0xb24c1db2fc8d00f0!2sKalyani%209%20no.%20Bus%20Stand!5e0!3m2!1sen!2sin!4v1710000000000!5m2!1sen!2sin" 
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={true} 
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
              <div className="absolute bottom-2.5 left-2.5 rounded-lg bg-zinc-900/85 backdrop-blur px-2.5 py-1 text-[9px] font-bold text-white pointer-events-none">
                📍 Kalyani 9 no. Bus Stand, WB
              </div>
              <a 
                href="https://www.google.com/maps/place/Kalyani+9+no.+Bus+Stand/@22.9771559,88.4254074,3a,65.2y,37.17h,88.23t/data=!3m7!1e1!3m5!1smAaQxeaytObibOh9LgC3Jg!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fcb_client%3Dmaps_sv.tactile%26w%3D900%26h%3D600%26pitch%3D1.767054184513512%26panoid%3DmAaQxeaytObibOh9LgC3Jg%26yaw%3D37.17391542755566!7i16384!8i8192!4m6!3m5!1s0x39f895002b543ca3:0xb24c1db2fc8d00f0!8m2!3d22.9799114!4d88.4254417!16s%2Fg%2F11yd7mgpb2?entry=ttu&g_ep=EgoyMDI2MDcxNC4wIKXMDSoASAFQAw%3D%3D"
                target="_blank"
                rel="noreferrer"
                className="absolute top-2.5 right-2.5 rounded-xl bg-brand-pink text-white px-3 py-1.5 text-[10px] font-bold shadow-md hover:bg-brand-pink-dark transition-colors cursor-pointer flex items-center space-x-1"
              >
                <span>View Live Location</span>
                <span className="text-[9px]">↗</span>
              </a>
            </div>
          </div>

          {/* Contact Feedback Form (lg:span-7) */}
          <div className="lg:col-span-7 p-6 sm:p-8 rounded-3xl border border-pink-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
            <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-2 border-b">
              Send us a Message
            </h3>

            <form onSubmit={handleContactSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                  Your Full Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Rahul Halder"
                  value={contName}
                  onChange={(e) => setContName(e.target.value)}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
                  id="contact-name"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="e.g. rahul@example.com"
                  value={contEmail}
                  onChange={(e) => setContEmail(e.target.value)}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
                  id="contact-email"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                  Your Message
                </label>
                <textarea
                  rows={4}
                  placeholder="Write your suggestions, queries or business proposals here..."
                  value={contMsg}
                  onChange={(e) => setContMsg(e.target.value)}
                  required
                  className="w-full rounded-xl border border-zinc-200 p-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
                  id="contact-message"
                />
              </div>

              <button
                type="submit"
                id="contact-submit"
                className="w-full h-11 rounded-full bg-brand-pink text-xs font-bold text-white shadow hover:bg-brand-pink-dark transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Send className="h-4 w-4" />
                <span>Submit Query</span>
              </button>
            </form>

            {formSent && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 p-3 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300 text-xs font-bold flex items-center justify-center space-x-2"
              >
                <CheckCircle2 className="h-4 w-4" />
                <span>Message successfully recorded! We will get back to you within 24 hours.</span>
              </motion.div>
            )}
          </div>

        </div>
      </section>

    </div>
  );
}
