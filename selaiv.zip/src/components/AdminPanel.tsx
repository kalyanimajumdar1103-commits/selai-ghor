import React, { useState, useEffect } from 'react';
import { ShieldCheck, TrendingUp, BarChart2, Plus, Edit, Trash2, CheckCircle2, AlertCircle, ShoppingBag, CreditCard, Users, Tag, Package, FolderPlus, ArrowUpRight, Download, Printer, Eye, EyeOff, FileSpreadsheet, LogIn, LogOut, Filter, X, Settings, RefreshCw, Check, Cloud, Image, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';
import { Product, Order, User, Coupon, Poster } from '../types';
import { CATEGORIES } from '../data';
import { googleSignIn, googleSignOut, getAccessToken, initAuth } from '../utils/firebase';
import { sendOrderToSheet, createOrdersSpreadsheet } from '../utils/googleSheets';

interface AdminPanelProps {
  products: Product[];
  onAddProduct: (product: Product) => void;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, status: Order['status'], description: string) => void;
  users: User[];
  coupons: Coupon[];
  onAddCoupon: (coupon: Coupon) => void;
  onDeleteCoupon: (code: string) => void;
  categories: string[];
  categoryImages?: {[key: string]: string};
  onUpdateCategoryImage?: (category: string, url: string) => void;
  onAddCategory: (category: string) => void;
  onDeleteCategory: (category: string) => void;
  onClose?: () => void;
  posters: Poster[];
  onAddPoster: (poster: Poster) => void;
  onDeletePoster: (posterId: string) => void;
  logoUrl: string;
  onUpdateLogo: (url: string) => void;
  qrCodeUrl: string;
  onUpdateQrCode: (url: string) => void;
}

export default function AdminPanel({
  products,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  orders,
  onUpdateOrderStatus,
  users,
  coupons,
  onAddCoupon,
  onDeleteCoupon,
  categories,
  categoryImages,
  onUpdateCategoryImage,
  onAddCategory,
  onDeleteCategory,
  onClose,
  posters,
  onAddPoster,
  onDeletePoster,
  logoUrl,
  onUpdateLogo,
  qrCodeUrl,
  onUpdateQrCode
}: AdminPanelProps) {
  // Admin Login Security States
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Active Order Status Filter State
  const [selectedOrderStatusFilter, setSelectedOrderStatusFilter] = useState<'All' | Order['status']>('All');

  // Selected Order for Invoice modal
  const [selectedInvoiceOrder, setSelectedInvoiceOrder] = useState<Order | null>(null);

  const [adminTab, setAdminTab] = useState<'dashboard' | 'products' | 'orders' | 'customers' | 'coupons' | 'categories' | 'sheets' | 'posters' | 'settings'>('dashboard');

  // Custom Admin Password state
  const [customPassword, setCustomPassword] = useState<string>(() => {
    return localStorage.getItem('sg_admin_password') || '11092007';
  });
  const [newPasswordInput, setNewPasswordInput] = useState('');
  const [newPasswordSuccess, setNewPasswordSuccess] = useState('');
  const [newPasswordError, setNewPasswordError] = useState('');

  // Store Settings inputs
  const [inputLogoUrl, setInputLogoUrl] = useState(logoUrl);
  const [inputQrCodeUrl, setInputQrCodeUrl] = useState(qrCodeUrl);

  // Poster management states
  const [posterImage, setPosterImage] = useState('');
  const [posterTitle, setPosterTitle] = useState('');
  const [posterSubtitle, setPosterSubtitle] = useState('');
  const [posterDescription, setPosterDescription] = useState('');
  const [posterLinkTab, setPosterLinkTab] = useState('shop');
  const [posterButtonText, setPosterButtonText] = useState('Shop Now');
  const [posterLayout, setPosterLayout] = useState<'split' | 'full'>('full');
  const [posterError, setPosterError] = useState('');

  // Non-blocking iframe-safe confirmations and category management
  const [productConfirmDeleteId, setProductConfirmDeleteId] = useState<string | null>(null);
  const [posterConfirmDeleteId, setPosterConfirmDeleteId] = useState<string | null>(null);
  const [categoryConfirmDeleteName, setCategoryConfirmDeleteName] = useState<string | null>(null);
  const [activeCategoryManage, setActiveCategoryManage] = useState<string | null>(null);
  const [editingCategoryForImage, setEditingCategoryForImage] = useState<string | null>(null);
  const [editingImageText, setEditingImageText] = useState<string>('');

  // Google Sheets integration state
  const [googleUser, setGoogleUser] = useState<any>(() => {
    const saved = localStorage.getItem('sg_google_user');
    return saved ? JSON.parse(saved) : null;
  });
  const [spreadsheetId, setSpreadsheetId] = useState<string>(() => {
    return localStorage.getItem('sg_spreadsheet_id') || '';
  });
  const [syncedOrderIds, setSyncedOrderIds] = useState<string[]>(() => {
    const saved = localStorage.getItem('sg_synced_order_ids');
    return saved ? JSON.parse(saved) : [];
  });
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState<string>('');
  const [autoSyncEnabled, setAutoSyncEnabled] = useState<boolean>(() => {
    return localStorage.getItem('sg_auto_sync_enabled') === 'true';
  });

  // Security: Clear admin token when leaving the AdminPanel view so password is required next time
  useEffect(() => {
    return () => {
      sessionStorage.removeItem('sg_admin_token');
    };
  }, []);

  // Listen for Google Auth State and load server configuration
  useEffect(() => {
    // Fetch sheets configuration from the server
    const fetchConfig = async () => {
      try {
        const response = await fetch('/api/sheets/config');
        if (response.ok) {
          const data = await response.json();
          if (data.spreadsheetId) {
            setSpreadsheetId(data.spreadsheetId);
            localStorage.setItem('sg_spreadsheet_id', data.spreadsheetId);
          }
        }
      } catch (err) {
        console.warn('Failed to load sheets config from server:', err);
      }
    };
    fetchConfig();

    const unsubscribe = initAuth(
      (user) => {
        setGoogleUser(user);
        localStorage.setItem('sg_google_user', JSON.stringify(user));
        
        // Sync active Google access token to the backend
        const token = getAccessToken();
        if (token) {
          fetch('/api/sheets/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ accessToken: token }),
          }).catch(err => console.warn('Failed to sync auth token with server:', err));
        }
      },
      () => {
        setGoogleUser(null);
        localStorage.removeItem('sg_google_user');
      }
    );
    return () => unsubscribe();
  }, []);

  const handleGoogleLogin = async () => {
    try {
      const res = await googleSignIn();
      if (res) {
        setGoogleUser(res.user);
        localStorage.setItem('sg_google_user', JSON.stringify(res.user));
        
        // Save the Google Access Token to the backend server config
        await fetch('/api/sheets/config', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ accessToken: res.accessToken }),
        });

        alert('Successfully authenticated with Google!');
      }
    } catch (err: any) {
      alert(`Google Auth Failed: ${err.message}`);
    }
  };

  const handleGoogleLogout = async () => {
    await googleSignOut();
    setGoogleUser(null);
    localStorage.removeItem('sg_google_user');
    alert('Logged out from Google!');
  };

  const handleCreateNewSheet = async () => {
    const token = getAccessToken();
    if (!token) {
      alert('Please authenticate with Google first.');
      return;
    }
    
    setIsSyncing(true);
    setSyncStatusMsg('Creating a new Google Spreadsheet...');
    try {
      const newId = await createOrdersSpreadsheet(token);
      setSpreadsheetId(newId);
      localStorage.setItem('sg_spreadsheet_id', newId);
      alert(`Spreadsheet created successfully!\nID: ${newId}`);
    } catch (err: any) {
      alert(`Failed to create spreadsheet: ${err.message}`);
    } finally {
      setIsSyncing(false);
      setSyncStatusMsg('');
    }
  };

  const handleSyncOrders = async () => {
    const token = getAccessToken();
    if (!token) {
      alert('Please authenticate with Google first.');
      return;
    }
    if (!spreadsheetId.trim()) {
      alert('Please connect a Google Spreadsheet ID or create a new one first.');
      return;
    }

    const pendingOrders = orders.filter(o => !syncedOrderIds.includes(o.id));
    if (pendingOrders.length === 0) {
      alert('All orders are already synced to Google Sheets!');
      return;
    }

    setIsSyncing(true);
    setSyncStatusMsg(`Syncing ${pendingOrders.length} pending orders...`);
    let successCount = 0;
    const newlySynced = [...syncedOrderIds];

    for (const order of pendingOrders) {
      try {
        const success = await sendOrderToSheet(order, spreadsheetId.trim(), token);
        if (success) {
          newlySynced.push(order.id);
          successCount++;
        }
      } catch (err) {
        console.error(`Failed to sync order ${order.id}:`, err);
      }
    }

    setSyncedOrderIds(newlySynced);
    localStorage.setItem('sg_synced_order_ids', JSON.stringify(newlySynced));
    alert(`Successfully synced ${successCount} out of ${pendingOrders.length} orders to Google Sheets!`);
    setIsSyncing(false);
    setSyncStatusMsg('');
  };

  const handleSyncSingleOrder = async (order: Order) => {
    const token = getAccessToken();
    if (!token) {
      alert('Please authenticate with Google first.');
      return;
    }
    if (!spreadsheetId.trim()) {
      alert('Please link a Spreadsheet ID first.');
      return;
    }

    setIsSyncing(true);
    try {
      const success = await sendOrderToSheet(order, spreadsheetId.trim(), token);
      if (success) {
        const nextSynced = [...syncedOrderIds, order.id];
        setSyncedOrderIds(nextSynced);
        localStorage.setItem('sg_synced_order_ids', JSON.stringify(nextSynced));
        alert(`Order ${order.id} successfully synced to Google Sheets!`);
      } else {
        alert(`Failed to sync order ${order.id}`);
      }
    } catch (err: any) {
      alert(`Sync Error: ${err.message}`);
    } finally {
      setIsSyncing(false);
    }
  };

  const handleSaveSpreadsheetId = async (id: string) => {
    const cleanId = id.trim();
    setSpreadsheetId(cleanId);
    localStorage.setItem('sg_spreadsheet_id', cleanId);

    // Save the spreadsheet ID to the backend server config
    try {
      await fetch('/api/sheets/config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ spreadsheetId: cleanId }),
      });
    } catch (err) {
      console.warn('Failed to save spreadsheet ID to server:', err);
    }
  };

  const handleToggleAutoSync = (checked: boolean) => {
    setAutoSyncEnabled(checked);
    localStorage.setItem('sg_auto_sync_enabled', String(checked));
  };
  
  // Product Form states
  const [isEditingProduct, setIsEditingProduct] = useState(false);
  const [editingProdId, setEditingProdId] = useState<string | null>(null);
  
  const [prodName, setProdName] = useState('');
  const [prodPrice, setProdPrice] = useState(0);
  const [prodDiscount, setProdDiscount] = useState<number | undefined>(undefined);
  const [prodCategory, setProdCategory] = useState(categories[0] || 'Crochet Bags');
  const [prodImages, setProdImages] = useState<string[]>([]);
  const [tempImageInput, setTempImageInput] = useState('');
  const [prodAvailability, setProdAvailability] = useState<'In Stock' | 'Out of Stock' | 'Pre-order'>('In Stock');
  const [prodShortDesc, setProdShortDesc] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  const [prodMaterials, setProdMaterials] = useState('');
  const [prodSize, setProdSize] = useState('');
  const [prodWeight, setProdWeight] = useState('');
  const [prodColors, setProdColors] = useState<string[]>([]);
  const [tempColorInput, setTempColorInput] = useState('');
  const [colorImagesMap, setColorImagesMap] = useState<{ [color: string]: string[] }>({});
  const [colorPricesMap, setColorPricesMap] = useState<{ [color: string]: number }>({});
  const [colorDiscountPricesMap, setColorDiscountPricesMap] = useState<{ [color: string]: number }>({});

  // Category addition state
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryPhoto, setNewCategoryPhoto] = useState('');

  // Coupon addition state
  const [couponCode, setCouponCode] = useState('');
  const [couponType, setCouponType] = useState<string>('percentage');
  const [couponVal, setCouponVal] = useState(0);
  const [couponMin, setCouponMin] = useState<number | undefined>(undefined);

  // Stats derivations
  const totalRevenue = orders
    .filter(o => o.status !== 'Cancelled')
    .reduce((sum, o) => sum + o.grandTotal, 0);

  const totalProductsSold = orders
    .filter(o => o.status !== 'Cancelled')
    .reduce((sum, o) => sum + o.items.reduce((itemSum, item) => itemSum + item.quantity, 0), 0);

  // Security & Authentication Helpers
  const djb2Hash = (str: string): string => {
    let hash = 5381;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) + hash) + str.charCodeAt(i);
    }
    return (hash >>> 0).toString(16);
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const emailLower = adminEmail.trim().toLowerCase();
    const passHash = djb2Hash(adminPassword);

    // Support premium and fallback simple admin credentials
    const isEmailValid = emailLower === 'kalyanimajumdar1103@gmail.com' || emailLower === 'admin@selaighor.com';
    const isPasswordValid = adminPassword === customPassword || adminPassword === '11092007' || passHash === 'c37ff819' || passHash === '86903e8a'; // custom, 11092007, or SalaiGhor@2026 or admin

    if (isEmailValid && isPasswordValid) {
      // Generate standard JWT structured token
      const header = btoa(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
      const payload = btoa(JSON.stringify({
        email: emailLower,
        role: 'admin',
        exp: Math.floor(Date.now() / 1000) + 7200 // 2 hours expiration
      }));
      const signature = btoa('salaighor_secret_key_2026');
      const token = `${header}.${payload}.${signature}`;

      sessionStorage.setItem('sg_admin_token', token);
      setIsAdminLoggedIn(true);
      setAdminEmail('');
      setAdminPassword('');
      setLoginError('');
    } else {
      setLoginError('Invalid Email or Password');
    }
  };

  const handleExportToExcel = () => {
    if (orders.length === 0) {
      alert('No orders available to export.');
      return;
    }

    // Excel CSV Headers
    const headers = [
      'Order ID',
      'Customer Name',
      'Phone Number',
      'Email',
      'Address',
      'Product Name(s)',
      'Quantity',
      'Total Price',
      'Payment Method',
      'Order Status',
      'Order Date'
    ];

    const rows = orders.map(o => {
      const productDetails = o.items.map(item => `${item.product.name} (${item.selectedColor})`).join('; ');
      const totalQty = o.items.reduce((sum, item) => sum + item.quantity, 0);
      const cleanAddress = `"${o.address.fullAddress.replace(/"/g, '""')}, Near ${o.address.landmark.replace(/"/g, '""')}, ${o.address.district}, ${o.address.state} - ${o.address.pinCode}"`;
      
      return [
        o.id,
        `"${o.address.fullName.replace(/"/g, '""')}"`,
        o.address.phoneNumber,
        o.userEmail || 'Guest',
        cleanAddress,
        `"${productDetails.replace(/"/g, '""')}"`,
        totalQty,
        o.grandTotal,
        o.paymentMethod,
        o.status,
        o.orderDate
      ];
    });

    const csvContent = "\uFEFF" // UTF-8 BOM to display Bengali characters and symbols correctly in Excel
      + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `SalaiGhor_Orders_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleAddImageUrl = () => {
    if (tempImageInput.trim()) {
      setProdImages(prev => [...prev, tempImageInput.trim()]);
      setTempImageInput('');
    }
  };

  const handleAddColor = () => {
    if (tempColorInput.trim()) {
      setProdColors(prev => [...prev, tempColorInput.trim()]);
      setTempColorInput('');
    }
  };

  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodName.trim() || prodPrice <= 0 || prodImages.length === 0) {
      alert('Product name, valid price, and at least 1 image are required.');
      return;
    }

    // Clean up colorImages, colorPrices, and colorDiscountPrices mapping for colors that were deleted from prodColors
    const cleanedColorImages: { [color: string]: string[] } = {};
    const cleanedColorPrices: { [color: string]: number } = {};
    const cleanedColorDiscountPrices: { [color: string]: number } = {};

    prodColors.forEach(color => {
      if (colorImagesMap[color] && colorImagesMap[color].length > 0) {
        cleanedColorImages[color] = colorImagesMap[color];
      }
      if (colorPricesMap[color] !== undefined) {
        cleanedColorPrices[color] = colorPricesMap[color];
      }
      if (colorDiscountPricesMap[color] !== undefined) {
        cleanedColorDiscountPrices[color] = colorDiscountPricesMap[color];
      }
    });

    const currentData: Product = {
      id: isEditingProduct && editingProdId ? editingProdId : `prod-${Date.now()}`,
      name: prodName,
      price: Number(prodPrice),
      discountPrice: prodDiscount ? Number(prodDiscount) : undefined,
      category: prodCategory,
      images: prodImages,
      availability: prodAvailability,
      shortDescription: prodShortDesc,
      description: prodDesc,
      materialsUsed: prodMaterials || 'Premium Cotton Wool Yarn',
      size: prodSize || 'Medium',
      weight: prodWeight || '200g',
      estimatedDelivery: '3 - 5 business days',
      colorOptions: prodColors.length > 0 ? prodColors : ['Standard Cream'],
      colorImages: Object.keys(cleanedColorImages).length > 0 ? cleanedColorImages : undefined,
      colorPrices: Object.keys(cleanedColorPrices).length > 0 ? cleanedColorPrices : undefined,
      colorDiscountPrices: Object.keys(cleanedColorDiscountPrices).length > 0 ? cleanedColorDiscountPrices : undefined,
      rating: 4.8
    };

    if (isEditingProduct && editingProdId) {
      onEditProduct(currentData);
      alert('Product successfully updated!');
    } else {
      onAddProduct(currentData);
      alert('New product successfully listed!');
    }

    // Reset Form
    setIsEditingProduct(false);
    setEditingProdId(null);
    setProdName('');
    setProdPrice(0);
    setProdDiscount(undefined);
    setProdImages([]);
    setProdColors([]);
    setProdShortDesc('');
    setProdDesc('');
    setProdMaterials('');
    setProdSize('');
    setProdWeight('');
    setColorImagesMap({});
    setColorPricesMap({});
    setColorDiscountPricesMap({});
  };

  const startEditProduct = (prod: Product) => {
    setIsEditingProduct(true);
    setEditingProdId(prod.id);
    setProdName(prod.name);
    setProdPrice(prod.price);
    setProdDiscount(prod.discountPrice);
    setProdCategory(prod.category);
    setProdImages(prod.images);
    setProdAvailability(prod.availability);
    setProdShortDesc(prod.shortDescription);
    setProdDesc(prod.description);
    setProdMaterials(prod.materialsUsed);
    setProdSize(prod.size);
    setProdWeight(prod.weight);
    setProdColors(prod.colorOptions);
    setColorImagesMap(prod.colorImages || {});
    setColorPricesMap(prod.colorPrices || {});
    setColorDiscountPricesMap(prod.colorDiscountPrices || {});
  };

  const handleCategorySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const catTrimmed = newCategoryName.trim();
    if (catTrimmed && !categories.includes(catTrimmed)) {
      onAddCategory(catTrimmed);
      if (newCategoryPhoto.trim() && onUpdateCategoryImage) {
        onUpdateCategoryImage(catTrimmed, newCategoryPhoto.trim());
      }
      alert(`Category "${catTrimmed}" added successfully!`);
      setNewCategoryName('');
      setNewCategoryPhoto('');
    }
  };

  const handleCouponSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim() || couponVal <= 0) return;

    const newCoupon: Coupon = {
      code: couponCode.trim().toUpperCase(),
      discountType: couponType,
      discountValue: Number(couponVal),
      minPurchase: couponMin ? Number(couponMin) : undefined
    };

    onAddCoupon(newCoupon);
    alert(`Coupon code "${newCoupon.code}" created successfully!`);
    setCouponCode('');
    setCouponVal(0);
    setCouponMin(undefined);
  };

  if (!isAdminLoggedIn) {
    return (
      <div className="flex min-h-[70vh] items-center justify-center px-4 py-12 sm:px-6 lg:px-8 bg-zinc-50 dark:bg-zinc-950">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative w-full max-w-md space-y-8 rounded-3xl border border-zinc-100 bg-white p-8 shadow-xl dark:border-zinc-800 dark:bg-zinc-900"
        >
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="absolute right-5 top-5 rounded-full p-1.5 text-zinc-400 hover:bg-zinc-100 hover:text-zinc-600 dark:hover:bg-zinc-800 dark:hover:text-zinc-200 transition-colors"
              aria-label="Close Admin Portal"
            >
              <X className="h-5 w-5" />
            </button>
          )}

          <div className="text-center">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-brand-pink-light text-brand-pink font-black text-2xl dark:bg-pink-950/40 dark:text-pink-400">
              S
            </div>
            <h2 className="mt-6 font-display text-2xl font-extrabold tracking-tight text-zinc-900 dark:text-white">
              Admin Portal
            </h2>
            <p className="mt-2 text-xs text-zinc-400">
              Authorized personnel only. Please sign in to manage Selai Ghor.
            </p>
            

          </div>

          <form onSubmit={handleAdminLogin} className="mt-8 space-y-4">
            {loginError && (
              <div className="flex items-center space-x-2 rounded-2xl bg-red-50 p-3 text-xs font-semibold text-red-600 dark:bg-red-950/20 dark:text-red-400">
                <AlertCircle className="h-4 w-4 shrink-0" />
                <span>{loginError}</span>
              </div>
            )}

            <div className="space-y-1.5">
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 dark:text-zinc-400">
                Admin Email
              </label>
              <input
                type="email"
                required
                value={adminEmail}
                onChange={(e) => {
                  setAdminEmail(e.target.value);
                  setLoginError('');
                }}
                placeholder=""
                className="h-10 w-full rounded-xl border border-zinc-200 px-3.5 text-xs text-zinc-800 dark:text-white outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-800"
              />
            </div>

             <div className="space-y-1.5">
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 dark:text-zinc-400">
                Admin Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  value={adminPassword}
                  onChange={(e) => {
                    setAdminPassword(e.target.value);
                    setLoginError('');
                  }}
                  placeholder="••••••••"
                  className="h-10 w-full rounded-xl border border-zinc-200 pl-3.5 pr-10 text-xs text-zinc-800 dark:text-white outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-800"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              className="w-full h-11 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark transition-all shadow-md shadow-pink-100 dark:shadow-none mt-2"
            >
              Sign In to Dashboard
            </button>
          </form>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 text-left" id="admin-view-panel">
      
      {/* Admin Title Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-8 pb-6 border-b border-pink-50 dark:border-zinc-800">
        <div>
          <span className="text-xs font-bold uppercase tracking-widest text-brand-purple flex items-center space-x-1.5">
            <ShieldCheck className="h-4 w-4" />
            <span>Administrator Portal Only</span>
          </span>
          <h1 className="font-display text-2xl font-extrabold sm:text-3xl text-zinc-900 dark:text-white mt-1">
            Selai Ghor Management Panel
          </h1>
          <p className="text-xs text-zinc-400">Add products, configure discounts, handle orders, and audit business charts.</p>
        </div>

        <div className="flex flex-wrap gap-2.5">
          <button
            onClick={handleExportToExcel}
            className="flex items-center space-x-1.5 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs font-bold text-emerald-700 hover:bg-emerald-100 dark:border-emerald-900/30 dark:bg-emerald-950/10 dark:text-emerald-400 transition-all"
            title="Export all orders to Excel Spreadsheet"
          >
            <FileSpreadsheet className="h-4 w-4" />
            <span>Export to Excel</span>
          </button>

          <button
            onClick={() => {
              sessionStorage.removeItem('sg_admin_token');
              setIsAdminLoggedIn(false);
            }}
            className="flex items-center space-x-1.5 rounded-xl border border-zinc-200 bg-white px-4 py-2.5 text-xs font-bold text-zinc-600 hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800 transition-all"
            title="Secure Sign Out"
          >
            <LogOut className="h-4 w-4 text-red-500" />
            <span>Sign Out</span>
          </button>
        </div>

        {/* Quick Admin Navigation Tabs */}
        <div className="flex flex-wrap gap-1">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: BarChart2 },
            { id: 'products', label: 'Products', icon: Package },
            { id: 'orders', label: 'Orders', icon: ShoppingBag },
            { id: 'customers', label: 'Customers', icon: Users },
            { id: 'coupons', label: 'Coupons', icon: Tag },
            { id: 'categories', label: 'Categories', icon: FolderPlus },
            { id: 'sheets', label: 'Google Sheets', icon: FileSpreadsheet },
            { id: 'posters', label: 'Posters', icon: Image },
            { id: 'settings', label: 'Store Settings', icon: Settings }
          ].map((tab) => {
            const TabIcon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setAdminTab(tab.id as any);
                  setIsEditingProduct(false);
                }}
                className={`flex items-center space-x-2 rounded-xl px-4 py-2.5 text-xs font-bold transition-all ${
                  adminTab === tab.id
                    ? 'bg-brand-pink text-white shadow-sm'
                    : 'bg-zinc-50 text-zinc-600 hover:bg-zinc-100 dark:bg-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800'
                }`}
              >
                <TabIcon className="h-3.5 w-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Render Contents based on Tabs */}

      {/* 1. VIEW DASHBOARD */}
      {adminTab === 'dashboard' && (
        <div className="space-y-8" id="admin-dashboard-tab">
          
          {/* Metrics summary cards */}
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
            
            <div className="p-5 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 flex items-center space-x-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-pink-light text-brand-pink dark:bg-pink-950/30">
                <CreditCard className="h-6 w-6" />
              </div>
              <div>
                <span className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400">Total Sales</span>
                <span className="block text-xl font-extrabold text-zinc-900 dark:text-white">₹{totalRevenue}</span>
              </div>
            </div>

            <div className="p-5 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 flex items-center space-x-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-purple-light text-brand-purple dark:bg-purple-950/30">
                <ShoppingBag className="h-6 w-6" />
              </div>
              <div>
                <span className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400">Total Orders</span>
                <span className="block text-xl font-extrabold text-zinc-900 dark:text-white">{orders.length}</span>
              </div>
            </div>

            <div className="p-5 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 flex items-center space-x-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-green-light text-brand-green dark:bg-emerald-950/30">
                <Users className="h-6 w-6" />
              </div>
              <div>
                <span className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400">Registered Customers</span>
                <span className="block text-xl font-extrabold text-zinc-900 dark:text-white">{users.length}</span>
              </div>
            </div>

            <div className="p-5 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 flex items-center space-x-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-zinc-100 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300">
                <Package className="h-6 w-6" />
              </div>
              <div>
                <span className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400">Listed Creations</span>
                <span className="block text-xl font-extrabold text-zinc-900 dark:text-white">{products.length}</span>
              </div>
            </div>

          </div>

          {/* Simple Visual Sales Chart / Metrics and Recent orders */}
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
            
            {/* Sales Chart block (lg:span-7) */}
            <div className="lg:col-span-7 p-6 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
              <div className="flex items-center justify-between mb-4 border-b border-zinc-50 pb-3 dark:border-zinc-800">
                <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white flex items-center space-x-2">
                  <TrendingUp className="h-4.5 w-4.5 text-brand-pink" />
                  <span>Interactive sales audit report</span>
                </h3>
                <span className="text-[10px] font-bold uppercase tracking-wider text-brand-green bg-brand-green-light px-2.5 py-1 rounded-full">
                  Live metrics
                </span>
              </div>

              <p className="text-xs text-zinc-500 leading-relaxed mb-6">
                Total units knitted and dispatched: <strong className="text-zinc-800 dark:text-white">{totalProductsSold} items</strong>. Here is the category distribution representation based on inventory listings:
              </p>

              {/* Graphical simulation using simple bars */}
              <div className="space-y-4" id="sales-graphic-bars">
                {categories.map((cat) => {
                  const itemsCount = products.filter(p => p.category === cat).length;
                  const pct = Math.max(8, Math.min(100, (itemsCount / products.length) * 100));
                  return (
                    <div key={cat} className="space-y-1">
                      <div className="flex justify-between text-[11px] font-bold">
                        <span className="text-zinc-600 dark:text-zinc-300">{cat}</span>
                        <span className="text-zinc-900 dark:text-white">{itemsCount} products listed</span>
                      </div>
                      
                      <div className="h-2.5 w-full rounded-full bg-zinc-100 dark:bg-zinc-800">
                        <div 
                          className="h-full rounded-full bg-gradient-to-r from-brand-pink to-brand-purple transition-all duration-1000" 
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick Recent order list (lg:span-5) */}
            <div className="lg:col-span-5 p-6 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
              <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-3 border-b border-zinc-100 dark:border-zinc-800">
                Recent Order Notifications
              </h3>

              {orders.length === 0 ? (
                <p className="text-xs text-zinc-500 italic text-center py-10">No orders placed yet.</p>
              ) : (
                <div className="space-y-3" id="dashboard-recent-orders">
                  {orders.slice(0, 5).map((ord) => (
                    <div
                      key={ord.id}
                      className="flex items-center justify-between p-3 rounded-xl bg-zinc-50 hover:bg-zinc-100 transition-colors dark:bg-zinc-950/20"
                    >
                      <div className="text-left">
                        <span className="block text-xs font-bold text-zinc-800 dark:text-white">ID: {ord.id}</span>
                        <span className="block text-[10px] text-zinc-400">{ord.address.fullName} • {ord.paymentMethod}</span>
                      </div>
                      
                      <div className="text-right">
                        <span className="block text-xs font-bold text-brand-pink">₹{ord.grandTotal}</span>
                        <span className="block text-[9px] font-bold uppercase text-brand-purple mt-0.5">{ord.status}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>
      )}

      {/* 2. PRODUCT MANAGEMENT (ADD / EDIT / DELETE) */}
      {adminTab === 'products' && (
        <div className="space-y-8" id="admin-products-tab">
          
          <div className="flex items-center justify-between border-b border-zinc-100 pb-4 dark:border-zinc-800">
            <h2 className="font-display text-base font-bold text-zinc-800 dark:text-white">
              {isEditingProduct ? `Edit Product: ${prodName}` : 'Add New Product Creation'}
            </h2>
            
            {isEditingProduct && (
              <button
                onClick={() => {
                  setIsEditingProduct(false);
                  setEditingProdId(null);
                  setProdName('');
                  setProdPrice(0);
                  setProdImages([]);
                }}
                className="text-xs font-bold text-zinc-500 hover:text-zinc-700"
              >
                Cancel Editing / Add New Instead
              </button>
            )}
          </div>

          {/* Form to Add or Edit Product */}
          <form onSubmit={handleProductSubmit} className="p-6 rounded-3xl border border-pink-100 bg-white space-y-4 dark:border-zinc-800 dark:bg-zinc-900">
            
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Product Name <span className="text-brand-pink">*</span>
                </label>
                <input
                  type="text"
                  placeholder="e.g. Handmade Woolen Gloves"
                  value={prodName}
                  onChange={(e) => setProdName(e.target.value)}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800"
                  id="admin-form-name"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Base Price (₹) <span className="text-brand-pink">*</span>
                </label>
                <input
                  type="number"
                  placeholder="e.g. 599"
                  value={prodPrice}
                  onChange={(e) => setProdPrice(Number(e.target.value))}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800"
                  id="admin-form-price"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Discounted Special Price (₹, Optional)
                </label>
                <input
                  type="number"
                  placeholder="e.g. 450"
                  value={prodDiscount || ''}
                  onChange={(e) => setProdDiscount(e.target.value ? Number(e.target.value) : undefined)}
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800"
                  id="admin-form-discount"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Select Category
                </label>
                <select
                  value={prodCategory}
                  onChange={(e) => setProdCategory(e.target.value)}
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100"
                  id="admin-form-category"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat} className="bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100">{cat}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Stock Status
                </label>
                <select
                  value={prodAvailability}
                  onChange={(e) => setProdAvailability(e.target.value as any)}
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100"
                  id="admin-form-stock"
                >
                  <option value="In Stock" className="bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100">In Stock (Shipped in 1-2 days)</option>
                  <option value="Out of Stock" className="bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100">Out of Stock</option>
                  <option value="Pre-order" className="bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100">Pre-order (Craft on demand)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Product Dimensions (e.g. 5" x 5")
                </label>
                <input
                  type="text"
                  placeholder="e.g. 6 inches Height"
                  value={prodSize}
                  onChange={(e) => setProdSize(e.target.value)}
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800"
                  id="admin-form-size"
                />
              </div>
            </div>

            {/* Images upload url checklist */}
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Add Image URL <span className="text-brand-pink">*</span>
                </label>
                <div className="flex gap-2">
                  <input
                    type="url"
                    placeholder="e.g. https://images.unsplash.com/photo-..."
                    value={tempImageInput}
                    onChange={(e) => setTempImageInput(e.target.value)}
                    className="h-10 flex-1 rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800"
                    id="admin-image-url-input"
                  />
                  <button
                    type="button"
                    onClick={handleAddImageUrl}
                    className="h-10 rounded-xl bg-zinc-800 px-4 text-xs font-bold text-white hover:bg-zinc-950"
                  >
                    Add
                  </button>
                </div>
                
                {/* Images Preview list */}
                <div className="mt-2.5 flex flex-wrap gap-2">
                  {prodImages.map((imgUrl, idx) => (
                    <div key={idx} className="relative h-14 w-14 rounded-lg border p-0.5">
                      <img src={imgUrl} alt="uploaded preview" referrerPolicy="no-referrer" className="h-full w-full object-cover rounded-md" />
                      <button
                        type="button"
                        onClick={() => setProdImages(prev => prev.filter((_, i) => i !== idx))}
                        className="absolute -top-1.5 -right-1.5 bg-red-500 hover:bg-red-600 text-white h-4 w-4 rounded-full flex items-center justify-center text-[10px] font-bold shadow-md transition-colors cursor-pointer"
                        title="Delete image"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                  {prodImages.length === 0 && (
                    <span className="text-[10px] text-zinc-400 italic">No image URLs added yet.</span>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Add Color Options
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="e.g. Blush Pink, Olive Green"
                    value={tempColorInput}
                    onChange={(e) => setTempColorInput(e.target.value)}
                    className="h-10 flex-1 rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800"
                    id="admin-color-input"
                  />
                  <button
                    type="button"
                    onClick={handleAddColor}
                    className="h-10 rounded-xl bg-zinc-800 px-4 text-xs font-bold text-white hover:bg-zinc-950"
                  >
                    Add
                  </button>
                </div>
                
                {/* Colors Preview list */}
                <div className="mt-2.5 flex flex-wrap gap-1.5">
                  {prodColors.map((col, idx) => (
                    <span key={idx} className="inline-flex items-center space-x-1 text-[10px] font-bold bg-zinc-100 text-zinc-800 px-2 py-1 rounded-full border dark:bg-zinc-800 dark:text-zinc-200">
                      <span>{col}</span>
                      <button
                        type="button"
                        onClick={() => setProdColors(prev => prev.filter((_, i) => i !== idx))}
                        className="text-red-500 hover:text-red-700"
                      >
                        ✕
                      </button>
                    </span>
                  ))}
                  {prodColors.length === 0 && (
                    <span className="text-[10px] text-zinc-400 italic">No colors entered.</span>
                  )}
                </div>
              </div>
            </div>

            {prodColors.length > 0 && (
              <div className="mb-6 p-5 rounded-3xl border border-pink-100 bg-pink-50/10 dark:border-zinc-800 dark:bg-zinc-900/30">
                <h4 className="font-display text-xs font-bold text-zinc-800 dark:text-pink-300 mb-3 flex items-center gap-1.5">
                  <Sparkles className="h-4 w-4 text-brand-pink" />
                  <span>Variant Specific Images & Prices (Optional)</span>
                </h4>
                <p className="text-[10px] text-zinc-400 mb-4 leading-normal">
                  Specify separate photo assets and pricing parameters for individual colors. If left empty, they will fall back to the product's main images and base prices.
                </p>
                
                <div className="space-y-4">
                  {prodColors.map((color) => {
                    const currentImages = colorImagesMap[color] || [];
                    const currentPrice = colorPricesMap[color] || '';
                    const currentDiscount = colorDiscountPricesMap[color] || '';
                    
                    return (
                      <div key={color} className="p-3.5 rounded-xl border border-zinc-200/60 bg-white dark:border-zinc-800 dark:bg-zinc-950/60 space-y-3">
                        <div className="flex items-center justify-between border-b pb-1.5 dark:border-zinc-800">
                          <span className="text-xs font-extrabold text-zinc-900 dark:text-white flex items-center gap-1.5">
                            <span className="h-2 w-2 rounded-full bg-brand-pink" />
                            {color}
                          </span>
                        </div>
                        
                        <div className="grid grid-cols-1 gap-3 sm:grid-cols-12 items-end">
                          {/* Images field */}
                          <div className="sm:col-span-6 space-y-1">
                            <label className="block text-[9px] font-bold uppercase tracking-wider text-zinc-400">
                              Variant Photo URLs (Comma separated)
                            </label>
                            <input
                              type="text"
                              placeholder="https://image1.jpg, https://image2.jpg"
                              value={currentImages.join(', ')}
                              onChange={(e) => {
                                const urls = e.target.value.split(',').map(url => url.trim()).filter(Boolean);
                                setColorImagesMap(prev => ({ ...prev, [color]: urls }));
                              }}
                              className="h-9 w-full rounded-lg border border-zinc-200 px-3.5 text-[11px] outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-900 dark:text-white"
                            />
                          </div>
                          
                          {/* Variant Price */}
                          <div className="sm:col-span-3 space-y-1">
                            <label className="block text-[9px] font-bold uppercase tracking-wider text-zinc-400">
                              Variant Base Price (₹)
                            </label>
                            <input
                              type="number"
                              placeholder="e.g. 699"
                              value={currentPrice}
                              onChange={(e) => {
                                const val = e.target.value ? Number(e.target.value) : undefined;
                                setColorPricesMap(prev => {
                                  const next = { ...prev };
                                  if (val === undefined) {
                                    delete next[color];
                                  } else {
                                    next[color] = val;
                                  }
                                  return next;
                                });
                              }}
                              className="h-9 w-full rounded-lg border border-zinc-200 px-3 text-[11px] outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-900 dark:text-white"
                            />
                          </div>

                          {/* Variant Discount Price */}
                          <div className="sm:col-span-3 space-y-1">
                            <label className="block text-[9px] font-bold uppercase tracking-wider text-zinc-400">
                              Discount Price (₹)
                            </label>
                            <input
                              type="number"
                              placeholder="e.g. 499"
                              value={currentDiscount}
                              onChange={(e) => {
                                const val = e.target.value ? Number(e.target.value) : undefined;
                                setColorDiscountPricesMap(prev => {
                                  const next = { ...prev };
                                  if (val === undefined) {
                                    delete next[color];
                                  } else {
                                    next[color] = val;
                                  }
                                  return next;
                                });
                              }}
                              className="h-9 w-full rounded-lg border border-zinc-200 px-3 text-[11px] outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-900 dark:text-white"
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Short One-line Tagline
                </label>
                <input
                  type="text"
                  placeholder="e.g. Charming knitted purse with soft floral straps."
                  value={prodShortDesc}
                  onChange={(e) => setProdShortDesc(e.target.value)}
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink"
                  id="admin-form-short-desc"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Yarn Materials Used (e.g. combed cotton)
                </label>
                <input
                  type="text"
                  placeholder="e.g. 100% Cotton Milk Yarn"
                  value={prodMaterials}
                  onChange={(e) => setProdMaterials(e.target.value)}
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink"
                  id="admin-form-materials"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Net Weight (g)
                </label>
                <input
                  type="text"
                  placeholder="e.g. 150g"
                  value={prodWeight}
                  onChange={(e) => setProdWeight(e.target.value)}
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink"
                  id="admin-form-weight"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                Full Narrative Description
              </label>
              <textarea
                rows={3}
                placeholder="Write full product specifications, wash care, design notes..."
                value={prodDesc}
                onChange={(e) => setProdDesc(e.target.value)}
                className="w-full rounded-xl border border-zinc-200 p-3 text-xs outline-none focus:border-brand-pink"
                id="admin-form-desc"
              />
            </div>

            <button
              type="submit"
              id="admin-product-submit"
              className="w-full h-11 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark transition-all"
            >
              {isEditingProduct ? 'Update Product Listing' : 'Publish Product Creation'}
            </button>
          </form>

          {/* Table List of Current Products to Edit or Delete */}
          <div className="rounded-3xl border border-zinc-100 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-900 overflow-x-auto">
            <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4">
              Current Inventory Directory ({products.length} listed items)
            </h3>

            <table className="w-full text-xs text-left" id="admin-inventory-table">
              <thead>
                <tr className="border-b text-zinc-400 font-bold uppercase tracking-wider">
                  <th className="pb-3">Image</th>
                  <th className="pb-3">Product Name</th>
                  <th className="pb-3">Category</th>
                  <th className="pb-3">Price</th>
                  <th className="pb-3">Availability</th>
                  <th className="pb-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-50 dark:divide-zinc-800">
                {products.map((prod) => (
                  <tr key={prod.id} className="hover:bg-zinc-50/50 dark:hover:bg-zinc-800/20">
                    <td className="py-3">
                      <div className="h-10 w-10 overflow-hidden rounded-lg bg-zinc-50 border">
                        <img src={prod.images[0]} alt="" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                      </div>
                    </td>
                    <td className="py-3 font-semibold text-zinc-800 dark:text-white">{prod.name}</td>
                    <td className="py-3 text-zinc-500">{prod.category}</td>
                    <td className="py-3 font-bold text-zinc-900 dark:text-white">
                      ₹{prod.discountPrice || prod.price}
                    </td>
                    <td className="py-3">
                      <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold uppercase ${
                        prod.availability === 'In Stock' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {prod.availability}
                      </span>
                    </td>
                    <td className="py-3 text-right space-x-2">
                      <button
                        onClick={() => {
                          startEditProduct(prod);
                          window.scrollTo({ top: 120, behavior: 'smooth' });
                        }}
                        className="p-1.5 rounded-lg border hover:bg-zinc-50 text-zinc-600 dark:border-zinc-800 dark:text-zinc-400 dark:hover:bg-zinc-800"
                        title="Edit Product"
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </button>
                      
                      {productConfirmDeleteId === prod.id ? (
                        <div className="inline-flex items-center space-x-1">
                          <button
                            onClick={() => {
                              onDeleteProduct(prod.id);
                              setProductConfirmDeleteId(null);
                            }}
                            className="px-2.5 py-1 rounded-xl bg-red-600 text-white font-bold text-[10px] hover:bg-red-700 transition-colors cursor-pointer"
                          >
                            Delete
                          </button>
                          <button
                            onClick={() => setProductConfirmDeleteId(null)}
                            className="px-2.5 py-1 rounded-xl border bg-white text-zinc-500 text-[10px] hover:bg-zinc-50 dark:bg-zinc-800 dark:text-zinc-300 transition-colors cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => {
                            setProductConfirmDeleteId(prod.id);
                          }}
                          className="p-1.5 rounded-lg border hover:bg-red-50 text-red-500 dark:border-zinc-800 dark:hover:bg-red-950/30 cursor-pointer inline-flex items-center justify-center"
                          title="Delete Product"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* 3. MANAGE CUSTOMER ORDERS */}
      {adminTab === 'orders' && (
        <div className="space-y-6" id="admin-orders-tab">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-zinc-100 pb-4 dark:border-zinc-800 gap-4">
            <div>
              <h2 className="font-display text-base font-bold text-zinc-800 dark:text-white">
                Fulfill Orders & Adjust Real-time tracking
              </h2>
              <p className="text-xs text-zinc-400 mt-0.5">Filter customer orders, change fulfillment statuses, and generate PDF invoices.</p>
            </div>

            {/* Quick Export to Excel inside orders tab */}
            <button
              onClick={handleExportToExcel}
              className="flex items-center space-x-1.5 rounded-xl border border-zinc-200 bg-white px-3.5 py-2 text-xs font-bold text-zinc-600 hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-400 transition-all sm:hidden"
            >
              <FileSpreadsheet className="h-4 w-4" />
              <span>Export Excel</span>
            </button>
          </div>

          {/* Status Filters */}
          <div className="flex flex-wrap items-center gap-1.5" id="order-status-filters">
            <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 mr-2 flex items-center space-x-1">
              <Filter className="h-3.5 w-3.5" />
              <span>Filter Status:</span>
            </span>
            {(['All', 'Pending', 'Confirmed', 'Shipped', 'Delivered', 'Cancelled'] as const).map((status) => {
              const count = status === 'All' ? orders.length : orders.filter(o => o.status === status).length;
              return (
                <button
                  key={status}
                  onClick={() => setSelectedOrderStatusFilter(status)}
                  className={`px-3 py-1.5 rounded-full text-[10px] font-extrabold uppercase transition-all ${
                    selectedOrderStatusFilter === status
                      ? 'bg-brand-pink text-white shadow-sm'
                      : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200 dark:bg-zinc-900 dark:text-zinc-400 dark:hover:bg-zinc-800'
                  }`}
                >
                  {status} ({count})
                </button>
              );
            })}
          </div>

          {orders.length === 0 ? (
            <p className="text-xs text-zinc-500 italic py-10 text-center bg-white rounded-3xl border border-dashed dark:bg-zinc-900">No customer orders recorded yet.</p>
          ) : (
            (() => {
              const filteredOrders = selectedOrderStatusFilter === 'All'
                ? orders
                : orders.filter(o => o.status === selectedOrderStatusFilter);

              if (filteredOrders.length === 0) {
                return (
                  <p className="text-xs text-zinc-500 italic py-12 text-center bg-white rounded-3xl border border-dashed dark:bg-zinc-900">
                    No customer orders match the "{selectedOrderStatusFilter}" status.
                  </p>
                );
              }

              return (
                <div className="space-y-4" id="admin-orders-list-container">
                  {filteredOrders.map((ord) => (
                    <div
                      key={ord.id}
                      className="p-5 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 space-y-4 text-xs"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b pb-3 border-zinc-50 dark:border-zinc-800 gap-2">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-bold text-zinc-800 dark:text-white text-sm">Order: {ord.id}</span>
                            <span className={`rounded-full px-2 py-0.5 text-[8px] font-bold uppercase ${
                              ord.status === 'Pending' ? 'bg-amber-100 text-amber-800' :
                              ord.status === 'Confirmed' ? 'bg-blue-100 text-blue-800' :
                              ord.status === 'Shipped' ? 'bg-indigo-100 text-indigo-800' :
                              ord.status === 'Delivered' ? 'bg-emerald-100 text-emerald-800' :
                              'bg-rose-100 text-rose-800'
                            }`}>
                              {ord.status}
                            </span>
                          </div>
                          <span className="block text-[10px] text-zinc-400 mt-1">Placed: {ord.orderDate}</span>
                        </div>

                        <div className="flex items-center space-x-3">
                          <span className="font-extrabold text-zinc-900 dark:text-white">Grand Total: ₹{ord.grandTotal}</span>
                          
                          {/* Change Order Status Dropdown! */}
                          <select
                            value={ord.status}
                            id={`status-select-${ord.id}`}
                            onChange={(e) => {
                              const nextStatus = e.target.value as Order['status'];
                              let desc = `Order status updated to ${nextStatus}.`;
                              if (nextStatus === 'Confirmed') desc = 'Payment details and address verified. Order under preparation.';
                              if (nextStatus === 'Shipped') desc = 'Handmade products packed securely and handed over to delivery executive.';
                              if (nextStatus === 'Delivered') desc = 'Package successfully handed over to customer. Thank you!';
                              onUpdateOrderStatus(ord.id, nextStatus, desc);
                            }}
                            className="h-8 rounded-lg border border-zinc-200 px-2.5 font-bold outline-none focus:border-brand-pink bg-white text-zinc-900 dark:bg-zinc-800 dark:border-zinc-700 dark:text-zinc-100"
                          >
                            <option value="Pending" className="bg-white text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100">Pending Validation</option>
                            <option value="Confirmed" className="bg-white text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100">Confirmed / In-making</option>
                            <option value="Shipped" className="bg-white text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100">Shipped / Dispatched</option>
                            <option value="Delivered" className="bg-white text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100">Delivered successfully</option>
                            <option value="Cancelled" className="bg-white text-zinc-900 dark:bg-zinc-800 dark:text-zinc-100">Cancelled / Refunded</option>
                          </select>

                          {/* Invoice Generation Button */}
                          <button
                            onClick={() => setSelectedInvoiceOrder(ord)}
                            className="inline-flex items-center space-x-1 rounded-lg border border-pink-100 bg-pink-50/50 px-2.5 h-8 font-bold text-brand-pink hover:bg-brand-pink hover:text-white dark:border-zinc-800 dark:bg-zinc-800 dark:text-pink-400 dark:hover:bg-brand-pink dark:hover:text-white transition-all"
                            title="View & Download PDF Invoice"
                          >
                            <Eye className="h-3.5 w-3.5" />
                            <span className="hidden md:inline">Invoice</span>
                          </button>
                        </div>
                      </div>

                      {/* Customer shipping details */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-left p-3 rounded-2xl bg-zinc-50 dark:bg-zinc-950/30">
                        <div>
                          <span className="block font-bold uppercase tracking-wider text-zinc-400 text-[9px] mb-1">Shipping Destination:</span>
                          <strong className="block text-zinc-800 dark:text-zinc-200">{ord.address.fullName} ({ord.address.phoneNumber})</strong>
                          <p className="text-zinc-500 mt-0.5">
                            {ord.address.fullAddress}, Near {ord.address.landmark}, {ord.address.district}, {ord.address.state} - {ord.address.pinCode}
                          </p>
                          {ord.address.deliveryNote && (
                            <p className="text-[10px] text-zinc-400 mt-1 italic">Note: {ord.address.deliveryNote}</p>
                          )}
                        </div>

                        <div>
                          <span className="block font-bold uppercase tracking-wider text-zinc-400 text-[9px] mb-1">Ordered Items:</span>
                          <ul className="space-y-1">
                            {ord.items.map((item, iIdx) => (
                              <li key={iIdx} className="font-semibold text-zinc-700 dark:text-zinc-300">
                                • {item.product.name} ({item.selectedColor}) x{item.quantity} - ₹{(item.product.discountPrice || item.product.price) * item.quantity}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                    </div>
                  ))}
                </div>
              );
            })()
          )}
        </div>
      )}

      {/* 4. MANAGE CUSTOMERS */}
      {adminTab === 'customers' && (
        <div className="space-y-6" id="admin-customers-tab">
          <h2 className="font-display text-base font-bold text-zinc-800 dark:text-white border-b border-zinc-100 pb-2 dark:border-zinc-800">
            Registered Customers Database
          </h2>

          <div className="rounded-3xl border border-zinc-100 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-900 overflow-x-auto">
            <table className="w-full text-xs text-left" id="admin-customers-table">
              <thead>
                <tr className="border-b text-zinc-400 font-bold uppercase tracking-wider">
                  <th className="pb-3">Customer ID</th>
                  <th className="pb-3">Name</th>
                  <th className="pb-3">Email Address</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3 text-right">Orders value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-50 dark:divide-zinc-800">
                {users.map((usr) => {
                  const userOrders = orders.filter(o => 
                    o.userId === usr.id || 
                    (o.userEmail && o.userEmail.toLowerCase() === usr.email.toLowerCase()) ||
                    o.address.fullName === usr.name ||
                    (usr.savedAddress?.phoneNumber && o.address.phoneNumber === usr.savedAddress.phoneNumber)
                  );
                  const userSpend = userOrders.reduce((sum, o) => sum + o.grandTotal, 0);

                  return (
                    <tr key={usr.id} className="hover:bg-zinc-50/50">
                      <td className="py-3 font-mono font-medium text-zinc-500">{usr.id}</td>
                      <td className="py-3 font-bold text-zinc-800 dark:text-white">{usr.name}</td>
                      <td className="py-3 text-zinc-500">{usr.email}</td>
                      <td className="py-3">
                        <span className="rounded-full bg-emerald-100 text-emerald-800 px-2 py-0.5 text-[9px] font-bold uppercase">
                          Active member
                        </span>
                      </td>
                      <td className="py-3 text-right font-extrabold text-zinc-900 dark:text-white">
                        ₹{userSpend} ({userOrders.length} orders)
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. COUPON MANAGEMENT */}
      {adminTab === 'coupons' && (
        <div className="grid grid-cols-1 gap-8 md:grid-cols-12" id="admin-coupons-tab">
          
          {/* Create Coupon Form (md:span-5) */}
          <div className="md:col-span-5 p-6 rounded-3xl border border-pink-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
            <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-2 border-b">
              Create Discount Coupon
            </h3>

            <form onSubmit={handleCouponSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Coupon Code (Unique)
                </label>
                <input
                  type="text"
                  placeholder="e.g. MONSOON30"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink uppercase font-bold"
                  id="coupon-code-input"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Discount Type (e.g. percentage, fixed, % or any text)
                </label>
                <input
                  type="text"
                  placeholder="e.g. percentage or fixed"
                  value={couponType}
                  onChange={(e) => setCouponType(e.target.value)}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink"
                  id="coupon-type-input"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Discount Value
                </label>
                <input
                  type="number"
                  placeholder="e.g. 20"
                  value={couponVal || ''}
                  onChange={(e) => setCouponVal(Number(e.target.value))}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink"
                  id="coupon-value-input"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Minimum Purchase (₹, Optional)
                </label>
                <input
                  type="number"
                  placeholder="e.g. 500"
                  value={couponMin || ''}
                  onChange={(e) => setCouponMin(e.target.value ? Number(e.target.value) : undefined)}
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink"
                  id="coupon-min-input"
                />
              </div>

              <button
                type="submit"
                id="create-coupon-btn"
                className="w-full h-10 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark transition-colors"
              >
                Generate Coupon Code
              </button>
            </form>
          </div>

          {/* List Coupons (md:span-7) */}
          <div className="md:col-span-7 p-6 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
            <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-2 border-b">
              Active Store Coupons
            </h3>

            <div className="space-y-3.5" id="admin-coupons-list">
              {coupons.map((c) => (
                <div
                  key={c.code}
                  className="flex items-center justify-between p-3.5 rounded-2xl bg-zinc-50 border dark:bg-zinc-950/20 dark:border-zinc-800"
                >
                  <div className="text-left">
                    <div className="flex items-center space-x-1.5 text-brand-pink font-bold text-xs">
                      <Tag className="h-4 w-4" />
                      <span>{c.code}</span>
                    </div>
                    <span className="block text-[10px] text-zinc-500 mt-1">
                      Discount: {c.discountType.toLowerCase().includes('percent') || c.discountType === '%' ? `${c.discountValue}% Off` : `₹${c.discountValue} Off (${c.discountType})`}
                      {c.minPurchase ? ` • Min Spend: ₹${c.minPurchase}` : ''}
                    </span>
                  </div>

                  <button
                    onClick={() => onDeleteCoupon(c.code)}
                    className="p-1 text-zinc-400 hover:text-red-500"
                    title="Delete Coupon"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>

        </div>
      )}

      {/* 6. MANAGE CATEGORIES */}
      {adminTab === 'categories' && (
        <div className="grid grid-cols-1 gap-8 md:grid-cols-12" id="admin-categories-tab">
          
          {/* Create Category (md:span-5) */}
          <div className="md:col-span-5 p-6 rounded-3xl border border-pink-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
            <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-2 border-b">
              Append Custom Category
            </h3>

            <form onSubmit={handleCategorySubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Category Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Winter Scarves"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
                  id="category-add-input"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                  Category Photo URL (ফটো লিংক - ঐচ্ছিক)
                </label>
                <input
                  type="url"
                  placeholder="e.g. https://images.unsplash.com/photo-..."
                  value={newCategoryPhoto}
                  onChange={(e) => setNewCategoryPhoto(e.target.value)}
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
                  id="category-photo-add-input"
                />
              </div>

              <button
                type="submit"
                id="create-category-btn"
                className="w-full h-10 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark"
              >
                Create Category
              </button>
            </form>
          </div>

          {/* List Categories (md:span-7) */}
          <div className="md:col-span-7 p-6 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
            <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-2 border-b">
              Current Category Directory
            </h3>

            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2" id="admin-categories-list">
              {categories.map((cat, idx) => {
                const catImg = categoryImages?.[cat] || 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=150';
                return (
                  <div
                    key={idx}
                    className="p-3.5 rounded-2xl bg-zinc-50 border text-xs font-bold text-zinc-700 flex flex-col gap-2 dark:bg-zinc-950/20 dark:border-zinc-800 dark:text-zinc-300"
                  >
                    <div className="flex items-center space-x-3">
                      <div className="h-10 w-10 overflow-hidden rounded-full border bg-white shrink-0 dark:border-zinc-800">
                        <img 
                          src={catImg} 
                          alt={cat} 
                          referrerPolicy="no-referrer" 
                          className="h-full w-full object-cover"
                          onError={(e) => {
                            e.currentTarget.src = "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=150";
                          }}
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-zinc-800 dark:text-white font-bold truncate">{cat}</span>
                          <span className="text-[10px] text-zinc-400 font-normal shrink-0 ml-1">
                            {products.filter(p => p.category === cat).length} items
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between border-t border-zinc-100 dark:border-zinc-800/80 pt-2 gap-2 mt-1">
                      <div className="flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => setActiveCategoryManage(activeCategoryManage === cat ? null : cat)}
                          className={`px-2 py-1 rounded-lg text-[9px] font-bold transition-all flex items-center space-x-1 ${
                            activeCategoryManage === cat 
                              ? 'bg-brand-pink text-white shadow-sm' 
                              : 'bg-white hover:bg-zinc-100 text-zinc-600 border dark:bg-zinc-900 dark:border-zinc-800 dark:text-zinc-400 dark:hover:bg-zinc-800'
                          }`}
                        >
                          <Plus className="h-2.5 w-2.5" />
                          <span>{activeCategoryManage === cat ? 'Close' : 'Items'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            if (editingCategoryForImage === cat) {
                              setEditingCategoryForImage(null);
                            } else {
                              setEditingCategoryForImage(cat);
                              setEditingImageText(categoryImages?.[cat] || '');
                            }
                          }}
                          className={`px-2 py-1 rounded-lg text-[9px] font-bold transition-all flex items-center space-x-1 ${
                            editingCategoryForImage === cat 
                              ? 'bg-indigo-600 text-white shadow-sm' 
                              : 'bg-white hover:bg-zinc-100 text-zinc-600 border dark:bg-zinc-900 dark:border-zinc-800 dark:text-zinc-400 dark:hover:bg-zinc-800'
                          }`}
                        >
                          <Image className="h-2.5 w-2.5" />
                          <span>Edit Photo</span>
                        </button>
                      </div>

                      {categoryConfirmDeleteName === cat ? (
                        <div className="flex items-center space-x-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              onDeleteCategory(cat);
                              setCategoryConfirmDeleteName(null);
                              if (activeCategoryManage === cat) {
                                setActiveCategoryManage(null);
                              }
                            }}
                            className="px-2 py-1 rounded bg-red-600 text-white font-bold text-[9px] hover:bg-red-700 transition-colors"
                          >
                            Confirm
                          </button>
                          <button
                            type="button"
                            onClick={() => setCategoryConfirmDeleteName(null)}
                            className="px-2 py-1 rounded border bg-white text-zinc-500 text-[9px] hover:bg-zinc-50 dark:bg-zinc-800 dark:text-zinc-300 transition-colors"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          type="button"
                          onClick={() => setCategoryConfirmDeleteName(cat)}
                          className="p-1 rounded bg-red-50 hover:bg-red-100 text-red-500 dark:bg-red-950/20 dark:text-red-400 dark:hover:bg-red-950/40 transition-colors cursor-pointer shrink-0"
                          title="Delete Category"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>

                    {/* Inline category image edit form */}
                    {editingCategoryForImage === cat && (
                      <div className="mt-2.5 p-2 border-t border-zinc-100 dark:border-zinc-800/80 pt-2 flex flex-col gap-1.5 w-full">
                        <label className="text-[9px] font-bold uppercase text-zinc-400 dark:text-zinc-500">
                          Edit Photo URL (ফটো লিংক):
                        </label>
                        <div className="flex gap-1.5">
                          <input
                            type="url"
                            value={editingImageText}
                            onChange={(e) => setEditingImageText(e.target.value)}
                            placeholder="https://images.unsplash.com/..."
                            className="h-8 flex-1 min-w-0 rounded-lg border border-zinc-200 px-2 text-[10px] outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white font-normal"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              if (onUpdateCategoryImage) {
                                onUpdateCategoryImage(cat, editingImageText.trim());
                                alert(`Category photo updated for "${cat}"!`);
                              }
                              setEditingCategoryForImage(null);
                            }}
                            className="h-8 px-2.5 rounded-lg bg-green-600 hover:bg-green-700 text-white text-[10px] font-bold shrink-0"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Inline Category Items Assign manager */}
            {activeCategoryManage && (
              <div className="mt-6 p-5 rounded-3xl border border-pink-100 bg-pink-50/20 dark:bg-zinc-950/40 dark:border-zinc-800 text-left">
                <div className="flex items-center justify-between mb-3 border-b border-pink-100/30 pb-2 dark:border-zinc-800">
                  <div>
                    <h4 className="text-xs font-bold text-zinc-800 dark:text-white uppercase tracking-wider flex items-center space-x-1">
                      <span>Add/Remove items for:</span>
                      <span className="text-brand-pink font-extrabold">{activeCategoryManage}</span>
                    </h4>
                    <p className="text-[10px] text-zinc-400 font-normal mt-0.5">Toggle cards to instantly assign or unassign products to this category.</p>
                  </div>
                  <button 
                    onClick={() => setActiveCategoryManage(null)} 
                    className="text-[10px] font-bold text-zinc-400 hover:text-zinc-600 uppercase bg-white px-2.5 py-1 rounded-full border shadow-sm dark:bg-zinc-900 dark:border-zinc-800"
                  >
                    Close
                  </button>
                </div>

                <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 max-h-72 overflow-y-auto pr-1">
                  {products.map(p => {
                    const isAssigned = p.category === activeCategoryManage;
                    return (
                      <div 
                        key={p.id} 
                        onClick={() => {
                          if (isAssigned) {
                            // Assign to default first category or empty
                            onEditProduct({ ...p, category: categories.find(c => c !== activeCategoryManage) || '' });
                          } else {
                            onEditProduct({ ...p, category: activeCategoryManage });
                          }
                        }}
                        className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer ${
                          isAssigned 
                            ? 'bg-white border-brand-pink dark:bg-zinc-900/60' 
                            : 'bg-white/50 border-zinc-100 hover:bg-white dark:bg-zinc-900/20 dark:border-zinc-850 dark:hover:bg-zinc-800/40'
                        }`}
                      >
                        <div className="flex items-center space-x-2.5 min-w-0">
                          <input
                            type="checkbox"
                            checked={isAssigned}
                            readOnly
                            className="rounded text-brand-pink focus:ring-brand-pink h-3.5 w-3.5"
                          />
                          <div className="text-left min-w-0">
                            <span className="block text-xs font-bold text-zinc-800 dark:text-white truncate">{p.name}</span>
                            <span className="block text-[9px] text-zinc-400 mt-0.5">Current Cat: <strong className="text-zinc-500">{p.category || 'None'}</strong></span>
                          </div>
                        </div>
                        <img src={p.images[0]} alt="" referrerPolicy="no-referrer" className="h-8 w-8 rounded-lg object-cover bg-zinc-50 border shrink-0" />
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

        </div>
      )}

      {/* 7. GOOGLE SHEETS INTEGRATION */}
      {adminTab === 'sheets' && (
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-12" id="admin-sheets-tab">
          
          {/* Column 1: Connection & Settings (lg:col-span-5) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Google Authentication Card */}
            <div className="p-6 rounded-3xl border border-pink-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 text-left">
              <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-2 border-b flex items-center space-x-2">
                <Cloud className="h-4 w-4 text-brand-pink" />
                <span>1. Google Account Authorization</span>
              </h3>

              {googleUser ? (
                <div className="space-y-4">
                  <div className="flex items-center space-x-3.5 bg-zinc-50 dark:bg-zinc-950/20 p-3.5 rounded-2xl border dark:border-zinc-800">
                    {googleUser.photoURL ? (
                      <img
                        src={googleUser.photoURL}
                        alt="Profile"
                        referrerPolicy="no-referrer"
                        className="h-10 w-10 rounded-full border border-pink-100"
                      />
                    ) : (
                      <div className="h-10 w-10 rounded-full bg-pink-100 text-brand-pink flex items-center justify-center font-bold">
                        {googleUser.displayName?.[0] || 'G'}
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold text-zinc-800 dark:text-white truncate">
                        {googleUser.displayName || 'Authorized Admin'}
                      </p>
                      <p className="text-[10px] text-zinc-400 truncate">{googleUser.email}</p>
                    </div>
                    <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500" title="Connected" />
                  </div>

                  <p className="text-[11px] text-zinc-500 leading-relaxed">
                    You are signed in and authorized. Your app is ready to push real-time orders directly to your Google Sheets.
                  </p>

                  <button
                    onClick={handleGoogleLogout}
                    className="w-full h-10 rounded-full border border-red-200 bg-red-50 text-xs font-bold text-red-600 hover:bg-red-100 dark:border-red-900/30 dark:bg-red-950/10 dark:text-red-400 transition-colors"
                  >
                    Disconnect Google Account
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-xs text-zinc-500 leading-relaxed">
                    Authorize this application with Google to push order data and customer leads to your spreadsheet. No database server required!
                  </p>
                  
                  <button
                    onClick={handleGoogleLogin}
                    className="w-full h-10 rounded-full bg-brand-purple hover:bg-brand-purple-dark text-xs font-bold text-white shadow-sm flex items-center justify-center space-x-2 transition-all"
                  >
                    <LogIn className="h-4 w-4" />
                    <span>Authorize Google Sheets & Drive</span>
                  </button>
                </div>
              )}
            </div>

            {/* Google Sheets Configuration */}
            <div className="p-6 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 text-left">
              <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-2 border-b flex items-center space-x-2">
                <Settings className="h-4 w-4 text-brand-pink" />
                <span>2. Spreadsheet Configuration</span>
              </h3>

              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                    Google Spreadsheet ID
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Enter Spreadsheet ID"
                      value={spreadsheetId}
                      onChange={(e) => handleSaveSpreadsheetId(e.target.value)}
                      className="h-10 flex-1 rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:bg-zinc-950 dark:border-zinc-800 dark:text-white"
                      title="Spreadsheet ID can be found in the URL of your Google Sheet: https://docs.google.com/spreadsheets/d/[SPREADSHEET_ID]/edit"
                    />
                    {spreadsheetId && (
                      <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 border border-emerald-100 text-emerald-600 dark:bg-emerald-950/10 dark:border-emerald-900/30 dark:text-emerald-400">
                        <Check className="h-4 w-4" />
                      </span>
                    )}
                  </div>
                  <p className="text-[10px] text-zinc-400 mt-1 leading-relaxed">
                    Found in the sheet URL: docs.google.com/spreadsheets/d/<strong>[SPREADSHEET_ID]</strong>/edit
                  </p>
                </div>

                <div className="relative flex items-start py-1">
                  <div className="flex h-5 items-center">
                    <input
                      id="auto-sync-toggle"
                      type="checkbox"
                      checked={autoSyncEnabled}
                      onChange={(e) => handleToggleAutoSync(e.target.checked)}
                      className="h-4 w-4 rounded border-zinc-300 text-brand-pink focus:ring-brand-pink"
                    />
                  </div>
                  <div className="ml-3 text-xs">
                    <label htmlFor="auto-sync-toggle" className="font-bold text-zinc-700 dark:text-zinc-300">
                      Enable Real-Time Auto-Sync
                    </label>
                    <p className="text-[10px] text-zinc-400 leading-relaxed">
                      Push order details automatically as soon as a customer completes their checkout!
                    </p>
                  </div>
                </div>

                <div className="pt-2 border-t border-dashed dark:border-zinc-800">
                  <span className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-2">
                    Don't have a spreadsheet?
                  </span>
                  <button
                    onClick={handleCreateNewSheet}
                    disabled={!googleUser || isSyncing}
                    className="w-full h-10 rounded-full border border-brand-pink bg-pink-50 text-xs font-bold text-brand-pink hover:bg-pink-100 dark:bg-pink-950/10 dark:border-pink-900/40 dark:text-pink-400 disabled:opacity-50 transition-colors flex items-center justify-center space-x-2"
                  >
                    <FileSpreadsheet className="h-4 w-4" />
                    <span>Create Fresh Orders Spreadsheet</span>
                  </button>
                </div>
              </div>
            </div>

          </div>

          {/* Column 2: Orders Sync Dashboard & Log (lg:col-span-7) */}
          <div className="lg:col-span-7 p-6 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 text-left">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b pb-4 mb-6 dark:border-zinc-800">
              <div>
                <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white flex items-center space-x-2">
                  <FileSpreadsheet className="h-4.5 w-4.5 text-brand-pink" />
                  <span>Google Sheets Synchronization Log</span>
                </h3>
                <p className="text-[11px] text-zinc-400 mt-0.5">Audit and manually push missing orders to the cloud.</p>
              </div>

              <button
                onClick={handleSyncOrders}
                disabled={isSyncing || !googleUser || !spreadsheetId}
                className="flex items-center space-x-2 rounded-full bg-brand-pink px-4.5 h-9 text-xs font-bold text-white hover:bg-brand-pink-dark disabled:opacity-50 transition-colors"
              >
                {isSyncing ? (
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                ) : (
                  <RefreshCw className="h-3.5 w-3.5" />
                )}
                <span>Sync Pending Orders</span>
              </button>
            </div>

            {/* Sync Progress Alert */}
            {isSyncing && syncStatusMsg && (
              <div className="mb-4 bg-blue-50 border border-blue-100 text-blue-700 dark:bg-blue-950/10 dark:border-blue-900/30 dark:text-blue-400 p-3.5 rounded-2xl text-xs flex items-center space-x-2 animate-pulse">
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>{syncStatusMsg}</span>
              </div>
            )}

            {/* Micro Stats Row */}
            <div className="grid grid-cols-3 gap-3.5 mb-6 text-center">
              <div className="bg-zinc-50 dark:bg-zinc-950/10 p-3 rounded-2xl border dark:border-zinc-800">
                <span className="block text-[9px] font-bold text-zinc-400 uppercase tracking-wider">Total Orders</span>
                <span className="text-sm font-extrabold text-zinc-800 dark:text-white">{orders.length}</span>
              </div>
              <div className="bg-emerald-50/50 dark:bg-emerald-950/5 p-3 rounded-2xl border border-emerald-100/50 dark:border-emerald-900/10">
                <span className="block text-[9px] font-bold text-emerald-500 uppercase tracking-wider">Cloud Synced</span>
                <span className="text-sm font-extrabold text-emerald-600 dark:text-emerald-400">
                  {orders.filter(o => syncedOrderIds.includes(o.id)).length}
                </span>
              </div>
              <div className="bg-amber-50/50 dark:bg-amber-950/5 p-3 rounded-2xl border border-amber-100/50 dark:border-amber-900/10">
                <span className="block text-[9px] font-bold text-amber-500 uppercase tracking-wider">Un-synced</span>
                <span className="text-sm font-extrabold text-amber-600 dark:text-amber-400">
                  {orders.filter(o => !syncedOrderIds.includes(o.id)).length}
                </span>
              </div>
            </div>

            {/* Orders Table */}
            <div className="overflow-x-auto rounded-2xl border dark:border-zinc-800">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="bg-zinc-50 border-b border-zinc-100 text-zinc-400 font-bold uppercase tracking-wider text-[10px] dark:bg-zinc-950 dark:border-zinc-800">
                    <th className="p-3">Order Details</th>
                    <th className="p-3 text-center">Grand Total</th>
                    <th className="p-3 text-center">Sync Status</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800 font-medium">
                  {orders.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="p-8 text-center text-zinc-400 font-bold">
                        No orders recorded to synchronize yet.
                      </td>
                    </tr>
                  ) : (
                    orders.map((o) => {
                      const isSynced = syncedOrderIds.includes(o.id);
                      return (
                        <tr key={o.id} className="hover:bg-zinc-50/50 dark:hover:bg-zinc-900/20 text-zinc-700 dark:text-zinc-300">
                          <td className="p-3 max-w-[200px]">
                            <p className="font-bold text-zinc-900 dark:text-white truncate">#{o.id}</p>
                            <p className="text-[10px] text-zinc-500 truncate">{o.address.fullName}</p>
                            <p className="text-[9px] text-zinc-400 truncate">{o.orderDate}</p>
                          </td>
                          <td className="p-3 text-center font-bold text-zinc-900 dark:text-white">
                            ₹{o.grandTotal}
                          </td>
                          <td className="p-3 text-center">
                            {isSynced ? (
                              <span className="inline-flex items-center space-x-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full dark:bg-emerald-950/20 dark:text-emerald-400">
                                <Check className="h-3 w-3" />
                                <span>Synced</span>
                              </span>
                            ) : (
                              <span className="inline-flex items-center space-x-1 text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full dark:bg-amber-950/20 dark:text-amber-400">
                                <Cloud className="h-3 w-3" />
                                <span>Pending</span>
                              </span>
                            )}
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => handleSyncSingleOrder(o)}
                              disabled={isSynced || isSyncing || !googleUser || !spreadsheetId}
                              className="inline-flex items-center space-x-1 rounded-xl border border-zinc-200 bg-white px-3 py-1.5 text-[10px] font-bold text-zinc-700 hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-300 dark:hover:bg-zinc-800 disabled:opacity-30 disabled:hover:bg-transparent"
                              title={isSynced ? 'Already Synced' : 'Sync to Google Sheets'}
                            >
                              <RefreshCw className="h-3 w-3" />
                              <span>{isSynced ? 'Re-sync' : 'Sync'}</span>
                            </button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {adminTab === 'posters' && (
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-12" id="admin-posters-tab">
          
          {/* Column 1: Add Poster Form (lg:col-span-5) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-3xl border border-pink-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 text-left">
              <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-2 border-b flex items-center space-x-2">
                <Image className="h-4 w-4 text-brand-pink" />
                <span>Add New Poster / Banner</span>
              </h3>

              <div className="space-y-4">
                {posterError && (
                  <div className="p-3 rounded-xl bg-red-50 border border-red-100 text-red-600 text-xs font-semibold dark:bg-red-950/10 dark:border-red-900/30">
                    {posterError}
                  </div>
                )}

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                    Banner Title (Heading) *
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Beautiful Crochet Treasures"
                    value={posterTitle}
                    onChange={(e) => setPosterTitle(e.target.value)}
                    className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:bg-zinc-950 dark:border-zinc-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                    Subtitle (Badge Text)
                  </label>
                  <input
                    type="text"
                    placeholder="e.g. Handmade with Love, Custom Caricatures"
                    value={posterSubtitle}
                    onChange={(e) => setPosterSubtitle(e.target.value)}
                    className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:bg-zinc-950 dark:border-zinc-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                    Image URL *
                  </label>
                  <input
                    type="text"
                    placeholder="https://images.unsplash.com/... or any photo URL"
                    value={posterImage}
                    onChange={(e) => setPosterImage(e.target.value)}
                    className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:bg-zinc-950 dark:border-zinc-800 dark:text-white"
                  />
                  {posterImage && (
                    <div className="mt-2 relative aspect-[2/1] rounded-2xl border overflow-hidden bg-zinc-50 dark:bg-zinc-950/20">
                      <img
                        src={posterImage}
                        alt="Preview"
                        onError={(e) => {
                          e.currentTarget.src = "https://placehold.co/600x300/pink/white?text=Invalid+Image+URL";
                        }}
                        className="h-full w-full object-cover"
                      />
                      <span className="absolute bottom-1 right-1 px-1.5 py-0.5 text-[8px] uppercase font-bold text-white bg-zinc-900/60 rounded">Image Preview</span>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                    Description *
                  </label>
                  <textarea
                    placeholder="Write a catchy short description about this banner..."
                    value={posterDescription}
                    onChange={(e) => setPosterDescription(e.target.value)}
                    rows={3}
                    className="w-full rounded-xl border border-zinc-200 p-3 text-xs outline-none focus:border-brand-pink dark:bg-zinc-950 dark:border-zinc-800 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-2">
                    Banner Layout Design (ব্যানার লেআউট)
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setPosterLayout('full')}
                      className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        posterLayout === 'full'
                          ? 'border-brand-pink bg-pink-50/50 text-brand-pink dark:bg-pink-950/10 dark:border-pink-900/40'
                          : 'border-zinc-200 hover:bg-zinc-50 text-zinc-500 dark:border-zinc-800 dark:hover:bg-zinc-800/40'
                      }`}
                    >
                      <span className="text-xs font-bold">Full Banner (ফুল স্ক্রিন)</span>
                      <span className="text-[9px] mt-0.5">Image covers whole slide</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPosterLayout('split')}
                      className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition-all cursor-pointer ${
                        posterLayout === 'split'
                          ? 'border-brand-pink bg-pink-50/50 text-brand-pink dark:bg-pink-950/10 dark:border-pink-900/40'
                          : 'border-zinc-200 hover:bg-zinc-50 text-zinc-500 dark:border-zinc-800 dark:hover:bg-zinc-800/40'
                      }`}
                    >
                      <span className="text-xs font-bold">Split Layout (বিভক্ত)</span>
                      <span className="text-[9px] mt-0.5">Text left, image card right</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                      Button Link Tab
                    </label>
                    <select
                      value={posterLinkTab}
                      onChange={(e) => setPosterLinkTab(e.target.value)}
                      className="h-10 w-full rounded-xl border border-zinc-200 px-2 text-xs outline-none focus:border-brand-pink dark:bg-zinc-950 dark:border-zinc-800 dark:text-white"
                    >
                      <option value="home">Homepage</option>
                      <option value="shop">Shop Tab</option>
                      <option value="custom-order">Custom Order Tab</option>
                      <option value="categories">Categories Tab</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                      Button Text
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Shop Now"
                      value={posterButtonText}
                      onChange={(e) => setPosterButtonText(e.target.value)}
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:bg-zinc-950 dark:border-zinc-800 dark:text-white"
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    if (!posterTitle.trim() || !posterImage.trim() || !posterDescription.trim()) {
                      setPosterError('Please fill in Title, Image URL, and Description.');
                      return;
                    }
                    setPosterError('');
                    const newPoster: Poster = {
                      id: `poster-${Date.now()}`,
                      title: posterTitle.trim(),
                      subtitle: posterSubtitle.trim(),
                      image: posterImage.trim(),
                      description: posterDescription.trim(),
                      linkTab: posterLinkTab,
                      buttonText: posterButtonText.trim() || 'Explore',
                      layout: posterLayout,
                      isCustom: true
                    };
                    onAddPoster(newPoster);
                    
                    // Reset fields
                    setPosterTitle('');
                    setPosterSubtitle('');
                    setPosterImage('');
                    setPosterDescription('');
                    setPosterLinkTab('shop');
                    setPosterButtonText('Shop Now');
                    setPosterLayout('full');
                    alert('Poster added successfully!');
                  }}
                  className="w-full h-11 rounded-full bg-brand-pink hover:bg-brand-pink-dark text-xs font-bold text-white transition-colors shadow-sm flex items-center justify-center space-x-2"
                >
                  <Plus className="h-4 w-4" />
                  <span>Publish Poster</span>
                </button>
              </div>
            </div>
          </div>

          {/* Column 2: Poster Slides List (lg:col-span-7) */}
          <div className="lg:col-span-7 p-6 rounded-3xl border border-zinc-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 text-left">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b pb-4 mb-6 dark:border-zinc-800">
              <div>
                <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white flex items-center space-x-2">
                  <Image className="h-4.5 w-4.5 text-brand-pink" />
                  <span>Active Front Banners & Posters ({posters.length})</span>
                </h3>
                <p className="text-[11px] text-zinc-400 mt-0.5">Manage the slides that appear on the homepage slider.</p>
              </div>
            </div>

            <div className="space-y-4">
              {posters.length === 0 ? (
                <div className="p-8 text-center text-zinc-400 border border-dashed rounded-3xl">
                  No active banners. The slideshow will be empty! Add a new poster to get started.
                </div>
              ) : (
                posters.map((poster, index) => (
                  <div
                    key={poster.id}
                    className="flex flex-col sm:flex-row gap-4 p-4 rounded-2xl border border-zinc-100 bg-zinc-50/50 dark:border-zinc-800 dark:bg-zinc-950/20 hover:border-pink-100 dark:hover:border-zinc-700 transition-all"
                  >
                    {/* Thumbnail / Image */}
                    <div className="w-full sm:w-28 aspect-[16/9] sm:aspect-square rounded-xl overflow-hidden bg-white border shrink-0">
                      {poster.id === 'thekua-slide' ? (
                        <div className="w-full h-full bg-gradient-to-br from-amber-700 to-amber-900 flex items-center justify-center text-white text-[10px] font-bold uppercase tracking-wider text-center p-2">
                          Special TheKua Slide
                        </div>
                      ) : (
                        <img
                          src={poster.image}
                          alt={poster.title}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            e.currentTarget.src = "https://placehold.co/100x100/pink/white?text=No+Image";
                          }}
                        />
                      )}
                    </div>

                    {/* Content Detail */}
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] font-black uppercase text-zinc-400">Slide {index + 1}</span>
                        {poster.id === 'thekua-slide' && (
                          <span className="px-1.5 py-0.5 rounded text-[8px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950/40 dark:text-amber-400">Custom Code Vector Layout</span>
                        )}
                        {!poster.isCustom ? (
                          <span className="px-1.5 py-0.5 rounded text-[8px] font-bold bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400">Default Built-in</span>
                        ) : (
                          <>
                            <span className="px-1.5 py-0.5 rounded text-[8px] font-bold bg-pink-100 text-pink-700 dark:bg-pink-950/40 dark:text-pink-400">Custom Poster</span>
                            <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold ${poster.layout === 'split' ? 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-400' : 'bg-teal-100 text-teal-700 dark:bg-teal-950/40 dark:text-teal-400'}`}>
                              {poster.layout === 'split' ? 'Split Layout' : 'Full Banner'}
                            </span>
                          </>
                        )}
                      </div>
                      <h4 className="font-bold text-xs sm:text-sm text-zinc-800 dark:text-white truncate">{poster.title}</h4>
                      {poster.subtitle && (
                        <p className="text-[10px] text-brand-pink font-semibold uppercase">{poster.subtitle}</p>
                      )}
                      <p className="text-[11px] text-zinc-500 dark:text-zinc-400 line-clamp-2 leading-relaxed">{poster.description}</p>
                      <div className="flex items-center gap-4 text-[10px] text-zinc-400 pt-1">
                        <span>Link Tab: <strong className="text-zinc-600 dark:text-zinc-300 uppercase">{poster.linkTab}</strong></span>
                        <span>Button: <strong className="text-zinc-600 dark:text-zinc-300">{poster.buttonText}</strong></span>
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex sm:flex-col justify-end items-center gap-2 shrink-0">
                      {posterConfirmDeleteId === poster.id ? (
                        <div className="flex flex-col gap-1 items-center">
                          <button
                            onClick={() => {
                              onDeletePoster(poster.id);
                              setPosterConfirmDeleteId(null);
                            }}
                            className="px-2.5 py-1 rounded-xl bg-red-600 text-white font-bold text-[10px] hover:bg-red-700 transition-colors cursor-pointer"
                          >
                            Confirm Delete
                          </button>
                          <button
                            onClick={() => setPosterConfirmDeleteId(null)}
                            className="px-2.5 py-1 rounded-xl border bg-white dark:bg-zinc-800 dark:border-zinc-700 text-zinc-500 text-[10px] hover:bg-zinc-50 transition-colors cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setPosterConfirmDeleteId(poster.id)}
                          className="h-8 w-8 rounded-full bg-red-50 text-red-600 hover:bg-red-100 dark:bg-red-950/20 dark:text-red-400 flex items-center justify-center transition-colors cursor-pointer"
                          title="Delete Poster"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      )}

      {adminTab === 'settings' && (
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 text-left animate-fade-in" id="admin-settings-tab">
          
          {/* Column 1: Brand & Payment Assets (lg:col-span-7) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="p-6 rounded-3xl border border-pink-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
              <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-2 border-b flex items-center space-x-2">
                <Sparkles className="h-4.5 w-4.5 text-brand-pink" />
                <span>Custom Store Brand Identity</span>
              </h3>
              
              <div className="space-y-5">
                {/* Store Logo Input */}
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                    Store Logo Image URL
                  </label>
                  <p className="text-[10px] text-zinc-400 mb-2">Provide a custom brand logo image URL to replace the default banner logo in the Navbar.</p>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="https://images.unsplash.com/... or any photo URL"
                      value={inputLogoUrl}
                      onChange={(e) => setInputLogoUrl(e.target.value)}
                      className="h-10 flex-1 rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:bg-zinc-950 dark:border-zinc-800 dark:text-white"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        onUpdateLogo(inputLogoUrl.trim());
                        alert('Store Logo updated successfully!');
                      }}
                      className="h-10 px-4 rounded-xl bg-brand-pink hover:bg-brand-pink-dark text-xs font-bold text-white transition-colors cursor-pointer"
                    >
                      Save
                    </button>
                  </div>
                </div>

                {/* Logo Preview */}
                <div className="p-4 rounded-2xl bg-zinc-50 border border-zinc-100 dark:bg-zinc-950/20 dark:border-zinc-800 flex items-center justify-between">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">Live Logo Preview</span>
                    <span className="text-[11px] text-zinc-500">This logo is displayed in the navigation headers of the website.</span>
                  </div>
                  <div className="h-12 w-28 rounded-lg overflow-hidden border bg-white flex items-center justify-center p-1 shrink-0">
                    <img
                      src={inputLogoUrl || 'https://images.unsplash.com/photo-1608248597481-496100c80836?auto=format&fit=crop&q=80&w=240&h=120'}
                      alt="Brand Logo"
                      className="h-full w-full object-cover rounded"
                      onError={(e) => {
                        e.currentTarget.src = "https://placehold.co/240x120/pink/white?text=SG";
                      }}
                    />
                  </div>
                </div>

                <hr className="border-pink-50 dark:border-zinc-800" />

                {/* Payment QR Code Input */}
                <div>
                  <h4 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-2 flex items-center space-x-2">
                    <CreditCard className="h-4 w-4 text-brand-purple" />
                    <span>Store Payment QR Code</span>
                  </h4>
                  <p className="text-[11px] text-zinc-400 mb-3">Upload or paste an image URL of your custom Google Pay, PhonePe, or Paytm payment QR code. If left blank, the store automatically generates a dynamic UPI scan-to-pay QR code.</p>
                  
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. Paste direct link to QR code image"
                      value={inputQrCodeUrl}
                      onChange={(e) => setInputQrCodeUrl(e.target.value)}
                      className="h-10 flex-1 rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:bg-zinc-950 dark:border-zinc-800 dark:text-white"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        onUpdateQrCode(inputQrCodeUrl.trim());
                        alert('Payment QR Code saved successfully!');
                      }}
                      className="h-10 px-4 rounded-xl bg-brand-pink hover:bg-brand-pink-dark text-xs font-bold text-white transition-colors cursor-pointer"
                    >
                      Save
                    </button>
                  </div>
                </div>

                {/* QR Preview Card */}
                <div className="p-4 rounded-2xl bg-zinc-50 border border-zinc-100 dark:bg-zinc-950/20 dark:border-zinc-800 flex flex-col md:flex-row items-center gap-4">
                  <div className="flex-1 space-y-1 text-left">
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block">QR Code Preview</span>
                    <p className="text-[11px] text-zinc-500 leading-relaxed">
                      {inputQrCodeUrl 
                        ? "Currently displaying your uploaded static QR Code image during checkout." 
                        : "Using dynamic UPI payments generator. Scanning this will directly request the checkout grand total sent to 9339483660@fam."}
                    </p>
                    {!inputQrCodeUrl && (
                      <span className="inline-block mt-2 px-2.5 py-1 text-[9px] font-bold uppercase bg-brand-purple-light text-brand-purple dark:bg-purple-950/40 dark:text-purple-400 rounded-full">
                        ✨ Dynamic UPI Mode Active
                      </span>
                    )}
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border w-28 h-28 shrink-0 flex items-center justify-center">
                    <img
                      src={inputQrCodeUrl || 'https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=upi://pay?pa=9339483660@fam%26pn=Selai%20Ghor%26am=999%26cu=INR'}
                      alt="QR Preview"
                      className="h-full w-full object-contain"
                      onError={(e) => {
                        e.currentTarget.src = "https://placehold.co/180x180/pink/white?text=Invalid+QR";
                      }}
                    />
                  </div>
                </div>

              </div>
            </div>
          </div>

          {/* Column 2: Admin Password Access Security Settings (lg:col-span-5) */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-3xl border border-pink-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
              <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-2 border-b flex items-center space-x-2">
                <ShieldCheck className="h-4.5 w-4.5 text-brand-pink" />
                <span>Admin Password Access Security</span>
              </h3>
              
              <div className="space-y-4">
                {newPasswordSuccess && (
                  <div className="p-3.5 rounded-xl bg-green-50 border border-green-100 text-green-700 text-xs font-semibold dark:bg-green-950/10 dark:border-green-900/30">
                    {newPasswordSuccess}
                  </div>
                )}
                {newPasswordError && (
                  <div className="p-3.5 rounded-xl bg-red-50 border border-red-100 text-red-600 text-xs font-semibold dark:bg-red-950/10 dark:border-red-900/30">
                    {newPasswordError}
                  </div>
                )}

                <div>
                  <span className="block text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Current Active Password</span>
                  <div className="h-10 px-3 flex items-center justify-between rounded-xl bg-zinc-50 border border-zinc-100 text-xs font-mono font-bold text-zinc-700 dark:bg-zinc-950 dark:border-zinc-800 dark:text-zinc-300">
                    <span>{customPassword}</span>
                    <span className="text-[8px] uppercase tracking-wider font-sans bg-zinc-200 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400 px-1.5 py-0.5 rounded">Active</span>
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                    Set New Secure Password
                  </label>
                  <p className="text-[10px] text-zinc-400 mb-2">Update the password required to access this admin panel. Must be at least 4 characters long.</p>
                  <input
                    type="password"
                    placeholder="e.g. Enter new password"
                    value={newPasswordInput}
                    onChange={(e) => {
                      setNewPasswordInput(e.target.value);
                      setNewPasswordSuccess('');
                      setNewPasswordError('');
                    }}
                    className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:bg-zinc-950 dark:border-zinc-800 dark:text-white"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => {
                    const pass = newPasswordInput.trim();
                    if (!pass || pass.length < 4) {
                      setNewPasswordError('Password must be at least 4 characters long.');
                      return;
                    }
                    localStorage.setItem('sg_admin_password', pass);
                    setCustomPassword(pass);
                    setNewPasswordInput('');
                    setNewPasswordSuccess('Admin access password updated successfully! Keep it recorded.');
                  }}
                  className="w-full h-11 rounded-full bg-brand-pink hover:bg-brand-pink-dark text-xs font-bold text-white transition-colors shadow-sm cursor-pointer"
                >
                  Update Admin Password
                </button>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* Invoice Modal Overlay */}
      {selectedInvoiceOrder && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" id="invoice-modal">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white dark:bg-zinc-900 border dark:border-zinc-800 shadow-2xl p-6 sm:p-8"
          >
            {/* Close button */}
            <button
              onClick={() => setSelectedInvoiceOrder(null)}
              className="absolute top-4 right-4 p-2 text-zinc-400 hover:text-zinc-600 dark:hover:text-white transition-colors"
              title="Close invoice"
            >
              <X className="h-5 w-5" />
            </button>

            {/* Printable Area starts here */}
            <div id="invoice-print-area" className="text-zinc-800 dark:text-zinc-100 p-2 text-left">
              {/* Invoice Header */}
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-start border-b pb-6 border-zinc-100 dark:border-zinc-800 gap-4">
                <div>
                  <div className="flex items-center space-x-2">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-pink-100 text-brand-pink font-bold text-lg dark:bg-pink-950/40">
                      S
                    </div>
                    <span className="font-display text-xl font-bold tracking-tight text-zinc-950 dark:text-white">
                      Selai <span className="text-brand-pink">Ghor</span>
                    </span>
                  </div>
                  <p className="text-[10px] text-zinc-400 uppercase tracking-wider mt-1.5 font-bold">Handmade with love & premium wool</p>
                  <p className="text-[11px] text-zinc-500 mt-1">Kolkata, West Bengal, India</p>
                  <p className="text-[11px] text-zinc-500">Email: support@selaighor.com | WhatsApp: +91 81002 26410</p>
                </div>

                <div className="sm:text-right">
                  <h1 className="font-display text-2xl font-black text-zinc-900 dark:text-white tracking-tight uppercase">Invoice</h1>
                  <p className="text-xs text-zinc-500 mt-1">Invoice #: <strong className="text-zinc-800 dark:text-zinc-200">INV-{selectedInvoiceOrder.id}</strong></p>
                  <p className="text-xs text-zinc-500">Date: {selectedInvoiceOrder.orderDate}</p>
                  <p className="text-xs text-zinc-500">Payment: <span className="font-bold text-brand-purple">{selectedInvoiceOrder.paymentMethod}</span></p>
                  <p className="text-xs text-zinc-500">Status: <span className="font-semibold uppercase text-[10px] rounded-full bg-emerald-50 text-emerald-700 px-2.5 py-0.5 dark:bg-emerald-950/20 dark:text-emerald-400">{selectedInvoiceOrder.status}</span></p>
                </div>
              </div>

              {/* Customer Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 py-6 border-b border-zinc-100 dark:border-zinc-800">
                <div>
                  <span className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-2">Billed To (Customer):</span>
                  <strong className="block text-zinc-800 dark:text-white text-sm">{selectedInvoiceOrder.address.fullName}</strong>
                  <p className="text-xs text-zinc-500 mt-1">Phone: {selectedInvoiceOrder.address.phoneNumber}</p>
                  {selectedInvoiceOrder.userEmail && (
                    <p className="text-xs text-zinc-500">Email: {selectedInvoiceOrder.userEmail}</p>
                  )}
                </div>

                <div>
                  <span className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-2">Shipping Destination:</span>
                  <p className="text-xs text-zinc-600 dark:text-zinc-300 leading-relaxed">
                    {selectedInvoiceOrder.address.fullAddress},<br />
                    Near {selectedInvoiceOrder.address.landmark},<br />
                    {selectedInvoiceOrder.address.district}, {selectedInvoiceOrder.address.state} - <strong className="text-zinc-800 dark:text-white">{selectedInvoiceOrder.address.pinCode}</strong>
                  </p>
                </div>
              </div>

              {/* Product Table */}
              <table className="w-full text-xs text-left my-6 border-collapse">
                <thead>
                  <tr className="border-b border-zinc-200 dark:border-zinc-800 text-zinc-400 font-bold uppercase tracking-wider text-[10px]">
                    <th className="py-2">Product Description</th>
                    <th className="py-2 text-center">Color Option</th>
                    <th className="py-2 text-center">Qty</th>
                    <th className="py-2 text-right">Unit Price</th>
                    <th className="py-2 text-right">Total Price</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-100 dark:divide-zinc-800 font-medium">
                  {selectedInvoiceOrder.items.map((item, idx) => {
                    const unitPrice = item.product.discountPrice || item.product.price;
                    return (
                      <tr key={idx} className="text-zinc-700 dark:text-zinc-300">
                        <td className="py-3 text-zinc-900 dark:text-white font-bold">{item.product.name}</td>
                        <td className="py-3 text-center">{item.selectedColor}</td>
                        <td className="py-3 text-center font-bold">{item.quantity}</td>
                        <td className="py-3 text-right">₹{unitPrice}</td>
                        <td className="py-3 text-right font-bold">₹{unitPrice * item.quantity}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {/* Totals Section */}
              <div className="flex justify-end pt-4">
                <div className="w-full max-w-xs space-y-2.5 text-xs text-zinc-500">
                  <div className="flex justify-between">
                    <span>Subtotal Amount:</span>
                    <span className="font-bold text-zinc-800 dark:text-white">₹{selectedInvoiceOrder.totalPrice}</span>
                  </div>
                  {selectedInvoiceOrder.discountApplied > 0 && (
                    <div className="flex justify-between text-brand-pink">
                      <span>Coupon Discount:</span>
                      <span>-₹{selectedInvoiceOrder.discountApplied}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Standard Delivery:</span>
                    <span>{selectedInvoiceOrder.deliveryCharge === 0 ? 'FREE' : `₹${selectedInvoiceOrder.deliveryCharge}`}</span>
                  </div>
                  <div className="flex justify-between text-zinc-900 dark:text-white font-black border-t pt-2.5 text-sm">
                    <span>Grand Total Paid:</span>
                    <span className="text-brand-pink font-extrabold text-base">₹{selectedInvoiceOrder.grandTotal}</span>
                  </div>
                </div>
              </div>

              {/* Note sign-off */}
              <div className="text-center mt-12 pt-6 border-t border-dashed border-zinc-200 dark:border-zinc-800">
                <p className="text-xs text-zinc-500 font-medium italic">Thank you for supporting handcrafted local wool art! ❤️</p>
                <p className="text-[9px] text-zinc-400 mt-1 uppercase tracking-widest font-bold">Selai Ghor Boutique • Handmade With Unconditional Care</p>
              </div>
            </div>

            {/* Action buttons (Print / Download PDF) */}
            <div className="flex flex-wrap gap-3 mt-8 pt-4 border-t no-print justify-end">
              <button
                onClick={() => {
                  const printContent = document.getElementById('invoice-print-area')?.innerHTML;
                  if (!printContent) return;
                  const originalTitle = document.title;
                  document.title = `Invoice_INV-${selectedInvoiceOrder.id}`;
                  
                  const style = `
                    <style>
                      body { font-family: system-ui, sans-serif; padding: 30px; color: #18181b; background: white; }
                      .no-print { display: none; }
                      table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                      th, td { border-bottom: 1px solid #e4e4e7; padding: 10px; text-align: left; }
                      th { font-size: 11px; text-transform: uppercase; color: #71717a; font-weight: bold; }
                      .text-right { text-align: right; }
                      .text-center { text-align: center; }
                      .font-bold { font-weight: bold; }
                      .text-brand-pink { color: #ec4899; }
                      .text-brand-purple { color: #8b5cf6; }
                      .font-black { font-weight: 900; }
                      .text-lg { font-size: 1.125rem; }
                      .text-xl { font-size: 1.25rem; }
                      .text-2xl { font-size: 1.5rem; }
                      .font-display { font-family: system-ui, sans-serif; }
                      .divide-y > * + * { border-top-width: 1px; }
                      .grid { display: grid; }
                      .grid-cols-1 { grid-template-columns: repeat(1, minmax(0, 1fr)); }
                      @media (min-width: 768px) {
                        .grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
                        .md\\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
                      }
                      .flex { display: flex; }
                      .flex-col { flex-direction: column; }
                      @media (min-width: 640px) {
                        .sm\\:flex-row { flex-direction: row; }
                        .sm\\:justify-between { justify-content: space-between; }
                        .sm\\:text-right { text-align: right; }
                      }
                      .justify-between { justify-content: space-between; }
                      .justify-end { justify-content: flex-end; }
                      .items-center { align-items: center; }
                      .space-x-2 > * + * { margin-left: 0.5rem; }
                      .space-y-2\\.5 > * + * { margin-top: 0.625rem; }
                      .space-y-1 > * + * { margin-top: 0.25rem; }
                      .mt-1 { margin-top: 0.25rem; }
                      .mt-1\\.5 { margin-top: 0.375rem; }
                      .mt-6 { margin-top: 1.5rem; }
                      .my-6 { margin: 1.5rem 0; }
                      .mt-12 { margin-top: 3rem; }
                      .pb-6 { padding-bottom: 1.5rem; }
                      .pt-4 { padding-top: 1rem; }
                      .pb-2 { padding-bottom: 0.5rem; }
                      .border-b { border-bottom-width: 1px; }
                      .border-t { border-top-width: 1px; }
                      .border-dashed { border-style: dashed; }
                      .w-full { width: 100%; }
                      .max-w-xs { max-w: 20rem; }
                    </style>
                  `;
                  const win = window.open('', '', 'height=800,width=1000');
                  if (win) {
                    win.document.write('<html><head><title>Invoice_INV-' + selectedInvoiceOrder.id + '</title>' + style + '</head><body>');
                    win.document.write(printContent);
                    win.document.write('</body></html>');
                    win.document.close();
                    win.focus();
                    setTimeout(() => {
                      win.print();
                      win.close();
                      document.title = originalTitle;
                    }, 250);
                  }
                }}
                className="inline-flex items-center space-x-2 rounded-xl bg-zinc-800 px-5 h-10 text-xs font-bold text-white hover:bg-zinc-950 transition-colors"
              >
                <Printer className="h-4 w-4" />
                <span>Print Invoice / Save PDF</span>
              </button>

              <button
                onClick={() => setSelectedInvoiceOrder(null)}
                className="rounded-xl border px-5 h-10 text-xs font-bold text-zinc-500 hover:bg-zinc-50 dark:border-zinc-800 dark:hover:bg-zinc-800 dark:text-zinc-400 transition-colors"
              >
                Close Preview
              </button>
            </div>
          </motion.div>
        </div>
      )}

    </div>
  );
}
