import React, { useState, useRef } from 'react';
import { Heart, Share2, Star, ShoppingBag, Plus, Minus, ArrowLeft, Calendar, ShieldCheck, Truck, Scale, Sparkles, Check, CheckCircle2, ShieldAlert, LogIn } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Product, Review, CartItem, Order, User } from '../types';

interface ProductDetailsProps {
  product: Product;
  onBack: () => void;
  onAddToCart: (product: Product, quantity: number, color: string) => void;
  onToggleWishlist: (productId: string) => void;
  isWishlisted: boolean;
  reviews: Review[];
  onAddReview: (review: Omit<Review, 'id' | 'date'>) => void;
  relatedProducts: Product[];
  onSelectProduct: (product: Product) => void;
  onDirectBuy: (product: Product, quantity: number, color: string) => void;
  orders: Order[];
  currentUser?: User | null;
  setCurrentTab?: (tab: string) => void;
}

export default function ProductDetails({
  product,
  onBack,
  onAddToCart,
  onToggleWishlist,
  isWishlisted,
  reviews,
  onAddReview,
  relatedProducts,
  onSelectProduct,
  onDirectBuy,
  orders,
  currentUser,
  setCurrentTab
}: ProductDetailsProps) {
  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [selectedColor, setSelectedColor] = useState(product.colorOptions[0] || 'Default');
  const displayImages = (product.colorImages && product.colorImages[selectedColor]) 
    ? product.colorImages[selectedColor] 
    : product.images;
  const [quantity, setQuantity] = useState(1);
  const [isAddedToast, setIsAddedToast] = useState(false);
  const [isShareSuccess, setIsShareSuccess] = useState(false);

  // Zoom Ref and State
  const imageContainerRef = useRef<HTMLDivElement>(null);
  const [zoomStyle, setZoomStyle] = useState<React.CSSProperties>({ display: 'none' });

  // Reviews toggle state and Ref
  const [showReviews, setShowReviews] = useState(false);
  const reviewsSectionRef = useRef<HTMLDivElement>(null);

  const toggleReviews = () => {
    setShowReviews(prev => {
      const next = !prev;
      if (next) {
        setTimeout(() => {
          reviewsSectionRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 150);
      }
      return next;
    });
  };

  // Review Form state
  const [reviewName, setReviewName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState(false);

  // Related products
  const productReviews = reviews.filter(r => r.productId === product.id);
  const averageRating = productReviews.length > 0 
    ? (productReviews.reduce((sum, r) => sum + r.rating, 0) / productReviews.length) 
    : product.rating;

  // Check if the user has purchased this product
  const hasPurchased = orders.some(o => o.items.some(item => item.product.id === product.id));

  // Color-specific price calculation
  const hasColorPrice = product.colorPrices && product.colorPrices[selectedColor] !== undefined;
  const hasColorDiscountPrice = product.colorDiscountPrices && product.colorDiscountPrices[selectedColor] !== undefined;

  const basePrice = hasColorPrice 
    ? product.colorPrices![selectedColor] 
    : product.price;

  const discountPrice = hasColorDiscountPrice 
    ? product.colorDiscountPrices![selectedColor] 
    : (hasColorPrice ? undefined : product.discountPrice);

  const currentPrice = discountPrice || basePrice;
  const savingAmount = discountPrice ? (basePrice - discountPrice) : 0;

  // Zoom logic
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!imageContainerRef.current) return;
    const { left, top, width, height } = imageContainerRef.current.getBoundingClientRect();
    const x = ((e.clientX - left) / width) * 100;
    const y = ((e.clientY - top) / height) * 100;
    setZoomStyle({
      display: 'block',
      transform: 'scale(1.8)',
      transformOrigin: `${x}% ${y}%`
    });
  };

  const handleMouseLeave = () => {
    setZoomStyle({ transform: 'scale(1)', transformOrigin: 'center center' });
  };

  const handleShare = () => {
    const text = `Check out this beautiful handmade crochet product: ${product.name} at Selai Ghor! Price: ₹${currentPrice}. Get yours now!`;
    navigator.clipboard.writeText(window.location.href);
    setIsShareSuccess(true);
    setTimeout(() => setIsShareSuccess(false), 3000);
    
    // Fallback to web share if supported
    if (navigator.share) {
      navigator.share({
        title: 'Selai Ghor',
        text: text,
        url: window.location.href
      }).catch(() => {});
    }
  };

  const handleAddToCartClick = () => {
    onAddToCart(product, quantity, selectedColor);
    setIsAddedToast(true);
    setTimeout(() => setIsAddedToast(false), 3000);
  };

  const handleBuyNowClick = () => {
    onDirectBuy(product, quantity, selectedColor);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewName.trim() || !reviewComment.trim()) return;

    onAddReview({
      productId: product.id,
      customerName: reviewName,
      rating: reviewRating,
      comment: reviewComment
    });

    setReviewName('');
    setReviewComment('');
    setReviewRating(5);
    setReviewSuccess(true);
    setTimeout(() => setReviewSuccess(false), 5000);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 text-left" id="product-detail-view">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {isAddedToast && (
          <motion.div
            initial={{ opacity: 0, y: -50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="fixed top-20 right-4 z-50 flex items-center space-x-2 rounded-2xl bg-emerald-500 p-4 text-sm font-bold text-white shadow-xl"
            id="added-to-cart-toast"
          >
            <CheckCircle2 className="h-5 w-5" />
            <span>Added {quantity}x {product.name} ({selectedColor}) to Cart!</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Back to Shop Button */}
      <button
        id="detail-back-to-shop-btn"
        onClick={onBack}
        className="group mb-6 inline-flex items-center space-x-2 text-xs font-bold uppercase tracking-widest text-zinc-500 hover:text-brand-pink transition-colors cursor-pointer"
      >
        <ArrowLeft className="h-4 w-4 group-hover:-translate-x-1 transition-transform" />
        <span>Back to creations</span>
      </button>

      {/* Product Information Split */}
      <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
        
        {/* Left Column: Image Gallery (lg:span-6) */}
        <div className="lg:col-span-6 space-y-4">
                    {/* Active Image Box with zoom */}
          <div 
            ref={imageContainerRef}
            onMouseMove={handleMouseMove}
            onMouseLeave={handleMouseLeave}
            className="zoom-container relative aspect-square w-full overflow-hidden rounded-[2rem] border border-pink-50 bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-800 shadow-md cursor-zoom-in"
            id="product-zoom-container"
          >
            <img
              src={displayImages[selectedImageIdx] || displayImages[0]}
              alt={product.name}
              referrerPolicy="no-referrer"
              className="zoom-image h-full w-full object-cover"
              style={zoomStyle}
            />

            {/* Float badges */}
            {product.availability === 'Pre-order' && (
              <span className="absolute top-4 left-4 rounded-xl bg-brand-purple px-3 py-1.5 text-xs font-bold text-white shadow-md">
                Pre-order Craft
              </span>
            )}
            
            <div className="absolute bottom-4 right-4 rounded-xl bg-black/40 backdrop-blur-md px-3 py-1.5 text-xs font-medium text-white">
              Roll hover to zoom 🔍
            </div>
          </div>

          {/* Thumbnail row */}
          <div className="flex gap-3 overflow-x-auto pb-2" id="thumbnail-row">
            {displayImages.map((imgUrl, idx) => (
              <button
                key={idx}
                id={`thumb-${idx}`}
                onClick={() => setSelectedImageIdx(idx)}
                className={`relative aspect-square w-20 flex-shrink-0 overflow-hidden rounded-2xl border-2 transition-all cursor-pointer ${
                  selectedImageIdx === idx 
                    ? 'border-brand-pink ring-2 ring-pink-100 dark:ring-pink-950/40' 
                    : 'border-transparent hover:border-pink-200'
                }`}
              >
                <img
                  src={imgUrl}
                  alt={`Thumbnail ${idx}`}
                  referrerPolicy="no-referrer"
                  className="h-full w-full object-cover"
                />
              </button>
            ))}
          </div>

        </div>

        {/* Right Column: Buying controls & detail data (lg:span-6) */}
        <div className="lg:col-span-6 space-y-6" id="product-detail-info">
          
          {/* Name & Category info */}
          <div className="space-y-2">
            <span className="text-xs font-bold uppercase tracking-widest text-brand-pink bg-brand-pink-light px-3 py-1 rounded-full dark:bg-pink-950/30 dark:text-pink-300">
              {product.category}
            </span>
            <h1 className="font-display text-2xl font-extrabold sm:text-3xl text-zinc-900 dark:text-white mt-2">
              {product.name}
            </h1>
            
            {/* Rating Stars and short description (Clickable to toggle reviews list) */}
            <div 
              onClick={toggleReviews}
              className="flex items-center space-x-3 cursor-pointer group/rating hover:text-brand-pink transition-colors select-none py-1 inline-flex"
              title="Click star to view Customer Reviews & Share Feedback"
            >
              <div className="flex items-center space-x-1">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star 
                    key={i} 
                    className={`h-4 w-4 transition-transform group-hover/rating:scale-110 ${i < Math.round(averageRating) ? 'fill-current text-yellow-400' : 'text-zinc-300'}`} 
                  />
                ))}
                <span className="text-xs font-bold text-zinc-700 dark:text-zinc-300 pl-1 group-hover/rating:text-brand-pink">
                  {averageRating.toFixed(1)}
                </span>
              </div>
              <span className="text-zinc-300 dark:text-zinc-700">|</span>
              <span className="text-xs font-semibold text-zinc-500 dark:text-zinc-400 group-hover/rating:text-brand-pink underline decoration-dashed decoration-pink-300 underline-offset-2">
                {productReviews.length} Customer Reviews (Click to view & write)
              </span>
            </div>
          </div>

          <hr className="border-pink-50 dark:border-zinc-800" />

          {/* Price */}
          <div className="space-y-2">
            <div className="flex items-baseline space-x-3">
              <span className="text-3xl font-extrabold text-zinc-900 dark:text-white">
                ₹{currentPrice}
              </span>
              {discountPrice ? (
                <>
                  <span className="text-base text-zinc-400 line-through">
                    ₹{basePrice}
                  </span>
                  <span className="text-xs font-bold text-red-500 bg-red-50 px-2 py-0.5 rounded dark:bg-red-950/20">
                    Save ₹{savingAmount}!
                  </span>
                </>
              ) : null}
            </div>
            
            <p className="text-xs text-zinc-500 dark:text-zinc-400">
              *Inclusive of all local hand-knitting craft taxes.
            </p>
          </div>

          {/* Short description */}
          <p className="text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed">
            {product.description}
          </p>

          {/* Color Options */}
          <div className="space-y-2.5">
            <span className="block text-xs font-bold text-zinc-500 uppercase tracking-widest dark:text-zinc-400">
              Color Option: <span className="text-zinc-800 dark:text-white font-bold">{selectedColor}</span>
            </span>
            <div className="flex flex-wrap gap-2">
              {product.colorOptions.map((color) => (
                <button
                  key={color}
                  id={`color-opt-${color.replace(/\s+/g, '-')}`}
                  onClick={() => {
                    setSelectedColor(color);
                    setSelectedImageIdx(0);
                  }}
                  className={`relative flex items-center justify-center rounded-xl px-4 py-2 text-xs font-bold transition-all cursor-pointer border ${
                    selectedColor === color
                      ? 'border-brand-pink bg-brand-pink-light/60 text-brand-pink ring-2 ring-pink-100 dark:border-pink-500 dark:bg-pink-950/20 dark:text-pink-400 dark:ring-pink-950/50'
                      : 'border-zinc-200 bg-white text-zinc-700 hover:border-pink-200 hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-300'
                  }`}
                >
                  {selectedColor === color && <Check className="mr-1 h-3.5 w-3.5 text-brand-pink dark:text-pink-400" />}
                  {color}
                </button>
              ))}
            </div>
          </div>

          {/* Quantity Selector */}
          <div className="space-y-2.5">
            <span className="block text-xs font-bold text-zinc-500 uppercase tracking-widest dark:text-zinc-400">
              Select Quantity:
            </span>
            <div className="flex items-center space-x-3">
              <div className="flex items-center rounded-2xl border border-zinc-200 bg-white p-1 dark:border-zinc-800 dark:bg-zinc-900">
                <button
                  id="qty-minus-btn"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="flex h-9 w-9 items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-brand-pink dark:text-zinc-400 dark:hover:bg-zinc-800 transition-colors"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="w-10 text-center text-sm font-bold text-zinc-800 dark:text-white" id="qty-count">
                  {quantity}
                </span>
                <button
                  id="qty-plus-btn"
                  onClick={() => setQuantity(quantity + 1)}
                  className="flex h-9 w-9 items-center justify-center rounded-xl text-zinc-500 hover:bg-zinc-100 hover:text-brand-pink dark:text-zinc-400 dark:hover:bg-zinc-800 transition-colors"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>

              {/* Wishlist Icon */}
              <button
                id="wishlist-detail-toggle"
                onClick={() => onToggleWishlist(product.id)}
                className={`flex h-11 w-11 items-center justify-center rounded-2xl border border-zinc-200 bg-white transition-all dark:border-zinc-800 dark:bg-zinc-900 ${
                  isWishlisted 
                    ? 'text-brand-pink border-pink-200 bg-pink-50/20 dark:text-pink-400' 
                    : 'text-zinc-500 hover:border-pink-200 hover:text-brand-pink'
                }`}
                title="Add to Wishlist"
              >
                <Heart className={`h-5 w-5 ${isWishlisted ? 'fill-brand-pink text-brand-pink' : ''}`} />
              </button>

              {/* Share Icon */}
              <button
                id="share-product-btn"
                onClick={handleShare}
                className={`relative flex h-11 w-11 items-center justify-center rounded-2xl border border-zinc-200 bg-white text-zinc-500 transition-all hover:border-pink-200 hover:text-brand-pink dark:border-zinc-800 dark:bg-zinc-900`}
                title="Share product link"
              >
                <Share2 className="h-5 w-5" />
                <AnimatePresence>
                  {isShareSuccess && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className="absolute bottom-12 right-0 w-28 rounded-lg bg-zinc-800 p-1.5 text-center text-[10px] font-bold text-white shadow"
                    >
                      Copied Link!
                    </motion.div>
                  )}
                </AnimatePresence>
              </button>
            </div>
          </div>

          {/* Buy and Add to Cart Buttons */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 pt-2">
            {!currentUser ? (
              <button
                id="detail-login-btn"
                onClick={() => {
                  if (setCurrentTab) {
                    setCurrentTab('account');
                  }
                }}
                className="col-span-1 sm:col-span-2 w-full flex items-center justify-center space-x-2 rounded-full bg-brand-pink px-6 py-3.5 text-xs font-bold text-white hover:bg-brand-pink-dark transition-all shadow-md cursor-pointer"
              >
                <LogIn className="h-4.5 w-4.5" />
                <span>Log In to Add to Cart & Buy</span>
              </button>
            ) : (
              <>
                <button
                  id="detail-add-to-cart-btn"
                  onClick={handleAddToCartClick}
                  className="flex items-center justify-center space-x-2 rounded-full border-2 border-brand-pink bg-transparent px-6 py-3.5 text-xs font-bold text-brand-pink hover:bg-brand-pink hover:text-white transition-all cursor-pointer dark:text-pink-400"
                >
                  <ShoppingBag className="h-4.5 w-4.5" />
                  <span>Add to Cart</span>
                </button>
                
                <button
                  id="detail-buy-now-btn"
                  onClick={handleBuyNowClick}
                  className="flex items-center justify-center space-x-2 rounded-full bg-brand-pink px-6 py-3.5 text-xs font-bold text-white hover:bg-brand-pink-dark transition-all shadow-md cursor-pointer"
                >
                  <span>Buy Now</span>
                </button>
              </>
            )}
          </div>

          <hr className="border-pink-50 dark:border-zinc-800" />

          {/* Artisan Trust & Details bullet lists */}
          <div className="grid grid-cols-2 gap-4 text-xs font-medium text-zinc-600 dark:text-zinc-400" id="spec-bullets">
            <div className="flex items-center space-x-2.5">
              <Sparkles className="h-4.5 w-4.5 text-brand-purple" />
              <span>Material: {product.materialsUsed}</span>
            </div>
            <div className="flex items-center space-x-2.5">
              <Calendar className="h-4.5 w-4.5 text-brand-pink" />
              <span>Size: {product.size}</span>
            </div>
            <div className="flex items-center space-x-2.5">
              <Scale className="h-4.5 w-4.5 text-brand-green" />
              <span>Weight: {product.weight}</span>
            </div>
            <div className="flex items-center space-x-2.5">
              <Truck className="h-4.5 w-4.5 text-zinc-500" />
              <span>Est: {product.estimatedDelivery}</span>
            </div>
          </div>

        </div>

      </div>

      {/* Scroll anchor ref for reviews */}
      <div ref={reviewsSectionRef} className="scroll-mt-24" />

      {/* Reviews Tab & Ratings Form Section */}
      <AnimatePresence>
        {showReviews && (
          <motion.section 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="mt-16 border-t border-pink-50 pt-12 dark:border-zinc-800 overflow-hidden" 
            id="reviews-section"
          >
            <div className="grid grid-cols-1 gap-12 lg:grid-cols-12">
              
              {/* Reviews List (lg:span-7) */}
              <div className="lg:col-span-7 space-y-6">
                <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">
                  Customer Reviews ({productReviews.length})
                </h2>

                {productReviews.length === 0 ? (
                  <p className="text-xs text-zinc-500 italic">No reviews for this product yet. Be the first to share your experience!</p>
                ) : (
                  <div className="space-y-4" id="reviews-list-container">
                    {productReviews.map((rev) => (
                      <div
                        key={rev.id}
                        className="p-5 rounded-2xl border border-pink-50/50 bg-zinc-50/40 dark:border-zinc-800 dark:bg-zinc-900/30"
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <span className="block text-sm font-bold text-zinc-800 dark:text-white">{rev.customerName}</span>
                            <span className="block text-[10px] text-zinc-400">{rev.date}</span>
                          </div>
                          
                          <div className="flex text-amber-400">
                            {Array.from({ length: rev.rating }).map((_, i) => (
                              <Star key={i} className="h-3.5 w-3.5 fill-current" />
                            ))}
                          </div>
                        </div>
                        
                        <p className="text-xs text-zinc-600 dark:text-zinc-300 mt-2.5 leading-relaxed">
                          {rev.comment}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Write a Review Form (lg:span-5) */}
              <div className="lg:col-span-5 p-6 rounded-3xl border border-pink-150 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 flex flex-col justify-center">
                <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4">
                  Share Your Feedback
                </h3>

                {!hasPurchased ? (
                  <div className="py-6 text-center space-y-4" id="verified-purchase-lock">
                    <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-pink-50 text-brand-pink dark:bg-zinc-800 dark:text-pink-400">
                      <ShieldAlert className="h-6 w-6" />
                    </div>
                    <div>
                      <h4 className="font-display text-xs font-bold text-zinc-800 dark:text-white">Verified Purchase Required</h4>
                      <p className="text-[11px] text-zinc-500 mt-1 max-w-xs mx-auto leading-relaxed dark:text-zinc-400">
                        To ensure the integrity of our handcrafted reviews, only customers who have purchased this product from Selai Ghor can write a review.
                      </p>
                    </div>
                    <div className="pt-2">
                      <span className="inline-block text-[10px] font-extrabold uppercase tracking-wider text-brand-pink bg-brand-pink-light/50 px-3.5 py-1.5 rounded-full dark:bg-pink-950/40 dark:text-pink-300">
                        Unlock after purchasing
                      </span>
                    </div>
                  </div>
                ) : (
                  <>
                    <form onSubmit={handleReviewSubmit} className="space-y-3.5">
                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                          Your Name
                        </label>
                        <input
                          type="text"
                          placeholder="Enter your name"
                          value={reviewName}
                          onChange={(e) => setReviewName(e.target.value)}
                          required
                          className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                          id="review-name-input"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1.5 dark:text-zinc-400">
                          Rating
                        </label>
                        <div className="flex space-x-1 text-amber-400">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              type="button"
                              id={`star-btn-${star}`}
                              onClick={() => setReviewRating(star)}
                              className="transition-transform hover:scale-110 cursor-pointer"
                            >
                              <Star className={`h-6 w-6 ${star <= reviewRating ? 'fill-current' : 'text-zinc-300'}`} />
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                          Review Comment
                        </label>
                        <textarea
                          rows={3}
                          placeholder="Tell us what you liked about this product..."
                          value={reviewComment}
                          onChange={(e) => setReviewComment(e.target.value)}
                          required
                          className="w-full rounded-xl border border-zinc-200 p-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                          id="review-comment-input"
                        />
                      </div>

                      <button
                        type="submit"
                        id="submit-review-btn"
                        className="w-full h-10 rounded-full bg-brand-pink text-xs font-bold text-white shadow hover:bg-brand-pink-dark transition-colors cursor-pointer"
                      >
                        Submit Review
                      </button>
                    </form>

                    {reviewSuccess && (
                      <div className="mt-3 p-2 text-center text-xs font-bold text-emerald-800 bg-emerald-100 rounded-xl dark:bg-emerald-950/40 dark:text-emerald-300">
                        ❤️ Thank you! Your review has been added.
                      </div>
                    )}
                  </>
                )}
              </div>

            </div>
          </motion.section>
        )}
      </AnimatePresence>

      {/* Related Products Carousel */}
      {relatedProducts.length > 0 && (
        <section className="mt-16 border-t border-pink-50 pt-12 dark:border-zinc-800" id="related-products-section">
          <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white mb-8">
            You May Also Like
          </h2>

          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {relatedProducts.map((relProd) => {
              const relPrice = relProd.discountPrice || relProd.price;
              const hasRelDiscount = !!relProd.discountPrice;
              return (
                <div
                  key={relProd.id}
                  onClick={() => {
                    onSelectProduct(relProd);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="group flex items-center space-x-3.5 p-3 rounded-2xl border border-zinc-100 bg-white hover:-translate-y-0.5 hover:shadow-md transition-all cursor-pointer dark:border-zinc-800 dark:bg-zinc-900"
                  id={`related-product-${relProd.id}`}
                >
                  <div className="h-16 w-16 flex-shrink-0 overflow-hidden rounded-xl bg-zinc-100">
                    <img
                      src={relProd.images[0]}
                      alt={relProd.name}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="text-left flex-1 min-w-0">
                    <span className="text-[9px] font-bold text-brand-purple uppercase tracking-wider">{relProd.category}</span>
                    <h4 className="font-display text-xs font-bold text-zinc-800 dark:text-zinc-100 truncate group-hover:text-brand-pink">
                      {relProd.name}
                    </h4>
                    <div className="flex items-center space-x-1.5 mt-0.5">
                      <span className="text-xs font-bold text-zinc-900 dark:text-white">₹{relPrice}</span>
                      {hasRelDiscount && <span className="text-[10px] text-zinc-400 line-through">₹{relProd.price}</span>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

    </div>
  );
}
