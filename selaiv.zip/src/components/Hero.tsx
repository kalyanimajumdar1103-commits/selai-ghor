import React, { useState, useEffect } from 'react';
import { ShoppingBag, ArrowRight, Heart, Sparkles, Star, ShieldCheck, HelpCircle, Flame, Gift, Compass, ChevronLeft, ChevronRight, Play, Pause, Phone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Product, Poster } from '../types';

interface HeroProps {
  products: Product[];
  setCurrentTab: (tab: string) => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, quantity: number, color: string) => void;
  onToggleWishlist: (productId: string) => void;
  wishlist: string[];
  posters?: Poster[];
  categories?: string[];
  categoryImages?: {[key: string]: string};
  onFilterCategory?: (category: string) => void;
}

export default function Hero({
  products,
  setCurrentTab,
  onSelectProduct,
  onAddToCart,
  onToggleWishlist,
  wishlist,
  posters,
  categories,
  categoryImages,
  onFilterCategory
}: HeroProps) {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [emailInput, setEmailInput] = useState('');
  const [newsletterSubscribed, setNewsletterSubscribed] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const slides = posters && posters.length > 0 ? posters : [
    {
      id: 'bun-ring-slide',
      image: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?q=80&w=600',
      title: 'Aparajita Hair Bun Ring',
      subtitle: 'Signature Crochet Collection',
      description: 'Elevate your hairstyle with our handmade white & blue crochet bun ring adorned with cascading Aparajita flower tassels and wooden stick.',
      linkTab: 'shop',
      buttonText: 'ORDER NOW'
    },
    {
      id: 'crochet-slide',
      image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=600',
      title: 'Beautiful Crochet Treasures for your Home',
      subtitle: 'Handmade with Love',
      description: 'Explore our collection of premium wool products, meticulously crafted to bring warmth and color to your life.',
      linkTab: 'shop',
      buttonText: 'Shop Now'
    },
    {
      id: 'sunflower-slide',
      image: 'https://images.unsplash.com/photo-1508780709619-795624c7ac40?q=80&w=600',
      title: 'Vibrant Sunflower Collection',
      subtitle: 'Bright & Cheerful Accessories',
      description: 'Bring warm sunshine vibes to your hair with our handmade crochet sunflower hair clips and bun accessories made from premium soft wool.',
      linkTab: 'shop',
      buttonText: 'SHOP SUNFLOWERS'
    }
  ];

  useEffect(() => {
    if (isPaused || slides.length === 0) return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [isPaused, slides.length]);

  // Filter sections
  const newArrivals = products.slice(0, 4);
  const bestSellers = products.slice(3, 7);
  const featuredProducts = products.filter(p => p.rating >= 4.9).slice(0, 4);

  const testimonials = [
    {
      name: 'Priyanka Das',
      role: 'Regular Customer',
      rating: 5,
      text: 'The crochet daisy tote is my favorite accessory! Every detail is perfect, and I always get compliments. Salai Ghor has the best handmade woolens!',
      avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=150'
    },
    {
      name: 'Siddharth Sen',
      role: 'Gift Buyer',
      rating: 5,
      text: 'I ordered a custom amigurumi doll for my daughters birthday. It looks exactly like her photo! Such amazing, dedicated craftsmanship. Truly unique.',
      avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=150'
    },
    {
      name: 'Riya Banerjee',
      role: 'Art Lover',
      rating: 5,
      text: 'Very soft, premium yarn is used. The tulip hair band feels so comfortable. Delivery was fast and the WhatsApp ordering was incredibly easy!',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=150'
    }
  ];

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailInput.trim()) {
      setNewsletterSubscribed(true);
      setEmailInput('');
      setTimeout(() => setNewsletterSubscribed(false), 5000);
    }
  };

  return (
    <div className="relative bg-white dark:bg-zinc-950 text-zinc-900 dark:text-zinc-50 transition-colors" id="homepage-container">
      
      {/* Top Banner Alert inside Hero section */}
      <div className="w-full text-center bg-[#8C1E1E] text-amber-50 text-[10px] sm:text-xs font-bold py-1.5 uppercase tracking-widest shadow-inner z-20" id="sale-alert-bar">
        Sale Started.
      </div>

      {/* 1. Hero Banner (Interactive Slider) */}
      <section className="relative overflow-hidden bg-[#FFFBF0] dark:bg-zinc-950 transition-colors" id="hero-banner-slider">
        <div className="relative min-h-[500px] lg:min-h-[580px] flex items-center">
          <AnimatePresence mode="wait">
            {(() => {
              const slide = slides[currentSlide];
              if (!slide) return null;

              if (slide.id === 'bun-ring-slide') {
                return (
                  <motion.div
                    key="bun-ring-slide"
                    initial={{ opacity: 0, x: 100 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                    transition={{ duration: 0.5 }}
                    className="w-full min-h-[500px] lg:min-h-[580px] flex items-center bg-[#FAF7F2] dark:bg-zinc-950 transition-colors py-6 sm:py-8 lg:py-10"
                  >
                    {/* Aparajita Hair Bun Ring Custom Banner */}
                    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 w-full">
                      {/* Traditional Double Border Frame */}
                      <div className="relative border-4 border-double border-blue-900/20 rounded-3xl bg-[#FDFBF7] p-6 sm:p-10 lg:p-12 shadow-xl dark:bg-stone-900 dark:border-blue-800/20 overflow-hidden">
                        
                        {/* Vintage Ornate Corner Flourishes (Inline SVGs) */}
                        <div className="absolute top-2 left-2 text-[#1F4E79] dark:text-blue-400 pointer-events-none opacity-80">
                          <svg width="48" height="48" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M 5 5 L 85 5 M 5 5 L 5 85" strokeWidth="4" />
                            <path d="M 15 15 L 65 15 M 15 15 L 15 65" />
                            <circle cx="25" cy="25" r="4" fill="currentColor" />
                            <path d="M 5 40 C 15 40, 25 30, 25 15" />
                            <path d="M 40 5 C 40 15, 30 25, 15 25" />
                            <path d="M 15 15 C 30 15, 30 30, 15 30 Z" />
                          </svg>
                        </div>
                        <div className="absolute top-2 right-2 text-[#1F4E79] dark:text-blue-400 pointer-events-none opacity-80 rotate-90">
                          <svg width="48" height="48" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M 5 5 L 85 5 M 5 5 L 5 85" strokeWidth="4" />
                            <path d="M 15 15 L 65 15 M 15 15 L 15 65" />
                            <circle cx="25" cy="25" r="4" fill="currentColor" />
                            <path d="M 5 40 C 15 40, 25 30, 25 15" />
                            <path d="M 40 5 C 40 15, 30 25, 15 25" />
                            <path d="M 15 15 C 30 15, 30 30, 15 30 Z" />
                          </svg>
                        </div>
                        <div className="absolute bottom-2 left-2 text-[#1F4E79] dark:text-blue-400 pointer-events-none opacity-80 -rotate-90">
                          <svg width="48" height="48" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M 5 5 L 85 5 M 5 5 L 5 85" strokeWidth="4" />
                            <path d="M 15 15 L 65 15 M 15 15 L 15 65" />
                            <circle cx="25" cy="25" r="4" fill="currentColor" />
                            <path d="M 5 40 C 15 40, 25 30, 25 15" />
                            <path d="M 40 5 C 40 15, 30 25, 15 25" />
                            <path d="M 15 15 C 30 15, 30 30, 15 30 Z" />
                          </svg>
                        </div>
                        <div className="absolute bottom-2 right-2 text-[#1F4E79] dark:text-blue-400 pointer-events-none opacity-80 rotate-180">
                          <svg width="48" height="48" viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="2">
                            <path d="M 5 5 L 85 5 M 5 5 L 5 85" strokeWidth="4" />
                            <path d="M 15 15 L 65 15 M 15 15 L 15 65" />
                            <circle cx="25" cy="25" r="4" fill="currentColor" />
                            <path d="M 5 40 C 15 40, 25 30, 25 15" />
                            <path d="M 40 5 C 40 15, 30 25, 15 25" />
                            <path d="M 15 15 C 30 15, 30 30, 15 30 Z" />
                          </svg>
                        </div>

                        <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-center relative z-10">
                          
                          {/* Banner Left (Columns 1-6) */}
                          <div className="lg:col-span-6 flex flex-col items-center justify-center text-center space-y-4">
                            
                            {/* Needle and Thread Icon */}
                            <div className="flex items-center justify-center space-x-1 opacity-80 text-[#1F4E79] dark:text-blue-400">
                              <div className="w-10 h-[1px] bg-gradient-to-r from-transparent to-current" />
                              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                                <path d="M5 19L19 5M19 5v6M19 5h-6" strokeLinecap="round" strokeLinejoin="round" />
                                <circle cx="12" cy="12" r="3" />
                              </svg>
                              <div className="w-10 h-[1px] bg-gradient-to-l from-transparent to-current" />
                            </div>

                            {/* Cursive Bengali Logo */}
                            <div>
                              <span className="inline-block px-3 py-1 bg-blue-50 text-[#1F4E79] text-[10px] font-extrabold rounded-full uppercase tracking-widest shadow-sm border border-blue-100/30 dark:bg-zinc-800 dark:text-blue-300 dark:border-zinc-700">
                                {slide.subtitle || 'Signature Crochet Collection'}
                              </span>
                              <h1 className="font-serif text-5xl sm:text-6xl font-black text-[#1F4E79] dark:text-blue-400 leading-tight mt-3 tracking-wide drop-shadow-sm select-none">
                                সেলাই ঘর
                              </h1>
                              <p className="text-[11px] uppercase tracking-[0.2em] font-bold text-zinc-500 mt-1">
                                ♥ Handmade with love ♥
                              </p>
                            </div>

                            {/* Dotted Circle Badge */}
                            <div className="relative mx-auto w-40 h-40 rounded-full border-2 border-dashed border-[#1F4E79]/40 bg-white/85 dark:bg-zinc-800/85 flex flex-col items-center justify-center p-4 text-center shadow-inner transition-transform hover:scale-105 duration-300">
                              <div className="absolute inset-1.5 rounded-full border border-[#1F4E79]/10" />
                              <span className="text-zinc-700 dark:text-zinc-200 font-bold text-sm tracking-wide leading-relaxed font-serif">
                                হাতের ছোঁয়ায় <br />
                                সুন্দর প্রতিটা <br />
                                মুহূর্ত
                              </span>
                              <span className="text-[#1F4E79] text-xs mt-1 animate-pulse">❤</span>
                            </div>

                            {/* Contact Pill */}
                            <div className="flex flex-col sm:flex-row items-center gap-3 pt-2">
                              <div className="inline-flex items-center space-x-2 rounded-full bg-[#1F4E79] text-white px-5 py-2.5 text-xs font-bold shadow-md hover:bg-[#153654] transition-colors transform hover:-translate-y-0.5">
                                <Phone className="h-3.5 w-3.5 animate-bounce" />
                                <span>+91 8100226410</span>
                              </div>
                            </div>

                          </div>

                          {/* Banner Right (Columns 7-12) */}
                          <div className="lg:col-span-6 flex flex-col items-center justify-center space-y-6">
                            
                            {/* Round Hair Bun Frame */}
                            <div className="relative aspect-square w-full max-w-[320px] overflow-hidden rounded-[2.5rem] border-[10px] border-white bg-white shadow-2xl dark:border-zinc-800 dark:bg-zinc-800 transition-transform hover:scale-[1.02] duration-300">
                              <img
                                src={slide.image}
                                alt="Aparajita Hair Bun Ring"
                                className="h-full w-full object-cover select-none"
                              />
                              
                              {/* Interactive CSS overlay representing the white-scalloped, blue-inner crochet hair bun ring accessory */}
                              <div className="absolute inset-0 bg-black/10 flex items-center justify-center">
                                <div className="relative w-36 h-36 rounded-full border-4 border-[#1F4E79] bg-[#1F4E79]/20 shadow-2xl flex items-center justify-center pointer-events-none">
                                  {/* White scalloped crochet ruffles */}
                                  <div className="absolute -inset-2.5 rounded-full border-[6px] border-dashed border-white opacity-95 animate-[spin_60s_linear_infinite]" />
                                  <div className="absolute -inset-1 rounded-full border-2 border-dashed border-[#1F4E79]/40" />
                                  
                                  {/* Wooden Hair Pin */}
                                  <div className="absolute w-48 h-2 bg-gradient-to-r from-amber-100 via-amber-200 to-amber-300 rounded-full rotate-[-30deg] shadow-lg border border-amber-400/40 transform -translate-x-1" />
                                  
                                  {/* Green stems and hanging Aparajita flowers */}
                                  <div className="absolute bottom-[-55px] right-2 w-2 h-14 bg-emerald-600 rounded-full flex flex-col justify-end items-center origin-top rotate-[5deg]">
                                    {/* Hanging blue flower tassel 1 */}
                                    <div className="absolute bottom-[-10px] -left-2.5 w-5.5 h-5.5 rounded-full bg-blue-600 border border-blue-200 flex items-center justify-center shadow-md">
                                      <span className="text-[5px] text-white font-extrabold">✿</span>
                                    </div>
                                    {/* Hanging blue flower tassel 2 */}
                                    <div className="absolute bottom-[-22px] left-0.5 w-5.5 h-5.5 rounded-full bg-blue-700 border border-blue-300 flex items-center justify-center shadow-md">
                                      <span className="text-[5px] text-white font-extrabold">✿</span>
                                    </div>
                                    {/* Thread detailing */}
                                    <div className="w-[1px] h-full bg-emerald-400/50" />
                                  </div>
                                </div>
                              </div>
                            </div>

                            <p className="text-xs sm:text-sm text-zinc-600 dark:text-zinc-300 italic font-medium leading-relaxed max-w-md text-center">
                              {slide.description}
                            </p>

                            {/* Order Now Button */}
                            <div>
                              <button
                                onClick={() => {
                                  setCurrentTab(slide.linkTab || 'shop');
                                }}
                                className="inline-flex items-center justify-center rounded-full bg-[#1F4E79] hover:bg-[#153654] text-white px-10 py-3.5 text-xs font-black uppercase tracking-wider shadow-lg hover:scale-[1.03] active:scale-95 transition-all cursor-pointer select-none border border-blue-700/30"
                              >
                                <span>{slide.buttonText || 'ORDER NOW'}</span>
                              </button>
                            </div>

                          </div>

                        </div>

                      </div>
                    </div>
                  </motion.div>
                );
              }

              if (slide.id === 'crochet-slide') {
                return (
                  <motion.div
                    key="crochet-slide"
                    initial={{ opacity: 0, x: 100 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                    transition={{ duration: 0.5 }}
                    className="w-full min-h-[500px] lg:min-h-[580px] flex items-center bg-[#FFF0F5] dark:bg-zinc-900 transition-colors py-6 sm:py-8 lg:py-10"
                  >
                    {/* Original Crochet Slide */}
                    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 w-full">
                      <div className="grid grid-cols-1 gap-12 lg:grid-cols-2 lg:items-center">
                        
                        {/* Hero Left: Text */}
                        <div className="space-y-6 text-left">
                          <div className="inline-block px-3 py-1 bg-white text-brand-pink text-xs font-bold rounded-full uppercase tracking-widest shadow-sm border border-pink-50 dark:bg-zinc-800 dark:text-pink-300 dark:border-zinc-700">
                            {slide.subtitle || 'Handmade with Love'}
                          </div>
                          
                          <h2 className="font-serif text-4xl font-normal tracking-tight sm:text-5xl md:text-6xl text-zinc-900 dark:text-white leading-tight">
                            Beautiful Crochet <br />
                            <span className="text-brand-pink italic">Treasures</span> for your Home
                          </h2>
                          
                          <p className="max-w-md text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed">
                            {slide.description}
                          </p>

                          <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 pt-2">
                            <button
                              id="hero-shop-now-btn-s1"
                              onClick={() => setCurrentTab(slide.linkTab || 'shop')}
                              className="inline-flex items-center justify-center space-x-2 rounded-full bg-zinc-950 px-8 py-3.5 text-xs font-semibold uppercase tracking-widest text-white hover:bg-zinc-800 dark:bg-white dark:text-zinc-950 dark:hover:bg-zinc-100 transition-colors cursor-pointer"
                            >
                              <span>{slide.buttonText || 'Shop Now'}</span>
                              <ArrowRight className="h-3.5 w-3.5" />
                            </button>
                            
                            <button
                              id="hero-custom-order-btn-s1"
                              onClick={() => setCurrentTab('custom-order')}
                              className="inline-flex items-center justify-center space-x-2 rounded-full border border-zinc-200 bg-white px-8 py-3.5 text-xs font-semibold uppercase tracking-widest text-zinc-700 hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 transition-colors cursor-pointer"
                            >
                              <span>Custom Order</span>
                              <Gift className="h-3.5 w-3.5 text-brand-pink" />
                            </button>
                          </div>

                          {/* Minimal stats */}
                          <div className="grid grid-cols-3 gap-4 pt-6 border-t border-zinc-200/50 dark:border-zinc-800">
                            <div>
                              <span className="block text-xl font-bold text-zinc-900 dark:text-white font-serif">500+</span>
                              <span className="text-[10px] text-zinc-400 font-semibold uppercase tracking-wider">Happy Clients</span>
                            </div>
                            <div>
                              <span className="block text-xl font-bold text-zinc-900 dark:text-white font-serif">100%</span>
                              <span className="text-[10px] text-zinc-400 font-semibold uppercase tracking-wider">Combed Cotton</span>
                            </div>
                            <div>
                              <span className="block text-xl font-bold text-zinc-900 dark:text-white font-serif">Artisan</span>
                              <span className="text-[10px] text-zinc-400 font-semibold uppercase tracking-wider">Handcrafted</span>
                            </div>
                          </div>
                        </div>

                        {/* Hero Right: Images Collage */}
                        <div className="relative flex justify-center">
                          <div className="relative aspect-square w-full max-w-[340px] overflow-hidden rounded-[2.5rem] border-[10px] border-white bg-white shadow-xl dark:border-zinc-800 dark:bg-zinc-800">
                            <img
                              src={slide.image}
                              alt={slide.title}
                              referrerPolicy="no-referrer"
                              className="h-full w-full object-cover"
                            />
                            <div className="absolute top-4 left-4 flex items-center space-x-1.5 rounded-full bg-white/95 px-3 py-1.5 text-xs font-semibold text-zinc-800 shadow-sm dark:bg-zinc-900/90 dark:text-white">
                              <span className="h-2 w-2 rounded-full bg-brand-pink" />
                              <span>Handcrafted</span>
                            </div>
                          </div>
                          
                          <div className="absolute -bottom-6 -left-6 hidden sm:block aspect-square w-28 overflow-hidden rounded-3xl border-4 border-white bg-white shadow-lg dark:border-zinc-800">
                            <img
                              src="https://images.unsplash.com/photo-1561181286-d3fee7d55364?q=80&w=250"
                              alt="Crochet Tulips"
                              referrerPolicy="no-referrer"
                              className="h-full w-full object-cover"
                            />
                          </div>
                        </div>

                      </div>
                    </div>
                  </motion.div>
                );
              }

              if (slide.id === 'sunflower-slide' || slide.id === 'custom-slide') {
                return (
                  <motion.div
                    key="sunflower-slide"
                    initial={{ opacity: 0, x: 100 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                    transition={{ duration: 0.5 }}
                    className="w-full min-h-[500px] lg:min-h-[580px] flex items-center bg-[#FFFDF0] dark:bg-zinc-950 transition-colors py-6 sm:py-8 lg:py-10"
                  >
                    {/* Sunflower Collection Custom Banner */}
                    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 w-full">
                      <div className="relative border-4 border-double border-amber-500/20 rounded-3xl bg-[#FFFDF7] p-6 sm:p-10 lg:p-12 shadow-2xl dark:bg-stone-900 dark:border-amber-800/20 overflow-hidden">
                        
                        <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-center relative z-10">
                          
                          {/* Left text column */}
                          <div className="lg:col-span-6 flex flex-col justify-center text-center lg:text-left space-y-6">
                            
                            <div>
                              <span className="inline-block px-3 py-1 bg-amber-50 text-amber-800 text-xs font-bold rounded-full uppercase tracking-widest shadow-sm border border-amber-100/30 dark:bg-zinc-800 dark:text-amber-300 dark:border-zinc-700">
                                {slide.subtitle || 'Cheerful & Bright Crochet'}
                              </span>
                              <h2 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-black text-amber-900 dark:text-amber-400 leading-tight mt-3">
                                Vibrant <br />
                                <span className="text-amber-600 dark:text-amber-500 italic">Sunflower</span> Collection
                              </h2>
                            </div>

                            <p className="text-xs sm:text-sm text-amber-800/80 dark:text-zinc-300 italic font-medium leading-relaxed max-w-md mx-auto lg:mx-0">
                              {slide.description}
                            </p>

                            {/* Order Button */}
                            <div className="pt-2">
                              <button
                                onClick={() => {
                                  setCurrentTab(slide.linkTab || 'shop');
                                }}
                                className="inline-flex items-center justify-center rounded-full bg-amber-500 hover:bg-amber-600 text-amber-950 px-10 py-3.5 text-xs font-black uppercase tracking-wider shadow-lg hover:scale-[1.03] active:scale-95 transition-all cursor-pointer select-none border border-amber-400/30"
                              >
                                <span>{slide.buttonText || 'EXPLORE NOW'}</span>
                              </button>
                            </div>

                          </div>

                          {/* Right graphics/photo column */}
                          <div className="lg:col-span-6 flex flex-col items-center justify-center space-y-6">
                            
                            {/* Round Hair Bun Frame */}
                            <div className="relative aspect-square w-full max-w-[320px] overflow-hidden rounded-[2.5rem] border-[10px] border-white bg-white shadow-2xl dark:border-zinc-800 dark:bg-zinc-800 transition-transform hover:scale-[1.02] duration-300">
                              <img
                                src={slide.image}
                                alt="Sunflower Crochet"
                                className="h-full w-full object-cover select-none"
                              />
                              
                              {/* Interactive CSS overlay representing Sunflower Crochet details */}
                              <div className="absolute inset-0 bg-black/5 flex items-center justify-center">
                                <div className="relative w-40 h-40 rounded-full flex items-center justify-center pointer-events-none scale-90">
                                  {/* Yellow petals */}
                                  <div className="absolute inset-0 rounded-full border-8 border-dashed border-amber-400 opacity-90 animate-[spin_40s_linear_infinite]" />
                                  <div className="absolute inset-2 rounded-full border-[6px] border-dashed border-yellow-400 opacity-95 animate-[spin_25s_linear_infinite]" />
                                  
                                  {/* Dark brown center */}
                                  <div className="absolute w-20 h-20 rounded-full bg-[#3D2314] shadow-inner flex items-center justify-center border-4 border-amber-600/30">
                                    {/* Seeds pattern */}
                                    <div className="w-10 h-10 rounded-full border border-dashed border-amber-500/40" />
                                  </div>

                                  {/* Green leaves */}
                                  <div className="absolute -bottom-4 -left-2 w-8 h-12 bg-emerald-600 rounded-full rotate-[-45deg] origin-top shadow-md border border-emerald-400/20" />
                                  <div className="absolute -bottom-4 -right-2 w-8 h-12 bg-emerald-600 rounded-full rotate-[45deg] origin-top shadow-md border border-emerald-400/20" />
                                </div>
                              </div>
                            </div>

                          </div>

                        </div>

                      </div>
                    </div>
                  </motion.div>
                );
              }

              // Custom Admin Uploaded Slide
              const isSplit = slide.layout === 'split';

              if (isSplit) {
                return (
                  <motion.div
                    key={slide.id}
                    initial={{ opacity: 0, x: 100 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -100 }}
                    transition={{ duration: 0.5 }}
                    className="w-full min-h-[500px] lg:min-h-[580px] flex items-center bg-zinc-50 dark:bg-zinc-900 transition-colors py-6 sm:py-8 lg:py-10"
                  >
                    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 w-full">
                      <div className="grid grid-cols-1 gap-12 lg:grid-cols-2 lg:items-center">
                        
                        {/* Left: Content Text */}
                        <div className="space-y-6 text-left">
                          {slide.subtitle && (
                            <div className="inline-block px-3 py-1 bg-white text-brand-pink text-xs font-bold rounded-full uppercase tracking-widest shadow-sm border border-pink-50 dark:bg-zinc-800 dark:text-pink-300 dark:border-zinc-700">
                              {slide.subtitle}
                            </div>
                          )}
                          
                          <h2 className="font-serif text-4xl font-semibold tracking-tight sm:text-5xl md:text-6xl text-zinc-900 dark:text-white leading-tight">
                            {slide.title}
                          </h2>
                          
                          <p className="max-w-md text-sm text-zinc-600 dark:text-zinc-300 leading-relaxed">
                            {slide.description}
                          </p>

                          <div className="pt-2">
                            <button
                              onClick={() => setCurrentTab(slide.linkTab || 'shop')}
                              className="inline-flex items-center justify-center space-x-2 rounded-full bg-brand-pink px-8 py-3.5 text-xs font-semibold uppercase tracking-widest text-white hover:bg-brand-pink-dark transition-colors cursor-pointer shadow-md"
                            >
                              <span>{slide.buttonText || 'Explore'}</span>
                              <ArrowRight className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* Right: Cover Image Box */}
                        <div className="relative flex justify-center">
                          <div className="relative aspect-video sm:aspect-square w-full max-w-[480px] sm:max-w-[340px] overflow-hidden rounded-[2.5rem] border-[10px] border-white bg-white shadow-xl dark:border-zinc-800 dark:bg-zinc-800">
                            <img
                              src={slide.image}
                              alt={slide.title}
                              referrerPolicy="no-referrer"
                              className="h-full w-full object-cover"
                              onError={(e) => {
                                e.currentTarget.src = "https://placehold.co/600x600/pink/white?text=No+Image";
                              }}
                            />
                          </div>
                        </div>

                      </div>
                    </div>
                  </motion.div>
                );
              }

              // Otherwise: Full-bleed background cover banner
              const hasCleanText = slide.title && 
                                   slide.title !== '00000000000u' && 
                                   slide.title.trim() !== '' &&
                                   slide.description && 
                                   slide.description !== 'dfvdd' && 
                                   slide.description.trim() !== '';

              return (
                <motion.div
                  key={slide.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.5 }}
                  className="w-full min-h-[500px] lg:min-h-[580px] relative flex items-center justify-center overflow-hidden cursor-pointer bg-zinc-950"
                  onClick={() => {
                    if (slide.linkTab) {
                      setCurrentTab(slide.linkTab);
                    }
                  }}
                >
                  {/* Full Background Image */}
                  <img
                    src={slide.image}
                    alt={slide.title || "Full Banner"}
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 h-full w-full object-cover select-none z-0"
                    onError={(e) => {
                      e.currentTarget.src = "https://placehold.co/1200x600/pink/white?text=No+Image";
                    }}
                  />
                  
                  {/* Gradient Overlay for Text Readability */}
                  {(hasCleanText || (slide.buttonText && slide.buttonText !== 'Shop Now')) && (
                    <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-transparent sm:bg-gradient-to-r sm:from-black/80 sm:via-black/40 sm:to-transparent z-10 pointer-events-none" />
                  )}

                  {/* Overlaid Content */}
                  {hasCleanText && (
                    <div className="relative z-20 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 w-full text-center sm:text-left text-white drop-shadow-md">
                      <div className="max-w-xl space-y-4 sm:space-y-6">
                        {slide.subtitle && (
                          <div className="inline-block px-3 py-1 bg-brand-pink/90 text-white text-xs font-bold rounded-full uppercase tracking-widest shadow-md">
                            {slide.subtitle}
                          </div>
                        )}
                        <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black leading-tight text-white">
                          {slide.title}
                        </h2>
                        <p className="text-xs sm:text-sm md:text-base text-zinc-100 font-medium leading-relaxed max-w-md">
                          {slide.description}
                        </p>
                        <div className="pt-2">
                          <button
                            onClick={(e) => {
                              e.stopPropagation(); // prevent double navigation
                              setCurrentTab(slide.linkTab || 'shop');
                            }}
                            className="inline-flex items-center justify-center space-x-2 rounded-full bg-brand-pink px-8 py-3.5 text-xs font-semibold uppercase tracking-widest text-white hover:bg-brand-pink-dark transition-transform hover:scale-105 active:scale-95 cursor-pointer shadow-lg border border-pink-400/30"
                          >
                            <span>{slide.buttonText || 'Explore'}</span>
                            <ArrowRight className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Floating CTA if text is hidden but a button exists */}
                  {!hasCleanText && slide.buttonText && slide.buttonText !== 'Shop Now' && (
                    <div className="absolute bottom-6 right-6 z-20">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setCurrentTab(slide.linkTab || 'shop');
                        }}
                        className="inline-flex items-center justify-center space-x-2 rounded-full bg-brand-pink px-6 py-2.5 text-xs font-semibold uppercase tracking-widest text-white hover:bg-brand-pink-dark transition-all hover:scale-105 shadow-xl border border-pink-400/30 cursor-pointer"
                      >
                        <span>{slide.buttonText}</span>
                        <ArrowRight className="h-3 w-3" />
                      </button>
                    </div>
                  )}
                </motion.div>
              );
            })()}
          </AnimatePresence>
        </div>

        {/* 1B. Slider Navigation Controls (Perfect Match to your Screenshot Bottom Bar) */}
        <div className="w-full bg-[#EFECE6] dark:bg-zinc-900/60 border-t border-zinc-200/50 dark:border-zinc-800 py-3 flex items-center justify-center space-x-4 select-none" id="slider-bottom-controls">
          
          {/* Previous Slide Button */}
          <button
            onClick={() => {
              setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
            }}
            className="p-1 text-zinc-500 hover:text-[#8C1E1E] dark:hover:text-amber-500 transition-colors"
            title="Previous Slide"
          >
            <ChevronLeft className="h-4.5 w-4.5" />
          </button>

          {/* Indicator dots */}
          <div className="flex items-center space-x-3">
            {Array.from({ length: slides.length }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrentSlide(idx)}
                className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                  currentSlide === idx 
                    ? 'bg-[#8C1E1E] dark:bg-amber-500 scale-110' 
                    : 'border-1.5 border-zinc-400 dark:border-zinc-600 bg-transparent'
                }`}
                title={`Go to Slide ${idx + 1}`}
              />
            ))}
          </div>

          {/* Next Slide Button */}
          <button
            onClick={() => {
              setCurrentSlide((prev) => (prev + 1) % slides.length);
            }}
            className="p-1 text-zinc-500 hover:text-[#8C1E1E] dark:hover:text-amber-500 transition-colors"
            title="Next Slide"
          >
            <ChevronRight className="h-4.5 w-4.5" />
          </button>

          {/* Vertical divider */}
          <span className="text-zinc-300 dark:text-zinc-700 text-xs font-semibold">|</span>

          {/* Pause/Play Button */}
          <button
            onClick={() => setIsPaused(!isPaused)}
            className="p-1 text-zinc-500 hover:text-[#8C1E1E] dark:hover:text-amber-500 transition-colors"
            title={isPaused ? "Play Autoplay" : "Pause Autoplay"}
          >
            {isPaused ? <Play className="h-3.5 w-3.5 fill-current" /> : <Pause className="h-3.5 w-3.5 fill-current" />}
          </button>

        </div>
      </section>

      {/* 2. Quick Categories Grid */}
      <section className="py-12 bg-white dark:bg-zinc-900 border-y border-zinc-100 dark:border-zinc-800" id="category-scroller">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-xs font-semibold uppercase tracking-widest text-brand-pink">Explore Our Collections</p>
          <h2 className="font-serif text-2xl font-normal text-zinc-900 dark:text-white mt-1">Shop by Category</h2>
          
          <div className="mt-8 flex flex-wrap justify-center gap-4">
            {(categories && categories.length > 0 
              ? categories.map(catName => {
                  const savedImg = categoryImages?.[catName];
                  if (savedImg) return { name: catName, img: savedImg };
                  
                  // Fallback: search if there are products with this category
                  const match = products.find(p => p.category === catName);
                  return {
                    name: catName,
                    img: match?.images?.[0] || 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=150'
                  };
                })
              : [
                  { name: 'Crochet Bags', img: 'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?q=80&w=150' },
                  { name: 'Crochet Flowers', img: 'https://images.unsplash.com/photo-1561181286-d3fee7d55364?q=80&w=150' },
                  { name: 'Hair Bands', img: 'https://images.unsplash.com/photo-1576243345690-4e4b79b63288?q=80&w=150' },
                  { name: 'Home Decoration', img: 'https://images.unsplash.com/photo-1513201099495-a636c5e5a59e?q=80&w=150' },
                  { name: 'Key Rings', img: 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?q=80&w=150' },
                  { name: 'Hair Accessories', img: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=150' }
                ]
            ).map((cat) => (
              <button
                key={cat.name}
                onClick={() => {
                  if (onFilterCategory) {
                    onFilterCategory(cat.name);
                  } else {
                    setCurrentTab('shop');
                  }
                }}
                className="group flex flex-col items-center p-2 rounded-2xl hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-all cursor-pointer"
              >
                <div className="h-16 w-16 overflow-hidden rounded-full border border-zinc-150 bg-zinc-50 group-hover:scale-105 group-hover:border-brand-pink transition-all">
                  <img
                    src={cat.img}
                    alt={cat.name}
                    referrerPolicy="no-referrer"
                    className="h-full w-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=150";
                    }}
                  />
                </div>
                <span className="mt-2 text-xs font-semibold text-zinc-700 dark:text-zinc-300 group-hover:text-brand-pink">
                  {cat.name}
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* 3. New Arrivals (With layout requirements) */}
      <section className="py-16 bg-white dark:bg-zinc-950" id="new-arrivals-section">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div className="text-left">
              <span className="text-xs font-semibold uppercase tracking-widest text-brand-pink">Fresh from the Loom</span>
              <h2 className="font-serif text-2.5xl font-normal text-zinc-900 dark:text-white mt-1">New Arrivals</h2>
            </div>
            <button
              onClick={() => setCurrentTab('new-arrivals')}
              className="text-xs font-bold uppercase tracking-widest text-brand-pink hover:underline transition-colors cursor-pointer"
            >
              View All New Arrivals
            </button>
          </div>

          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {newArrivals.map((product) => (
              <ProductItemCard
                key={product.id}
                product={product}
                onSelectProduct={onSelectProduct}
                onToggleWishlist={onToggleWishlist}
                isWishlisted={wishlist.includes(product.id)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 4. Best Sellers (With layout requirements) */}
      <section className="py-16 bg-white dark:bg-zinc-900 border-t border-zinc-100 dark:border-zinc-800" id="best-seller-section">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div className="text-left">
              <span className="text-xs font-semibold uppercase tracking-widest text-brand-pink">Most Loved Creations</span>
              <h2 className="font-serif text-2.5xl font-normal text-zinc-900 dark:text-white mt-1">Best Sellers</h2>
            </div>
            <button
              onClick={() => setCurrentTab('best-sellers')}
              className="text-xs font-bold uppercase tracking-widest text-brand-pink hover:underline transition-colors cursor-pointer"
            >
              View All Best Sellers
            </button>
          </div>

          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {bestSellers.map((product) => (
              <ProductItemCard
                key={product.id}
                product={product}
                onSelectProduct={onSelectProduct}
                onToggleWishlist={onToggleWishlist}
                isWishlisted={wishlist.includes(product.id)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 5. Custom Orders Callout Section */}
      <section className="relative py-16 overflow-hidden bg-brand-pink-light dark:bg-pink-950/10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center sm:text-left">
          <div className="grid grid-cols-1 gap-10 sm:grid-cols-12 items-center">
            <div className="sm:col-span-8 space-y-4">
              <span className="inline-block px-3 py-1 bg-white text-brand-pink text-xs font-bold rounded-full uppercase tracking-widest shadow-sm border border-pink-50 dark:bg-zinc-800 dark:text-pink-300 dark:border-zinc-700">
                Customization Available
              </span>
              <h2 className="font-serif text-3xl font-normal text-zinc-900 dark:text-white leading-tight">
                Have a design in mind? We will knit it for you!
              </h2>
              <p className="text-sm text-zinc-600 dark:text-zinc-300 max-w-xl">
                Whether it is a custom amigurumi caricature doll from your photos, a unique design of a handbag, custom color roses, or custom name tags - we can turn any wool fantasy into soft reality!
              </p>
            </div>
            <div className="sm:col-span-4 flex justify-center sm:justify-end">
              <button
                id="custom-order-callout-btn"
                onClick={() => setCurrentTab('custom-order')}
                className="inline-flex items-center space-x-2 rounded-full bg-zinc-950 px-8 py-3.5 text-xs font-semibold uppercase tracking-widest text-white hover:bg-zinc-800 dark:bg-white dark:text-zinc-950 dark:hover:bg-zinc-100 transition-colors shadow-sm cursor-pointer"
              >
                <span>Request Custom Order</span>
                <Compass className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Featured Products */}
      <section className="py-16 bg-white dark:bg-zinc-950 border-t border-zinc-100 dark:border-zinc-800" id="featured-products">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-xs font-semibold uppercase tracking-widest text-brand-pink">Selected Masterworks</span>
            <h2 className="font-serif text-3xl font-normal text-zinc-900 dark:text-white mt-1">Featured Products</h2>
            <p className="text-xs text-zinc-400 mt-2">Finest designs handpicked with 4.9+ star customer ratings</p>
          </div>

          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
            {featuredProducts.map((product) => (
              <ProductItemCard
                key={product.id}
                product={product}
                onSelectProduct={onSelectProduct}
                onToggleWishlist={onToggleWishlist}
                isWishlisted={wishlist.includes(product.id)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 7. Testimonials */}
      <section className="py-16 bg-white dark:bg-zinc-900 border-t border-zinc-100 dark:border-zinc-800" id="customer-testimonials">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <span className="text-xs font-semibold uppercase tracking-widest text-brand-pink">Heartwarming Stories</span>
            <h2 className="font-serif text-3xl font-normal text-zinc-900 dark:text-white mt-1">Customer Testimonials</h2>
          </div>

          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {testimonials.map((test, index) => (
              <div
                key={index}
                className="flex flex-col justify-between p-6 rounded-3xl border border-zinc-100 bg-zinc-50/50 dark:border-zinc-800 dark:bg-zinc-950/40 relative"
              >
                <div className="absolute top-6 right-6 text-brand-pink opacity-20 text-5xl font-serif select-none pointer-events-none">
                  “
                </div>
                
                <div className="space-y-4 text-left">
                  <div className="flex space-x-0.5 text-amber-400">
                    {Array.from({ length: test.rating }).map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                  <p className="text-sm italic text-zinc-600 dark:text-zinc-300 leading-relaxed">
                    "{test.text}"
                  </p>
                </div>

                <div className="flex items-center space-x-3 mt-6 pt-4 border-t border-zinc-100 dark:border-zinc-800">
                  <img
                    src={test.avatar}
                    alt={test.name}
                    referrerPolicy="no-referrer"
                    className="h-10 w-10 rounded-full object-cover"
                  />
                  <div className="text-left">
                    <span className="block text-xs font-bold text-zinc-800 dark:text-white">{test.name}</span>
                    <span className="block text-[10px] text-zinc-500">{test.role}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. Newsletter Subscription */}
      <section className="py-16 bg-brand-pink-light dark:bg-pink-950/10 border-t border-zinc-100 dark:border-zinc-800" id="newsletter-subscription">
        <div className="mx-auto max-w-md px-4 text-center">
          <span className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-white text-brand-pink mb-4 shadow-sm border border-pink-50 dark:bg-zinc-800">
            <Gift className="h-6 w-6" />
          </span>
          <h2 className="font-serif text-2xl font-normal text-zinc-900 dark:text-white">Get 10% Off Your First Order</h2>
          <p className="text-xs text-zinc-500 mt-2 mb-6">
            Subscribe to Salai Ghor newsletter to receive styling inspiration, sneak peeks at new collections, and an instant coupon code!
          </p>

          <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-2">
            <input
              type="email"
              placeholder="Enter your email address"
              value={emailInput}
              onChange={(e) => setEmailInput(e.target.value)}
              required
              className="flex-1 h-11 rounded-full border border-zinc-200 bg-white px-4 text-xs font-medium text-zinc-800 outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-900 dark:text-white dark:focus:border-pink-500"
              id="newsletter-email-input"
            />
            <button
              type="submit"
              id="newsletter-subscribe-btn"
              className="h-11 rounded-full bg-zinc-950 px-6 text-xs font-semibold uppercase tracking-widest text-white shadow-md hover:bg-zinc-800 transition-colors cursor-pointer dark:bg-white dark:text-zinc-950 dark:hover:bg-zinc-100"
            >
              Subscribe
            </button>
          </form>

          {newsletterSubscribed && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 p-3 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-300 text-xs font-semibold"
            >
              🎉 Success! Your secret 10% off code is <code className="bg-white/80 px-1.5 py-0.5 rounded dark:bg-zinc-900 text-brand-pink font-bold">WELCOME10</code>! Applied automatically on your next purchase.
            </motion.div>
          )}
        </div>
      </section>

    </div>
  );
}

/* Internal ProductItemCard helper */
interface ProductItemCardProps {
  key?: string;
  product: Product;
  onSelectProduct: (product: Product) => void;
  onToggleWishlist: (productId: string) => void;
  isWishlisted: boolean;
}

function ProductItemCard({ product, onSelectProduct, onToggleWishlist, isWishlisted }: ProductItemCardProps) {
  const currentPrice = product.discountPrice || product.price;
  const hasDiscount = !!product.discountPrice;
  const savingPercentage = hasDiscount ? Math.round(((product.price - product.discountPrice!) / product.price) * 100) : 0;

  return (
    <div
      onClick={() => onSelectProduct(product)}
      className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-zinc-200/80 bg-white p-3 shadow-sm hover:shadow-md dark:border-zinc-800 dark:bg-zinc-900 transition-all cursor-pointer"
      id={`product-card-${product.id}`}
    >
      
      {/* Product Image Area */}
      <div className="relative aspect-square w-full overflow-hidden rounded-xl bg-zinc-50 dark:bg-zinc-800 transform-gpu">
        <img
          src={product.images[0]}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300 transform-gpu will-change-transform"
        />

        {/* Badges */}
        {hasDiscount && (
          <span className="absolute top-3 left-3 rounded bg-red-500 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white">
            {savingPercentage}% OFF
          </span>
        )}

        {product.availability === 'Pre-order' && (
          <span className="absolute top-3 left-3 rounded bg-zinc-900 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white">
            Pre-order
          </span>
        )}

        {/* Wishlist Button */}
        <button
          id={`wishlist-toggle-${product.id}`}
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product.id);
          }}
          className="absolute top-3 right-3 flex h-8 w-8 items-center justify-center rounded-full bg-white text-zinc-400 shadow-sm hover:text-brand-pink dark:bg-zinc-900 dark:text-zinc-500 transition-colors"
          title="Add to Wishlist"
        >
          <Heart className={`h-4 w-4 ${isWishlisted ? 'fill-brand-pink text-brand-pink' : ''}`} />
        </button>
      </div>

      {/* Product Details */}
      <div className="flex flex-col p-2 text-left mt-3">
        <span className="text-[10px] font-bold uppercase tracking-widest text-brand-pink">
          {product.category}
        </span>
        
        <h3 className="font-sans text-sm font-bold text-zinc-950 dark:text-white mt-1 mb-1.5 group-hover:text-brand-pink transition-colors line-clamp-1">
          {product.name}
        </h3>
        
        <p className="text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2 mb-3 leading-relaxed">
          {product.shortDescription}
        </p>

        {/* Price & Action */}
        <div className="flex items-center justify-between pt-2.5 border-t border-zinc-100 dark:border-zinc-800 mt-auto">
          <div>
            <span className="text-sm font-bold text-zinc-950 dark:text-white">
              ₹{currentPrice}
            </span>
            {hasDiscount && (
              <span className="text-xs text-zinc-400 line-through ml-1.5">
                ₹{product.price}
              </span>
            )}
          </div>
          
          <div className="flex h-7 px-3 items-center justify-center rounded-full bg-zinc-50 text-zinc-700 text-[10px] font-semibold uppercase tracking-wider border border-zinc-200 group-hover:bg-zinc-950 group-hover:text-white group-hover:border-zinc-950 transition-colors dark:bg-zinc-800 dark:text-zinc-300 dark:border-zinc-700 dark:group-hover:bg-white dark:group-hover:text-zinc-950 dark:group-hover:border-white">
            <span>Details</span>
          </div>
        </div>
      </div>

    </div>
  );
}
