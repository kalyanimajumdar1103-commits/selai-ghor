import React, { useState } from 'react';
import { Mail, Phone, MapPin, Instagram, Facebook, Heart, Check, Compass, Ticket, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FooterProps {
  setCurrentTab: (tab: string) => void;
  openPolicyModal: (policyId: string) => void;
}

export default function Footer({ setCurrentTab, openPolicyModal }: FooterProps) {
  const [emailInput, setEmailInput] = useState('');
  const [isSubbed, setIsSubbed] = useState(false);

  const handleSub = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailInput.trim()) {
      setIsSubbed(true);
      setEmailInput('');
      setTimeout(() => setIsSubbed(false), 5000);
    }
  };

  const menuLinks = [
    { id: 'home', label: 'Home' },
    { id: 'shop', label: 'Shop' },
    { id: 'categories', label: 'Categories' },
    { id: 'new-arrivals', label: 'New Arrival' },
    { id: 'best-sellers', label: 'Best Seller' },
    { id: 'custom-order', label: 'Custom Order' },
    { id: 'about-us', label: 'About Us' },
    { id: 'contact', label: 'Contact' }
  ];

  const policyLinks = [
    { id: 'privacy', label: 'Privacy Policy' },
    { id: 'return', label: 'Return Policy' },
    { id: 'refund', label: 'Refund Policy' },
    { id: 'shipping', label: 'Shipping Policy' },
    { id: 'terms', label: 'Terms & Conditions' }
  ];

  return (
    <footer className="bg-zinc-900 text-zinc-400 border-t border-zinc-800" id="store-footer">
      
      {/* Top Footer Segment */}
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-12 text-left">
          
          {/* Brand Intro Column (lg:span-4) */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center space-x-2">
              <span className="font-serif text-xl tracking-widest text-white uppercase">
                Selai <span className="text-brand-pink font-light italic lowercase">ghor</span>
              </span>
            </div>
            
            <p className="text-xs text-zinc-400 leading-relaxed max-w-xs">
              Handcrafting beautiful, timeless, premium crochet and wool accessories with unconditional care and love. Unique art that never fades.
            </p>

            {/* Social media anchors */}
            <div className="flex space-x-3 pt-2">
              <a
                href="https://www.instagram.com/crafty_deepika98?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="
                target="_blank"
                rel="noreferrer"
                className="flex h-8 w-8 items-center justify-center rounded-full bg-zinc-800 text-zinc-300 hover:bg-brand-pink hover:text-white transition-colors"
                title="Follow Deepika on Instagram"
              >
                <Instagram className="h-4 w-4" />
              </a>
              
              <a
                href="https://www.facebook.com/deepika.bose.614118"
                target="_blank"
                rel="noreferrer"
                className="flex h-8 w-8 items-center justify-center rounded-full bg-zinc-800 text-zinc-300 hover:bg-brand-pink hover:text-white transition-colors"
                title="Follow Deepika on Facebook"
              >
                <Facebook className="h-4 w-4" />
              </a>

              <a
                href="https://www.google.com/maps/place/Kalyani+9+no.+Bus+Stand/@22.9771559,88.4254074,3a,65.2y,37.17h,88.23t/data=!3m7!1e1!3m5!1smAaQxeaytObibOh9LgC3Jg!2e0!6shttps:%2F%2Fstreetviewpixels-pa.googleapis.com%2Fv1%2Fthumbnail%3Fcb_client%3Dmaps_sv.tactile%26w%3D900%26h%3D600%26pitch%3D1.767054184513512%26panoid%3DmAaQxeaytObibOh9LgC3Jg%26yaw%3D37.17391542755566!7i16384!8i8192!4m6!3m5!1s0x39f895002b543ca3:0xb24c1db2fc8d00f0!8m2!3d22.9799114!4d88.4254417!16s%2Fg%2F11yd7mgpb2?entry=ttu&g_ep=EgoyMDI2MDcxNC4wIKXMDSoASAFQAw%3D%3D"
                target="_blank"
                rel="noreferrer"
                className="flex h-8 w-8 items-center justify-center rounded-full bg-zinc-800 text-zinc-300 hover:bg-brand-pink hover:text-white transition-colors"
                title="View Workshop on Google Maps"
              >
                <MapPin className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Quick Links Column (lg:span-3) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-zinc-200">
              Navigation
            </h4>
            <ul className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
              {menuLinks.map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => {
                      setCurrentTab(link.id);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="hover:text-brand-pink transition-colors cursor-pointer text-left"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Policy Links Column (lg:span-2) */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-zinc-200">
              Policies
            </h4>
            <ul className="space-y-2 text-xs">
              {policyLinks.map((p) => (
                <li key={p.id}>
                  <button
                    onClick={() => openPolicyModal(p.id)}
                    className="hover:text-brand-pink transition-colors text-left cursor-pointer"
                  >
                    {p.label}
                  </button>
                </li>
              ))}
              <li>
                <button
                  onClick={() => {
                    setCurrentTab('about-us');
                    setTimeout(() => {
                      document.getElementById('faqs-container')?.scrollIntoView({ behavior: 'smooth' });
                    }, 100);
                  }}
                  className="hover:text-brand-pink transition-colors text-left cursor-pointer flex items-center space-x-1"
                >
                  <HelpCircle className="h-3.5 w-3.5" />
                  <span>Store FAQs</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Mini newsletter column (lg:span-3) */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-zinc-200">
              Newsletter
            </h4>
            <p className="text-[11px] text-zinc-400">
              Receive updates on new collections, sales, and special crochet tips.
            </p>

            <form onSubmit={handleSub} className="flex flex-col gap-2">
              <input
                type="email"
                placeholder="Email address"
                value={emailInput}
                onChange={(e) => setEmailInput(e.target.value)}
                required
                className="h-9 rounded-xl bg-zinc-800 border border-zinc-700 px-3 text-xs text-white outline-none focus:border-brand-pink"
                id="footer-email-input"
              />
              <button
                type="submit"
                id="footer-sub-btn"
                className="h-9 rounded-xl bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark transition-colors cursor-pointer"
              >
                Join Clan
              </button>
            </form>

            {isSubbed && (
              <span className="block text-[10px] text-brand-green font-semibold">
                🎉 Applied code: <strong className="underline">WELCOME10</strong> (10% off)!
              </span>
            )}
          </div>

        </div>
      </div>

      {/* Bottom Segment */}
      <div className="border-t border-zinc-800 bg-zinc-950 py-6 text-center text-xs">
        <p className="flex items-center justify-center space-x-1">
          <span>&copy; {new Date().getFullYear()} Selai Ghor. All Rights Reserved.</span>
          <span className="text-zinc-600">|</span>
          <span>Crafted with</span>
          <Heart className="h-3 w-3 text-brand-pink fill-brand-pink animate-pulse" />
          <span>for Crochet & Wool Art Lovers.</span>
        </p>
      </div>

    </footer>
  );
}
