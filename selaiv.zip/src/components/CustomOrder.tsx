import React, { useState } from 'react';
import { Gift, Compass, Sparkles, MessageCircle, ArrowRight, ShieldCheck, FileText, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CustomOrderProps {
  currentUser?: any;
  setCurrentTab?: (tab: string) => void;
}

export default function CustomOrder({ currentUser, setCurrentTab }: CustomOrderProps) {
  const [custName, setCustName] = useState('');
  const [custPhone, setCustPhone] = useState('');
  const [customType, setCustomType] = useState('Amigurumi Portrait Doll');
  const [customDetails, setCustomDetails] = useState('');
  const [customSize, setCustomSize] = useState('Medium (6-8 inches)');
  const [customColors, setCustomColors] = useState('');
  const [customNote, setCustomNote] = useState('');
  
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!custName.trim() || !custPhone.trim() || !customDetails.trim()) {
      alert('Please fill out all required fields.');
      return;
    }

    // Build WhatsApp message
    const waNumber = '+918100226410';
    const waText = `*New Custom Order Inquiry - Selai Ghor* 🌸

*Customer Name:* ${custName}
*Phone Number:* ${custPhone}
*Product Type:* ${customType}
*Size Preference:* ${customSize}
*Color Choices:* ${customColors || 'Handpicked by artisan'}
*Customization Details:* ${customDetails}
*Additional Note:* ${customNote || 'None'}

Please guide me with the quote and estimated timeframe. Thank you!`;

    const encodedText = encodeURIComponent(waText);
    const waUrl = `https://wa.me/${waNumber.replace(/\+/g, '').replace(/\s+/g, '')}?text=${encodedText}`;
    
    setFormSubmitted(true);
    
    // Redirect after brief delay
    setTimeout(() => {
      window.open(waUrl, '_blank');
      setFormSubmitted(false);
      
      // Reset form
      setCustName('');
      setCustPhone('');
      setCustomDetails('');
      setCustomColors('');
      setCustomNote('');
    }, 1500);
  };

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8 text-left" id="custom-order-view">
      
      {/* Intro section */}
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="inline-flex h-12 w-12 items-center justify-center rounded-full bg-brand-purple-light text-brand-purple mb-4 dark:bg-purple-950/30">
          <Gift className="h-6 w-6" />
        </span>
        <h1 className="font-display text-2xl font-extrabold sm:text-3xl text-zinc-900 dark:text-white">
          Bespoke Handmade Custom Creations
        </h1>
        <p className="text-xs text-zinc-500 mt-2">
          Submit your requirements below. Our skilled artisans will carefully handcraft any amigurumi portrait dolls, custom bags, or wool decorations exactly to your preferences.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-8 md:grid-cols-12 items-start">
        
        {/* Info Column (md:span-5) */}
        <div className="md:col-span-5 space-y-6 md:sticky md:top-24">
          <div className="p-6 rounded-3xl border border-purple-100 bg-brand-purple-light/20 space-y-4 dark:border-zinc-800 dark:bg-purple-950/10">
            <h3 className="font-display text-sm font-bold text-brand-purple">
              How Custom Orders Work
            </h3>
            
            <ul className="space-y-3.5 text-xs text-zinc-600 dark:text-zinc-300">
              <li className="flex items-start space-x-2">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-brand-purple text-[10px] font-bold text-white mt-0.5">
                  1
                </span>
                <div>
                  <strong className="block text-zinc-800 dark:text-white">Describe Your Design</strong>
                  <span>Provide details like references, colors, yarn preferences, and sizes.</span>
                </div>
              </li>
              
              <li className="flex items-start space-x-2">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-brand-purple text-[10px] font-bold text-white mt-0.5">
                  2
                </span>
                <div>
                  <strong className="block text-zinc-800 dark:text-white">Connect on WhatsApp</strong>
                  <span>Submitting this form redirects you to WhatsApp with pre-filled details to secure details.</span>
                </div>
              </li>

              <li className="flex items-start space-x-2">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-brand-purple text-[10px] font-bold text-white mt-0.5">
                  3
                </span>
                <div>
                  <strong className="block text-zinc-800 dark:text-white">Handcrafted with Love</strong>
                  <span>We confirm quotes, craft your items (takes 8-12 days), and ship straight to your door!</span>
                </div>
              </li>
            </ul>
          </div>

          <div className="grid grid-cols-2 gap-4 text-center">
            <div className="p-4 rounded-2xl border border-pink-100 bg-white dark:border-zinc-800 dark:bg-zinc-900">
              <ShieldCheck className="h-6 w-6 text-brand-pink mx-auto mb-1" />
              <span className="block text-xs font-bold text-zinc-800 dark:text-white">Premium Quality</span>
              <span className="block text-[10px] text-zinc-400 mt-0.5">Combed cotton wool</span>
            </div>
            
            <div className="p-4 rounded-2xl border border-pink-100 bg-white dark:border-zinc-800 dark:bg-zinc-900">
              <Sparkles className="h-6 w-6 text-brand-green mx-auto mb-1" />
              <span className="block text-xs font-bold text-zinc-800 dark:text-white">Eco Packing</span>
              <span className="block text-[10px] text-zinc-400 mt-0.5">Perfect gift wraps</span>
            </div>
          </div>
        </div>

        {/* Form Column (md:span-7) */}
        <div className="md:col-span-7 p-6 sm:p-8 rounded-3xl border border-pink-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">
          {!currentUser ? (
            <div className="flex flex-col items-center justify-center text-center py-12 px-4 min-h-[350px]" id="custom-order-login-wall">
              <div className="h-14 w-14 rounded-full bg-pink-50 text-brand-pink flex items-center justify-center mb-5 dark:bg-pink-950/20">
                <Gift className="h-7 w-7" />
              </div>
              <h3 className="font-display text-base font-bold text-zinc-800 dark:text-white">Account Login Required</h3>
              <p className="text-xs text-zinc-500 mt-2 max-w-sm leading-relaxed">
                To request custom handcrafted portrait caricature dolls, bags, or wool art, please log in to your account. This lets our artisans save your design specifications and track progress.
              </p>
              <button
                type="button"
                onClick={() => setCurrentTab && setCurrentTab('account')}
                className="mt-6 rounded-full bg-brand-pink px-7 py-3 text-xs font-bold text-white hover:bg-brand-pink-dark transition-all cursor-pointer shadow-md shadow-pink-100 dark:shadow-none"
              >
                Sign In or Register
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                    Full Name <span className="text-brand-pink">*</span>
                  </label>
                  <input
                    type="text"
                    placeholder="Your full name"
                    value={custName}
                    onChange={(e) => setCustName(e.target.value)}
                    required
                    className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                    id="custom-order-name"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                    Phone Number <span className="text-brand-pink">*</span>
                  </label>
                  <input
                    type="tel"
                    placeholder="Your active WhatsApp number"
                    value={custPhone}
                    onChange={(e) => setCustPhone(e.target.value)}
                    required
                    className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                    id="custom-order-phone"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                    Product Category
                  </label>
                  <select
                    value={customType}
                    onChange={(e) => setCustomType(e.target.value)}
                    className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                    id="custom-order-type"
                  >
                    <option value="Amigurumi Portrait Doll" className="bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white">Amigurumi Portrait Doll (Custom caricature)</option>
                    <option value="Custom Handbag / Tote" className="bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white">Custom Handbag / Crochet Tote</option>
                    <option value="Home Ornament / Coasters" className="bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white">Home Ornament / Coaster Set</option>
                    <option value="Special Festival Shawl / Beanie" className="bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white">Special Festival Shawl / Beanie</option>
                    <option value="Personalized Baby Gift Set" className="bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white">Personalized Baby Gift Set</option>
                    <option value="Other / Miscellaneous Idea" className="bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white">Other unique ideas</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                    Size Preference
                  </label>
                  <select
                    value={customSize}
                    onChange={(e) => setCustomSize(e.target.value)}
                    className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                    id="custom-order-size"
                  >
                    <option value="Mini (2-4 inches)" className="bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white">Mini (2-4 inches) - perfect key rings</option>
                    <option value="Medium (6-8 inches)" className="bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white">Medium (6-8 inches) - great dolls & cups</option>
                    <option value="Large (10-15 inches)" className="bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white">Large (10-15 inches) - tote bags, blankets</option>
                    <option value="Custom / Unspecified" className="bg-white text-zinc-900 dark:bg-zinc-950 dark:text-white">Custom sizing specifications</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                  Colors Preference
                </label>
                <input
                  type="text"
                  placeholder="e.g. Lavender purple, pastel yellow, sage green leaves..."
                  value={customColors}
                  onChange={(e) => setCustomColors(e.target.value)}
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                  id="custom-order-colors"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                  Customization Details <span className="text-brand-pink">*</span>
                </label>
                <textarea
                  rows={4}
                  placeholder="Please describe your customization requirements in detail. What are we crocheting? Let us know the style, eyes, colors, shapes..."
                  value={customDetails}
                  onChange={(e) => setCustomDetails(e.target.value)}
                  required
                  className="w-full rounded-xl border border-zinc-200 p-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                  id="custom-order-details"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                  Additional Instructions / Request (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="Any special wrapping notes, delivery deadline constraints, etc."
                  value={customNote}
                  onChange={(e) => setCustomNote(e.target.value)}
                  className="w-full rounded-xl border border-zinc-200 p-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                  id="custom-order-note"
                />
              </div>

              <button
                type="submit"
                id="custom-order-submit-btn"
                className="w-full h-12 rounded-full bg-brand-pink text-xs font-bold text-white shadow hover:bg-brand-pink-dark transition-all flex items-center justify-center space-x-2 cursor-pointer"
              >
                <MessageCircle className="h-4.5 w-4.5" />
                <span>Discuss details on WhatsApp</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </form>
          )}

          {formSubmitted && currentUser && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 p-3 rounded-xl bg-emerald-100 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-300 text-xs font-bold flex items-center justify-center space-x-2"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>Connecting you to Selai Ghor WhatsApp support channel (+91 81002 26410)...</span>
            </motion.div>
          )}
        </div>

      </div>

    </div>
  );
}
