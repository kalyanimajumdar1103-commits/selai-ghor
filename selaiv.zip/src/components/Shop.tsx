import React, { useState, useEffect } from 'react';
import { SlidersHorizontal, Search, ArrowUpDown, RefreshCw, Star, Heart, X, Sparkles, AlertCircle } from 'lucide-react';
import { Product } from '../types';
import { CATEGORIES } from '../data';

interface ShopProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onToggleWishlist: (productId: string) => void;
  wishlist: string[];
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  recentlyViewed: Product[];
}

export default function Shop({
  products,
  onSelectProduct,
  onToggleWishlist,
  wishlist,
  searchQuery,
  setSearchQuery,
  recentlyViewed
}: ShopProps) {
  // Filters State
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [maxPrice, setMaxPrice] = useState<number>(2500);
  const [selectedColors, setSelectedColors] = useState<string[]>([]);
  const [selectedAvailability, setSelectedAvailability] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState<string>('featured');
  const [showFiltersMobile, setShowFiltersMobile] = useState(false);

  // Derive unique colors from products list
  const allColors = Array.from(
    new Set(products.flatMap(p => p.colorOptions).filter(c => c !== 'Custom (Based on Photo)'))
  );

  // Live filter products
  const filteredProducts = products.filter(product => {
    // 1. Search Query filter (checks: name, category, colors, price)
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      const matchName = product.name.toLowerCase().includes(query);
      const matchCategory = product.category.toLowerCase().includes(query);
      const matchColors = product.colorOptions.some(color => color.toLowerCase().includes(query));
      const matchPrice = (`${product.discountPrice || product.price}`).includes(query);

      if (!matchName && !matchCategory && !matchColors && !matchPrice) {
        return false;
      }
    }

    // 2. Category filter
    if (selectedCategories.length > 0 && !selectedCategories.includes(product.category)) {
      return false;
    }

    // 3. Price filter
    const currentPrice = product.discountPrice || product.price;
    if (currentPrice > maxPrice) {
      return false;
    }

    // 4. Color filter
    if (selectedColors.length > 0) {
      const hasMatchingColor = product.colorOptions.some(color => selectedColors.includes(color));
      if (!hasMatchingColor) {
        return false;
      }
    }

    // 5. Availability filter
    if (selectedAvailability.length > 0 && !selectedAvailability.includes(product.availability)) {
      return false;
    }

    return true;
  });

  // Sort filtered products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    const priceA = a.discountPrice || a.price;
    const priceB = b.discountPrice || b.price;

    switch (sortBy) {
      case 'price-asc':
        return priceA - priceB;
      case 'price-desc':
        return priceB - priceA;
      case 'rating':
        return b.rating - a.rating;
      case 'name-asc':
        return a.name.localeCompare(b.name);
      case 'featured':
      default:
        return 0; // maintain original order
    }
  });

  // Reset all filters
  const handleResetFilters = () => {
    setSelectedCategories([]);
    setMaxPrice(2500);
    setSelectedColors([]);
    setSelectedAvailability([]);
    setSortBy('featured');
    setSearchQuery('');
  };

  const handleCategoryToggle = (category: string) => {
    setSelectedCategories(prev =>
      prev.includes(category) ? prev.filter(c => c !== category) : [...prev, category]
    );
  };

  const handleColorToggle = (color: string) => {
    setSelectedColors(prev =>
      prev.includes(color) ? prev.filter(c => c !== color) : [...prev, color]
    );
  };

  const handleAvailabilityToggle = (avail: string) => {
    setSelectedAvailability(prev =>
      prev.includes(avail) ? prev.filter(a => a !== avail) : [...prev, avail]
    );
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 text-left" id="shop-catalog-view">
      
      {/* Search Header Banner */}
      <div className="rounded-2xl bg-[#FFF0F5] p-6 md:p-10 mb-8 border border-zinc-100 dark:bg-zinc-900 dark:border-zinc-800">
        <span className="text-xs font-semibold uppercase tracking-widest text-brand-pink">Selai Ghor Catalog</span>
        <h1 className="font-serif text-2xl font-normal sm:text-3xl text-zinc-900 dark:text-white mt-1">
          Explore Hand-stitched Wonders
        </h1>
        <p className="text-xs text-zinc-500 mt-2 max-w-xl">
          Filtered by premium non-pilling combed cotton. Enter search criteria or customize details to find your perfect match.
        </p>

        {/* Centralised search input inside the shop */}
        <div className="relative max-w-md mt-6">
          <Search className="absolute top-1/2 left-3.5 h-4 w-4 -translate-y-1/2 text-zinc-400" />
          <input
            type="text"
            placeholder="Search by name, category, color, price..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-11 w-full rounded-full border border-zinc-200 bg-white pl-10 pr-4 text-xs font-semibold text-zinc-800 shadow-sm outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
            id="shop-internal-search"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute top-1/2 right-3.5 -translate-y-1/2 text-xs font-bold text-zinc-400 hover:text-brand-pink"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Control Bar: Filters toggle, sorting, item counts */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-8 pb-4 border-b border-zinc-100 dark:border-zinc-800" id="shop-control-bar">
        <div className="flex items-center space-x-3">
          <button
            id="mobile-filter-toggle-btn"
            onClick={() => setShowFiltersMobile(true)}
            className="flex h-10 items-center space-x-2 rounded-full border border-zinc-200 bg-white px-4 text-xs font-bold text-zinc-700 hover:border-brand-pink hover:text-brand-pink lg:hidden dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-300"
          >
            <SlidersHorizontal className="h-4 w-4" />
            <span>Filters</span>
          </button>
          
          <span className="text-xs font-semibold text-zinc-500 dark:text-zinc-400" id="shop-result-count">
            Showing {sortedProducts.length} of {products.length} unique items
          </span>
        </div>

        {/* Sorting Dropdown */}
        <div className="flex items-center space-x-2">
          <ArrowUpDown className="h-4 w-4 text-zinc-400" />
          <select
            id="shop-sort-select"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="h-10 rounded-xl border border-zinc-200 px-3 text-xs font-bold text-zinc-700 outline-none focus:border-brand-pink dark:border-zinc-800 bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100"
          >
            <option value="featured" className="bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100">Featured / Default</option>
            <option value="price-asc" className="bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100">Price: Low to High</option>
            <option value="price-desc" className="bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100">Price: High to Low</option>
            <option value="rating" className="bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100">Rating: High to Low</option>
            <option value="name-asc" className="bg-white text-zinc-900 dark:bg-zinc-900 dark:text-zinc-100">Alphabetical: A to Z</option>
          </select>
        </div>
      </div>

      {/* Grid Split: Sidebar vs Grid List */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-4">
        
        {/* Desktop Sidebar Filters (lg:span-1) */}
        <aside className="hidden lg:block space-y-6" id="desktop-filters-sidebar">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-800 dark:text-white">
              Filter By
            </h3>
            <button
              onClick={handleResetFilters}
              className="text-[10px] font-bold uppercase tracking-widest text-brand-pink hover:text-brand-pink-dark"
            >
              Reset All
            </button>
          </div>

          <hr className="border-zinc-100 dark:border-zinc-800" />

          {/* Categories checkboxes */}
          <div className="space-y-3">
            <span className="block text-[11px] font-bold text-zinc-400 uppercase tracking-widest dark:text-zinc-500">
              Categories
            </span>
            <div className="space-y-2">
              {CATEGORIES.map((cat) => (
                <label key={cat} className="flex items-center space-x-2.5 text-xs font-semibold text-zinc-600 dark:text-zinc-400 cursor-pointer hover:text-brand-pink">
                  <input
                    type="checkbox"
                    checked={selectedCategories.includes(cat)}
                    onChange={() => handleCategoryToggle(cat)}
                    className="h-4 w-4 rounded text-brand-pink focus:ring-brand-pink"
                  />
                  <span>{cat}</span>
                </label>
              ))}
            </div>
          </div>

          <hr className="border-zinc-100 dark:border-zinc-800" />

          {/* Price Range Slider */}
          <div className="space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-zinc-400 uppercase tracking-widest dark:text-zinc-500">
                Price Limit
              </span>
              <span className="font-bold text-brand-pink">
                ₹{maxPrice}
              </span>
            </div>
            <input
              type="range"
              min="100"
              max="2500"
              step="50"
              value={maxPrice}
              onChange={(e) => setMaxPrice(Number(e.target.value))}
              className="w-full h-1 bg-zinc-200 rounded-lg appearance-none cursor-pointer accent-brand-pink dark:bg-zinc-800"
            />
            <div className="flex justify-between text-[10px] font-semibold text-zinc-400">
              <span>₹100</span>
              <span>₹2500</span>
            </div>
          </div>

          <hr className="border-zinc-100 dark:border-zinc-800" />

          {/* Colors Filter */}
          <div className="space-y-3">
            <span className="block text-[11px] font-bold text-zinc-400 uppercase tracking-widest dark:text-zinc-500">
              Color Options
            </span>
            <div className="flex flex-wrap gap-1.5">
              {allColors.map((color) => (
                <button
                  key={color}
                  id={`filter-color-${color.replace(/\s+/g, '-')}`}
                  onClick={() => handleColorToggle(color)}
                  className={`rounded-xl px-2.5 py-1.5 text-[10px] font-bold transition-all cursor-pointer ${
                    selectedColors.includes(color)
                      ? 'bg-zinc-950 text-white dark:bg-white dark:text-zinc-950'
                      : 'border border-zinc-200 bg-white text-zinc-600 hover:border-brand-pink hover:bg-zinc-50 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-400'
                  }`}
                >
                  {color}
                </button>
              ))}
            </div>
          </div>

          <hr className="border-zinc-100 dark:border-zinc-800" />

          {/* Availability Filter */}
          <div className="space-y-3">
            <span className="block text-[11px] font-bold text-zinc-400 uppercase tracking-widest dark:text-zinc-500">
              Availability
            </span>
            <div className="space-y-2">
              {['In Stock', 'Out of Stock', 'Pre-order'].map((status) => (
                <label key={status} className="flex items-center space-x-2.5 text-xs font-semibold text-zinc-600 dark:text-zinc-400 cursor-pointer hover:text-brand-pink">
                  <input
                    type="checkbox"
                    checked={selectedAvailability.includes(status)}
                    onChange={() => handleAvailabilityToggle(status)}
                    className="h-4 w-4 rounded text-brand-pink focus:ring-brand-pink"
                  />
                  <span>{status}</span>
                </label>
              ))}
            </div>
          </div>

        </aside>

        {/* Products Grid List (lg:span-3) */}
        <section className="lg:col-span-3">
          
          {sortedProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center rounded-3xl border border-dashed border-zinc-200 bg-zinc-50/50 p-6 dark:border-zinc-800 dark:bg-zinc-950/40">
              <AlertCircle className="h-10 w-10 text-brand-pink mb-4" />
              <h3 className="font-display text-base font-bold text-zinc-800 dark:text-white">
                No creations found
              </h3>
              <p className="text-xs text-zinc-500 mt-1 max-w-sm">
                We couldn't find any products matching your specific search parameters or filter criteria. Try resetting the filters.
              </p>
              <button
                onClick={handleResetFilters}
                className="mt-6 rounded-full bg-brand-pink px-6 py-2.5 text-xs font-bold text-white shadow hover:bg-brand-pink-dark transition-colors"
              >
                Reset Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-4 2xl:grid-cols-4">
              {sortedProducts.map((product) => {
                const currentPrice = product.discountPrice || product.price;
                const hasDiscount = !!product.discountPrice;
                const savingPercentage = hasDiscount ? Math.round(((product.price - product.discountPrice!) / product.price) * 100) : 0;
                const isWishlisted = wishlist.includes(product.id);

                return (
                  <div
                    key={product.id}
                    id={`shop-product-card-${product.id}`}
                    onClick={() => onSelectProduct(product)}
                    className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-zinc-200/80 bg-white p-3 shadow-sm hover:shadow-md dark:border-zinc-800 dark:bg-zinc-900 transition-all cursor-pointer"
                  >
                    
                    {/* Image block */}
                    <div className="relative aspect-square w-full overflow-hidden rounded-xl bg-zinc-50 dark:bg-zinc-800 transform-gpu">
                      <img
                        src={product.images[0]}
                        alt={product.name}
                        referrerPolicy="no-referrer"
                        className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300 transform-gpu will-change-transform"
                      />

                      {/* Overlays */}
                      {hasDiscount && (
                        <span className="absolute top-3 left-3 rounded bg-red-500 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white">
                          {savingPercentage}% OFF
                        </span>
                      )}

                      {product.availability === 'Pre-order' && (
                        <span className="absolute top-3 left-3 rounded bg-zinc-900 px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white">
                          Pre-order
                        </span>
                      )}

                      {/* Wishlist Toggle button */}
                      <button
                        id={`wishlist-btn-shop-${product.id}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleWishlist(product.id);
                        }}
                        className="absolute top-3 right-3 flex h-8 w-8 items-center justify-center rounded-full bg-white text-zinc-400 shadow-sm hover:text-brand-pink dark:bg-zinc-900 dark:text-zinc-500 transition-colors"
                      >
                        <Heart className={`h-4 w-4 ${isWishlisted ? 'fill-brand-pink text-brand-pink' : ''}`} />
                      </button>
                    </div>

                    {/* Details block */}
                    <div className="flex flex-col p-2 mt-3 text-left">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-brand-pink">
                        {product.category}
                      </span>
                      
                      <h3 className="font-sans text-sm font-bold text-zinc-950 dark:text-white mt-1 mb-1.5 group-hover:text-brand-pink transition-colors line-clamp-1">
                        {product.name}
                      </h3>
                      
                      <p className="text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2 mb-3 leading-relaxed">
                        {product.shortDescription}
                      </p>

                      <div className="flex items-center justify-between pt-2.5 border-t border-zinc-100 dark:border-zinc-800 mt-auto">
                        <div>
                          <span className="text-sm font-bold text-zinc-950 dark:text-white">
                            ₹{currentPrice}
                          </span>
                          {hasDiscount && (
                            <span className="text-xs text-zinc-400 line-through ml-1.5">
                              ₹{product.price}
                            </span>
                          )}
                        </div>
                        
                        <div className="flex h-7 px-3 items-center justify-center rounded-full bg-zinc-50 text-zinc-700 text-[10px] font-semibold uppercase tracking-wider border border-zinc-200 group-hover:bg-zinc-950 group-hover:text-white group-hover:border-zinc-950 transition-colors dark:bg-zinc-800 dark:text-zinc-300 dark:border-zinc-700 dark:group-hover:bg-white dark:group-hover:text-zinc-950 dark:group-hover:border-white">
                          <span>Details</span>
                        </div>
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          )}

        </section>

      </div>

      {/* Recently Viewed Products Panel */}
      {recentlyViewed.length > 0 && (
        <section className="mt-16 border-t border-zinc-100 pt-12 dark:border-zinc-800" id="recently-viewed-section">
          <div className="flex items-center space-x-2 mb-6">
            <Sparkles className="h-4.5 w-4.5 text-brand-pink" />
            <h2 className="font-serif text-lg font-normal text-zinc-900 dark:text-white">
              Recently Viewed Products
            </h2>
          </div>

          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4 md:grid-cols-5">
            {recentlyViewed.map((viewedProd) => {
              const viewedPrice = viewedProd.discountPrice || viewedProd.price;
              return (
                <div
                  key={viewedProd.id}
                  onClick={() => {
                    onSelectProduct(viewedProd);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="group block p-2 rounded-2xl border border-zinc-100 bg-white hover:-translate-y-0.5 hover:shadow-sm transition-all cursor-pointer dark:border-zinc-800 dark:bg-zinc-900 text-left"
                  id={`recent-viewed-card-${viewedProd.id}`}
                >
                  <div className="aspect-square w-full overflow-hidden rounded-xl bg-zinc-50 dark:bg-zinc-800">
                    <img
                      src={viewedProd.images[0]}
                      alt={viewedProd.name}
                      referrerPolicy="no-referrer"
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <h4 className="font-display text-[11px] font-bold text-zinc-800 mt-2 truncate dark:text-zinc-200 group-hover:text-brand-pink">
                    {viewedProd.name}
                  </h4>
                  <span className="block text-xs font-extrabold text-zinc-900 dark:text-white mt-0.5">
                    ₹{viewedPrice}
                  </span>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Mobile Filters Side Drawer */}
      {showFiltersMobile && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          
          {/* Backdrop */}
          <div
            onClick={() => setShowFiltersMobile(false)}
            className="fixed inset-0 bg-black/40"
          />

          {/* Drawer Panel */}
          <div className="relative ml-auto flex h-full w-72 flex-col overflow-y-auto bg-white p-6 shadow-xl dark:bg-zinc-900 text-left">
            <div className="flex items-center justify-between mb-4">
              <span className="font-display text-sm font-bold uppercase tracking-wider text-zinc-800 dark:text-white">
                Filters
              </span>
              <button
                onClick={() => setShowFiltersMobile(false)}
                className="flex h-8 w-8 items-center justify-center rounded-full bg-zinc-100 text-zinc-500 hover:text-brand-pink dark:bg-zinc-800 dark:text-zinc-400"
              >
                <X className="h-4.5 w-4.5" />
              </button>
            </div>

            <button
              onClick={() => {
                handleResetFilters();
                setShowFiltersMobile(false);
              }}
              className="w-full text-center py-2.5 border border-zinc-200 rounded-xl text-[10px] font-bold uppercase tracking-widest text-zinc-700 bg-zinc-50 hover:bg-zinc-100 mb-6 dark:bg-zinc-800 dark:text-zinc-300 dark:border-zinc-700"
            >
              Reset All Filters
            </button>

            {/* Sidebar content copy */}
            <div className="space-y-6">
              
              {/* Categories */}
              <div className="space-y-3">
                <span className="block text-xs font-bold text-zinc-500 uppercase tracking-widest dark:text-zinc-400">
                  Categories
                </span>
                <div className="space-y-2">
                  {CATEGORIES.map((cat) => (
                    <label key={cat} className="flex items-center space-x-2.5 text-xs font-semibold text-zinc-600 dark:text-zinc-400 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedCategories.includes(cat)}
                        onChange={() => handleCategoryToggle(cat)}
                        className="h-4 w-4 rounded text-brand-pink focus:ring-brand-pink"
                      />
                      <span>{cat}</span>
                    </label>
                  ))}
                </div>
              </div>

              <hr className="border-zinc-100 dark:border-zinc-800" />

              {/* Price limit */}
              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-zinc-500 uppercase tracking-widest dark:text-zinc-400">
                    Price Limit
                  </span>
                  <span className="font-bold text-brand-pink">
                    ₹{maxPrice}
                  </span>
                </div>
                <input
                  type="range"
                  min="100"
                  max="2500"
                  step="50"
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(Number(e.target.value))}
                  className="w-full h-1 bg-zinc-200 rounded-lg appearance-none cursor-pointer accent-brand-pink dark:bg-zinc-800"
                />
              </div>

              <hr className="border-zinc-100 dark:border-zinc-800" />

              {/* Colors */}
              <div className="space-y-3">
                <span className="block text-xs font-bold text-zinc-500 uppercase tracking-widest dark:text-zinc-400">
                  Colors
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {allColors.map((color) => (
                    <button
                      key={color}
                      onClick={() => handleColorToggle(color)}
                      className={`rounded-xl px-2.5 py-1 text-[10px] font-bold transition-all cursor-pointer ${
                        selectedColors.includes(color)
                          ? 'bg-zinc-950 text-white dark:bg-white dark:text-zinc-950'
                          : 'border border-zinc-200 bg-white text-zinc-600 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-400'
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>

              <hr className="border-zinc-100 dark:border-zinc-800" />

              {/* Availability */}
              <div className="space-y-3">
                <span className="block text-xs font-bold text-zinc-500 uppercase tracking-widest dark:text-zinc-400">
                  Availability
                </span>
                <div className="space-y-2">
                  {['In Stock', 'Out of Stock', 'Pre-order'].map((status) => (
                    <label key={status} className="flex items-center space-x-2.5 text-xs font-semibold text-zinc-600 dark:text-zinc-400 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedAvailability.includes(status)}
                        onChange={() => handleAvailabilityToggle(status)}
                        className="h-4 w-4 rounded text-brand-pink focus:ring-brand-pink"
                      />
                      <span>{status}</span>
                    </label>
                  ))}
                </div>
              </div>

            </div>
          </div>

        </div>
      )}

    </div>
  );
}
