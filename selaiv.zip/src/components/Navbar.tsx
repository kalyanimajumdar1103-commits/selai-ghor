import React, { useState } from 'react';
import { Menu, X, ShoppingCart, Heart, Search, User, Sun, Moon, ShoppingBag, ShieldAlert, MoreVertical, MapPin, Truck, ChevronDown, ChevronUp, LogOut } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CartItem, User as UserType } from '../types';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  setAccountSubTab: (subTab: 'orders' | 'wishlist' | 'address' | 'tracking') => void;
  cart: CartItem[];
  setIsCartOpen: (open: boolean) => void;
  wishlistCount: number;
  isDarkMode: boolean;
  setIsDarkMode: (dark: boolean) => void;
  currentUser: UserType | null;
  onSearch: (query: string) => void;
  searchQuery: string;
  onLogout?: () => void;
  logoUrl?: string;
}

export default function Navbar({
  currentTab,
  setCurrentTab,
  setAccountSubTab,
  cart,
  setIsCartOpen,
  wishlistCount,
  isDarkMode,
  setIsDarkMode,
  currentUser,
  onSearch,
  searchQuery,
  onLogout,
  logoUrl
}: NavbarProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchExpanded, setIsSearchExpanded] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isOrdersSubmenuOpen, setIsOrdersSubmenuOpen] = useState(true);
  const [isAccountDropdownOpen, setIsAccountDropdownOpen] = useState(false);

  const menuItems = [
    { id: 'home', label: 'Home' },
    { id: 'shop', label: 'Shop' },
    { id: 'categories', label: 'Categories' },
    { id: 'new-arrivals', label: 'New Arrival' },
    { id: 'best-sellers', label: 'Best Seller' },
    { id: 'custom-order', label: 'Custom Order' },
    { id: 'about-us', label: 'About Us' },
    { id: 'contact', label: 'Contact' },
  ];

  const totalCartItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleTabClick = (tabId: string) => {
    setCurrentTab(tabId);
    setIsMobileMenuOpen(false);
  };

  return (
    <header className={`sticky top-0 w-full border-b border-zinc-100 bg-white/95 backdrop-blur-md transition-colors dark:border-zinc-800/80 dark:bg-zinc-950/95 transition-all ${isSidebarOpen ? 'z-[200]' : 'z-50'}`} id="main-header">
      <div className="mx-auto flex h-16 max-w-full items-center justify-between px-2 sm:px-4 lg:px-6">
        
        {/* Left Section: Sidebar Trigger (☰), Search Button (🔍), and Customizable Logo Image */}
        <div className="flex items-center space-x-2" id="logo-and-dots-wrapper">
          {/* Hamburger Menu (☰) Button on the absolute Left side */}
          <button
            id="sidebar-trigger-menu"
            onClick={() => setIsSidebarOpen(true)}
            className="flex h-9 w-9 items-center justify-center rounded-full text-zinc-500 hover:bg-zinc-100 hover:text-brand-pink transition-colors dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-pink-400 cursor-pointer"
            title="Open Menu"
          >
            <Menu className="h-5.5 w-5.5" />
          </button>

          {/* Search Button (🔍) on the Left */}
          <div className="relative flex items-center">
            <button
              id="search-toggle-btn-left"
              onClick={() => setIsSearchExpanded(!isSearchExpanded)}
              className="flex h-9 w-9 items-center justify-center rounded-full text-zinc-500 hover:bg-zinc-100 hover:text-brand-pink transition-colors dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-pink-400 cursor-pointer"
              title="Search"
            >
              <Search className="h-4.5 w-4.5" />
            </button>
            <AnimatePresence>
              {(isSearchExpanded || searchQuery) && (
                <motion.input
                  initial={{ width: 0, opacity: 0 }}
                  animate={{ width: 130, opacity: 1 }}
                  exit={{ width: 0, opacity: 0 }}
                  type="text"
                  placeholder="Search..."
                  value={searchQuery}
                  onChange={(e) => {
                    onSearch(e.target.value);
                    if (currentTab !== 'shop') {
                      setCurrentTab('shop');
                    }
                  }}
                  className="ml-1 h-8 rounded-full border border-zinc-200 bg-zinc-50 px-3 text-xs font-medium text-zinc-800 outline-none focus:border-brand-pink focus:bg-white dark:border-zinc-700 dark:bg-zinc-800 dark:text-white dark:focus:border-brand-pink dark:focus:bg-zinc-900"
                  id="navbar-search-input-left"
                />
              )}
            </AnimatePresence>
          </div>

          {/* Logo Container with customizable tiny image */}
          <div 
            className="flex cursor-pointer items-center ml-1" 
            onClick={() => setCurrentTab('home')}
            id="logo-container"
          >
            {/* 
              TINY LOGO PHOTO / IMAGE PLACEHOLDER
              You can easily replace the 'src' URL below with your own logo/image file path (e.g. "/my-logo.png") later!
              আপনি নিচের 'src' পরিবর্তন করে আপনার পছন্দমতো ছবি/লোগো লাগাতে পারেন।
            */}
            <div className="flex h-10 w-24 items-center justify-center rounded-lg overflow-hidden border border-zinc-200 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 transition-all p-1">
              <img 
                src={logoUrl || "https://images.unsplash.com/photo-1608248597481-496100c80836?auto=format&fit=crop&q=80&w=240&h=120"} 
                alt="Selai Ghor Logo"
                referrerPolicy="no-referrer"
                className="h-full w-full object-cover rounded"
                onError={(e) => {
                  e.currentTarget.src = "https://placehold.co/240x120/pink/white?text=SG";
                }}
              />
            </div>
          </div>
        </div>

        {/* Desktop Navigation Menu removed per user request so they are all inside the sidebar */}
        <div className="hidden lg:block w-0" id="desktop-nav-removed" />

        {/* Actions / Icons */}
        <div className="flex items-center space-x-2 sm:space-x-3" id="navbar-actions">
          
          {/* Light/Dark Mode Switch */}
          <button
            id="theme-toggle-btn"
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="flex h-9 w-9 items-center justify-center rounded-full text-zinc-500 hover:bg-zinc-100 hover:text-brand-pink transition-colors dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-pink-400"
            title="Toggle theme"
          >
            {isDarkMode ? <Sun className="h-4.5 w-4.5 text-amber-400" /> : <Moon className="h-4.5 w-4.5 text-zinc-600" />}
          </button>

          {/* Wishlist Button */}
          <button
            id="wishlist-nav-btn"
            onClick={() => {
              if (!currentUser) {
                alert('Please sign in to view your wishlist.');
                setCurrentTab('account');
                setAccountSubTab('orders');
              } else {
                setCurrentTab('account');
                setAccountSubTab('wishlist');
              }
            }}
            className="relative flex h-9 w-9 items-center justify-center rounded-full text-zinc-500 hover:bg-zinc-100 hover:text-brand-pink transition-colors dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-pink-400"
            title="Wishlist"
          >
            <Heart className="h-4.5 w-4.5" />
            {currentUser && wishlistCount > 0 && (
              <span className="absolute -top-1 -right-1 flex h-4.5 min-w-[18px] items-center justify-center rounded-full bg-brand-pink px-1 text-[10px] font-bold text-white ring-2 ring-white dark:ring-zinc-900">
                {wishlistCount}
              </span>
            )}
          </button>

          {/* Cart Button */}
          {currentUser && (
            <button
              id="cart-nav-btn"
              onClick={() => setIsCartOpen(true)}
              className="relative flex h-9 w-9 items-center justify-center rounded-full bg-brand-pink-light/60 text-brand-pink hover:bg-brand-pink hover:text-white transition-all dark:bg-pink-950/20 dark:text-pink-400 dark:hover:bg-brand-pink dark:hover:text-white"
              title="Shopping Cart"
            >
              <ShoppingCart className="h-4.5 w-4.5" />
              {totalCartItems > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4.5 min-w-[18px] items-center justify-center rounded-full bg-brand-purple px-1 text-[10px] font-bold text-white ring-2 ring-white dark:ring-zinc-900">
                  {totalCartItems}
                </span>
              )}
            </button>
          )}

          {/* User Account / Profile icon with dropdown */}
          <div className="relative" id="account-nav-wrapper">
            <button
              id="account-nav-btn"
              onClick={() => {
                if (currentUser) {
                  setIsAccountDropdownOpen(!isAccountDropdownOpen);
                } else {
                  setCurrentTab('account');
                }
              }}
              className={`flex h-9 items-center space-x-1 rounded-full px-2 text-zinc-500 hover:bg-zinc-100 hover:text-brand-pink transition-colors dark:text-zinc-400 dark:hover:bg-zinc-800 dark:hover:text-pink-400 ${isAccountDropdownOpen ? 'bg-zinc-100 dark:bg-zinc-800 text-brand-pink dark:text-pink-400' : ''}`}
              title="My Account"
            >
              <User className="h-4.5 w-4.5" />
              {currentUser && (
                <span className="hidden text-xs font-semibold sm:inline max-w-[80px] truncate">
                  {currentUser.name}
                </span>
              )}
            </button>

            {/* Click-away backdrop */}
            {isAccountDropdownOpen && (
              <div 
                className="fixed inset-0 z-40 cursor-default" 
                onClick={() => setIsAccountDropdownOpen(false)} 
              />
            )}

            {/* Account Dropdown Popover */}
            <AnimatePresence>
              {isAccountDropdownOpen && currentUser && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95, y: 10 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: 10 }}
                  transition={{ duration: 0.15 }}
                  className="absolute right-0 mt-2 w-56 origin-top-right rounded-2xl border border-zinc-100 bg-white p-2.5 shadow-xl dark:border-zinc-800 dark:bg-zinc-950 z-50 text-left"
                  id="account-dropdown-popover"
                >
                  <div className="px-3.5 py-2 border-b border-zinc-100 dark:border-zinc-800/80 mb-1.5">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Logged in as</p>
                    <p className="text-xs font-extrabold text-zinc-800 dark:text-zinc-200 truncate mt-0.5">{currentUser.name}</p>
                    <p className="text-[10px] text-zinc-400 truncate mt-0.5">{currentUser.email}</p>
                  </div>

                  <div className="space-y-1">
                    {/* Saved Address Option */}
                    <button
                      onClick={() => {
                        setCurrentTab('account');
                        setAccountSubTab('address');
                        setIsAccountDropdownOpen(false);
                      }}
                      className="w-full text-left px-3.5 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest flex items-center space-x-2.5 text-zinc-600 hover:bg-pink-50/50 hover:text-brand-pink dark:text-zinc-400 dark:hover:bg-pink-950/20 dark:hover:text-pink-400 transition-all"
                    >
                      <MapPin className="h-4 w-4 shrink-0" />
                      <span>Saved Address</span>
                    </button>

                    {/* Log Out Option */}
                    <button
                      onClick={() => {
                        if (onLogout) {
                          onLogout();
                        }
                        setIsAccountDropdownOpen(false);
                        setCurrentTab('shop'); // default back to shop
                      }}
                      className="w-full text-left px-3.5 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest flex items-center space-x-2.5 text-red-500 hover:bg-red-50/50 dark:hover:bg-red-950/20 transition-all"
                    >
                      <LogOut className="h-4 w-4 shrink-0" />
                      <span>Log Out</span>
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Admin Toggle button (Visible shortcut) */}
          {currentUser?.isAdmin && (
            <button
              id="admin-nav-btn"
              onClick={() => setCurrentTab('admin')}
              className={`flex h-9 items-center space-x-1 rounded-full px-2 text-zinc-500 hover:bg-zinc-100 transition-colors dark:text-zinc-400 dark:hover:bg-zinc-800 ${
                currentTab === 'admin' ? 'text-brand-purple bg-brand-purple-light dark:text-purple-400 dark:bg-purple-950/20' : 'hover:text-brand-purple'
              }`}
              title="Admin Panel"
            >
              <ShieldAlert className="h-4.5 w-4.5" />
              <span className="hidden text-[10px] font-bold uppercase tracking-wider md:inline">Admin</span>
            </button>
          )}
        </div>
      </div>
      {/* 3. Sliding Left Sidebar Drawer (Full Screen / Left Sided) */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            key="sidebar-backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm"
            id="sidebar-backdrop"
          />
        )}

        {isSidebarOpen && (
          <motion.div
            key="sidebar-drawer"
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', stiffness: 260, damping: 28 }}
            className="fixed inset-y-0 left-0 z-[110] w-80 max-w-[calc(100vw-3rem)] h-full min-h-screen border-r border-zinc-200 bg-white p-6 shadow-2xl dark:border-zinc-800 dark:bg-zinc-950 flex flex-col text-left"
            id="left-sidebar-drawer"
          >
              {/* Drawer Header */}
              <div className="flex items-center justify-between pb-6 border-b border-pink-50 dark:border-zinc-800/80 mb-6">
                <div className="flex items-center space-x-2">
                  <span className="font-display text-xl font-extrabold tracking-tight text-zinc-900 dark:text-white">
                    Selai <span className="text-brand-pink">Ghor</span>
                  </span>
                </div>
                
                <button
                  onClick={() => setIsSidebarOpen(false)}
                  className="rounded-full p-1.5 text-zinc-400 hover:bg-zinc-100 hover:text-zinc-600 dark:hover:bg-zinc-800"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Navigation Links List */}
              <div className="flex-1 overflow-y-auto space-y-2.5 pr-1" id="sidebar-nav-list">
                {/* 1. Home */}
                <button
                  onClick={() => {
                    setCurrentTab('home');
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold uppercase tracking-widest flex items-center justify-between transition-all ${
                    currentTab === 'home' ? 'bg-brand-pink text-white' : 'text-zinc-600 dark:text-zinc-300 hover:bg-pink-50/50 dark:hover:bg-zinc-900'
                  }`}
                >
                  <span>Home</span>
                </button>

                {/* 2. Shop */}
                <button
                  onClick={() => {
                    setCurrentTab('shop');
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold uppercase tracking-widest flex items-center justify-between transition-all ${
                    currentTab === 'shop' ? 'bg-brand-pink text-white' : 'text-zinc-600 dark:text-zinc-300 hover:bg-pink-50/50 dark:hover:bg-zinc-900'
                  }`}
                >
                  <span>Shop</span>
                </button>

                {/* 3. Categories */}
                <button
                  onClick={() => {
                    setCurrentTab('categories');
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold uppercase tracking-widest flex items-center justify-between transition-all ${
                    currentTab === 'categories' ? 'bg-brand-pink text-white' : 'text-zinc-600 dark:text-zinc-300 hover:bg-pink-50/50 dark:hover:bg-zinc-900'
                  }`}
                >
                  <span>Categories</span>
                </button>

                {/* 4. New Arrival */}
                <button
                  onClick={() => {
                    setCurrentTab('new-arrivals');
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold uppercase tracking-widest flex items-center justify-between transition-all ${
                    currentTab === 'new-arrivals' ? 'bg-brand-pink text-white' : 'text-zinc-600 dark:text-zinc-300 hover:bg-pink-50/50 dark:hover:bg-zinc-900'
                  }`}
                >
                  <span>New Arrival</span>
                </button>

                {/* 5. My Orders (With Nested Submenu) */}
                <div className="rounded-2xl border border-zinc-100 dark:border-zinc-800 bg-zinc-50/30 dark:bg-zinc-900/10 p-1.5 space-y-1">
                  <button
                    onClick={() => {
                      setIsOrdersSubmenuOpen(!isOrdersSubmenuOpen);
                    }}
                    className={`w-full text-left px-2.5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-widest flex items-center justify-between transition-all text-zinc-700 dark:text-zinc-300 hover:bg-zinc-100/50 dark:hover:bg-zinc-900`}
                  >
                    <span>My Orders</span>
                    {isOrdersSubmenuOpen ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
                  </button>

                  <AnimatePresence initial={false}>
                    {isOrdersSubmenuOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden pl-1 space-y-1 pb-1"
                      >
                        {/* Submenu: My Orders */}
                        <button
                          onClick={() => {
                            setCurrentTab('account');
                            setAccountSubTab('orders');
                            setIsSidebarOpen(false);
                          }}
                          className={`w-full text-left px-2 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest flex items-center space-x-2 transition-all ${
                            currentTab === 'account' ? 'text-brand-pink' : 'text-zinc-500 hover:text-brand-pink'
                          }`}
                        >
                          <ShoppingBag className="h-3.5 w-3.5 shrink-0" />
                          <span>My Orders</span>
                        </button>

                        {/* Submenu: Saved Address */}
                        <button
                          onClick={() => {
                            setCurrentTab('account');
                            setAccountSubTab('address');
                            setIsSidebarOpen(false);
                          }}
                          className={`w-full text-left px-2 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest flex items-center space-x-2 transition-all ${
                            currentTab === 'account' ? 'text-brand-pink' : 'text-zinc-500 hover:text-brand-pink'
                          }`}
                        >
                          <MapPin className="h-3.5 w-3.5 shrink-0" />
                          <span>Saved Address</span>
                        </button>

                        {/* Submenu: Live Order Tracking */}
                        <button
                          onClick={() => {
                            setCurrentTab('account');
                            setAccountSubTab('tracking');
                            setIsSidebarOpen(false);
                          }}
                          className={`w-full text-left px-2 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest flex items-center space-x-2 transition-all ${
                            currentTab === 'account' ? 'text-brand-pink' : 'text-zinc-500 hover:text-brand-pink'
                          }`}
                        >
                          <Truck className="h-3.5 w-3.5 shrink-0" />
                          <span>Live Order Tracking</span>
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                {/* 6. Best Seller */}
                <button
                  onClick={() => {
                    setCurrentTab('best-sellers');
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold uppercase tracking-widest flex items-center justify-between transition-all ${
                    currentTab === 'best-sellers' ? 'bg-brand-pink text-white' : 'text-zinc-600 dark:text-zinc-300 hover:bg-pink-50/50 dark:hover:bg-zinc-900'
                  }`}
                >
                  <span>Best Seller</span>
                </button>

                {/* 7. Custom Order */}
                <button
                  onClick={() => {
                    setCurrentTab('custom-order');
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold uppercase tracking-widest flex items-center justify-between transition-all ${
                    currentTab === 'custom-order' ? 'bg-brand-pink text-white' : 'text-zinc-600 dark:text-zinc-300 hover:bg-pink-50/50 dark:hover:bg-zinc-900'
                  }`}
                >
                  <span>Custom Order</span>
                </button>

                {/* 8. About Us */}
                <button
                  onClick={() => {
                    setCurrentTab('about-us');
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold uppercase tracking-widest flex items-center justify-between transition-all ${
                    currentTab === 'about-us' ? 'bg-brand-pink text-white' : 'text-zinc-600 dark:text-zinc-300 hover:bg-pink-50/50 dark:hover:bg-zinc-900'
                  }`}
                >
                  <span>About Us</span>
                </button>

                {/* 9. Contact */}
                <button
                  onClick={() => {
                    setCurrentTab('contact');
                    setIsSidebarOpen(false);
                  }}
                  className={`w-full text-left px-4 py-3 rounded-2xl text-xs font-bold uppercase tracking-widest flex items-center justify-between transition-all ${
                    currentTab === 'contact' ? 'bg-brand-pink text-white' : 'text-zinc-600 dark:text-zinc-300 hover:bg-pink-50/50 dark:hover:bg-zinc-900'
                  }`}
                >
                  <span>Contact</span>
                </button>
              </div>

              {/* Sidebar Footer */}
              <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800 text-center">
                <span className="text-[9px] font-bold tracking-widest text-zinc-400 uppercase">
                  Selai Ghor Boutique © 2026
                </span>
              </div>
            </motion.div>
          )
        }
      </AnimatePresence>
    </header>
  );
}
