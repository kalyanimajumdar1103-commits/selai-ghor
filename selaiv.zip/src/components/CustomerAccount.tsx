import React, { useState } from 'react';
import { User, LogIn, Heart, ShoppingBag, MapPin, Search, Key, ShieldCheck, Check, Edit, Eye, EyeOff, Clock, Truck, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Product, ShippingAddress, Order, User as UserType } from '../types';

interface CustomerAccountProps {
  products: Product[];
  currentUser: UserType | null;
  onLogin: (user: UserType) => void;
  onLogout: () => void;
  onUpdateAddress: (address: ShippingAddress) => void;
  orders: Order[];
  onSelectProduct: (product: Product) => void;
  wishlist: string[];
  onToggleWishlist: (productId: string) => void;
  onRegister?: (user: UserType) => void;
  subTab: 'orders' | 'wishlist' | 'address' | 'tracking';
  setSubTab: (tab: 'orders' | 'wishlist' | 'address' | 'tracking') => void;
  setCurrentTab?: (tab: string) => void;
}

export default function CustomerAccount({
  products,
  currentUser,
  onLogin,
  onLogout,
  onUpdateAddress,
  orders,
  onSelectProduct,
  wishlist,
  onToggleWishlist,
  onRegister,
  subTab,
  setSubTab,
  setCurrentTab
}: CustomerAccountProps) {
  const [authTab, setAuthTab] = useState<'login' | 'register' | 'forgot'>('login');

  // Password visibility states
  const [showLoginPass, setShowLoginPass] = useState(false);
  const [showRegPass, setShowRegPass] = useState(false);

  // Login form states
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPass, setLoginPass] = useState('');
  const [loginError, setLoginError] = useState('');

  // Register form states
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPass, setRegPass] = useState('');
  const [regError, setRegError] = useState('');
  const [regSuccess, setRegSuccess] = useState(false);

  // Forgot password form states
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState(false);

  // Address edit form states
  const [isEditingAddress, setIsEditingAddress] = useState(false);
  const [fullName, setFullName] = useState(currentUser?.savedAddress?.fullName || '');
  const [phoneNumber, setPhoneNumber] = useState(currentUser?.savedAddress?.phoneNumber || '');
  const [fullAddress, setFullAddress] = useState(currentUser?.savedAddress?.fullAddress || '');
  const [landmark, setLandmark] = useState(currentUser?.savedAddress?.landmark || '');
  const [district, setDistrict] = useState(currentUser?.savedAddress?.district || '');
  const [state, setState] = useState(currentUser?.savedAddress?.state || '');
  const [pinCode, setPinCode] = useState(currentUser?.savedAddress?.pinCode || '');

  React.useEffect(() => {
    if (currentUser?.savedAddress) {
      setFullName(currentUser.savedAddress.fullName || '');
      setPhoneNumber(currentUser.savedAddress.phoneNumber || '');
      setFullAddress(currentUser.savedAddress.fullAddress || '');
      setLandmark(currentUser.savedAddress.landmark || '');
      setDistrict(currentUser.savedAddress.district || '');
      setState(currentUser.savedAddress.state || '');
      setPinCode(currentUser.savedAddress.pinCode || '');
    } else {
      setFullName('');
      setPhoneNumber('');
      setFullAddress('');
      setLandmark('');
      setDistrict('');
      setState('');
      setPinCode('');
    }
  }, [currentUser]);

  // Tracking inquiry state
  const [trackingIdInput, setTrackingIdInput] = useState('');
  const [trackedOrder, setTrackedOrder] = useState<Order | null>(null);

  // Guest search state
  const [guestSearchInput, setGuestSearchInput] = useState('');
  const [guestSearchResult, setGuestSearchResult] = useState<Order[]>([]);
  const [hasSearchedGuest, setHasSearchedGuest] = useState(false);

  // Filter wishlist items
  const wishlistedItems = products.filter(p => wishlist.includes(p.id));

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    const email = loginEmail.trim();
    const password = loginPass.trim();

    if (!email || !password) {
      setLoginError('All fields are required.');
      return;
    }

    // 1. Check for Admin Login
    if (email.toLowerCase() === 'kalyanimajumdar1103@gmail.com') {
      if (password !== '11092007') {
        setLoginError('Incorrect password for admin account.');
        return;
      }

      const adminUser: UserType = {
        id: 'usr-admin',
        name: 'Kalyani Majumdar',
        email: 'kalyanimajumdar1103@gmail.com',
        wishlist: [],
        isAdmin: true,
        savedAddress: {
          fullName: 'Kalyani Majumdar',
          phoneNumber: '8100226410',
          fullAddress: 'Salai Ghor Workshop, Garia',
          landmark: 'Metro Station',
          district: 'Kolkata',
          state: 'West Bengal',
          pinCode: '700084'
        }
      };
      
      onLogin(adminUser);
      return;
    }

    // 2. Check localStorage users
    const localUsers: UserType[] = JSON.parse(localStorage.getItem('sg_users') || '[]');
    const matched = localUsers.find(u => u.email.toLowerCase() === email.toLowerCase());

    if (matched) {
      if (matched.password && matched.password !== password) {
        setLoginError('Incorrect password. Please try again.');
        return;
      }
      onLogin(matched);
      return;
    }

    setLoginError('This email is not registered yet. Please click the register tab above to create an account.');
  };

  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');
    setRegSuccess(false);

    if (!regName.trim() || !regEmail.trim() || !regPass.trim()) {
      setRegError('All fields are required.');
      return;
    }

    const localUsers: UserType[] = JSON.parse(localStorage.getItem('sg_users') || '[]');
    const exists = localUsers.some(u => u.email.toLowerCase() === regEmail.toLowerCase());

    if (exists || regEmail.toLowerCase() === 'kalyanimajumdar1103@gmail.com') {
      setRegError('Email already registered! Try logging in.');
      return;
    }

    const newUser: UserType = {
      id: `usr-${Date.now()}`,
      name: regName,
      email: regEmail,
      password: regPass,
      wishlist: []
    };

    localUsers.push(newUser);
    localStorage.setItem('sg_users', JSON.stringify(localUsers));

    if (onRegister) {
      onRegister(newUser);
    }

    setRegSuccess(true);
    setRegName('');
    setRegEmail('');
    setRegPass('');
    setTimeout(() => {
      setAuthTab('login');
      setRegSuccess(false);
    }, 2000);
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setForgotSuccess(false);
    if (!forgotEmail.trim()) return;

    setForgotSuccess(true);
    setForgotEmail('');
    setTimeout(() => setForgotSuccess(false), 5000);
  };

  const handleAddressSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const newAddress: ShippingAddress = {
      fullName,
      phoneNumber,
      fullAddress,
      landmark,
      district,
      state,
      pinCode
    };

    onUpdateAddress(newAddress);
    setIsEditingAddress(false);
  };

  const handleTrackInquirySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setTrackedOrder(null);
    const found = orders.find(
      o => o.id.toLowerCase() === trackingIdInput.trim().toLowerCase() || 
           o.trackingNumber?.toLowerCase() === trackingIdInput.trim().toLowerCase()
    );

    if (!found) {
      alert('Order ID or Tracking number not found.');
      return;
    }

    // Secure: Only allow tracking if the user is an admin OR is the owner of the order
    const isOwner = currentUser && (
      found.userId === currentUser.id ||
      (found.userEmail && found.userEmail.toLowerCase() === currentUser.email.toLowerCase())
    );

    if (!currentUser?.isAdmin && !isOwner) {
      alert('This order does not belong to your account.');
      return;
    }

    setTrackedOrder(found);
  };

  const handleGuestOrderSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearchedGuest(false);
    setGuestSearchResult([]);

    const query = guestSearchInput.trim().toLowerCase();
    if (!query) return;

    // Search orders for match with Order ID, Tracking Number, Phone, or Email, or Name
    const matched = orders.filter(
      o => o.id.toLowerCase() === query ||
           o.trackingNumber?.toLowerCase() === query ||
           o.address.phoneNumber.toLowerCase().replace(/\D/g, '') === query.replace(/\D/g, '') ||
           o.userEmail?.toLowerCase() === query ||
           o.address.fullName.toLowerCase().includes(query)
    );

    setGuestSearchResult(matched);
    setHasSearchedGuest(true);
  };

  // If user is not logged in, render authentication (with guest overrides for tracking and address)
  if (!currentUser) {
    if (subTab === 'tracking') {
      return (
        <div className="mx-auto max-w-2xl px-4 py-8 text-left" id="guest-tracking-view">
          <div className="mb-6 pb-4 border-b border-pink-50 dark:border-zinc-800 flex items-center justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-brand-pink">Guest Portal</span>
              <h1 className="font-display text-2xl font-extrabold text-zinc-900 dark:text-white mt-1">Live Order Tracking</h1>
            </div>
            <button
              onClick={() => {
                setSubTab('orders');
              }}
              className="rounded-full border border-pink-100 bg-white px-4 py-1.5 text-xs font-bold text-brand-pink hover:bg-brand-pink hover:text-white transition-colors dark:border-zinc-800 dark:bg-zinc-900 shadow-sm cursor-pointer"
            >
              Sign In Account
            </button>
          </div>

          <div className="p-6 rounded-3xl border border-pink-100 bg-white shadow-xl dark:border-zinc-800 dark:bg-zinc-900 space-y-6">
            <p className="text-xs text-zinc-500 leading-relaxed">
              Track your handcrafted order by entering your Order ID (e.g., <strong>SG-123456</strong>) or Tracking Number.
            </p>

            <form onSubmit={(e) => {
              e.preventDefault();
              setTrackedOrder(null);
              const found = orders.find(
                o => o.id.toLowerCase() === trackingIdInput.trim().toLowerCase() || 
                     o.trackingNumber?.toLowerCase() === trackingIdInput.trim().toLowerCase()
              );
              if (!found) {
                alert('Order ID or Tracking number not found.');
                return;
              }
              setTrackedOrder(found);
            }} className="flex gap-2">
              <input
                type="text"
                placeholder="Enter Order ID (e.g. SG-123456)"
                value={trackingIdInput}
                onChange={(e) => setTrackingIdInput(e.target.value)}
                required
                className="h-10 flex-1 rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
              />
              <button
                type="submit"
                className="h-10 rounded-xl bg-brand-pink px-5 text-xs font-bold text-white hover:bg-brand-pink-dark cursor-pointer"
              >
                Locate
              </button>
            </form>

            {trackedOrder && (
              <div className="p-5 rounded-2xl border border-pink-50 bg-pink-50/10 space-y-4 mt-6 dark:border-zinc-800 dark:bg-pink-950/10">
                <div className="flex justify-between items-start text-xs border-b border-pink-50/50 pb-3 dark:border-zinc-800">
                  <div>
                    <span className="block font-bold text-zinc-800 dark:text-white">Order: {trackedOrder.id}</span>
                    <span className="block text-[10px] text-zinc-400 font-semibold">Recipient: {trackedOrder.address.fullName}</span>
                  </div>
                  
                  <span className="rounded-full bg-brand-pink px-2.5 py-1 text-[10px] font-bold text-white uppercase">
                    {trackedOrder.status}
                  </span>
                </div>

                {/* Tracking updates */}
                <div className="space-y-4">
                  <span className="block text-[10px] font-bold uppercase tracking-wider text-zinc-400">Status History:</span>
                  <div className="space-y-3.5 pl-2 relative border-l-2 border-pink-100 dark:border-zinc-800 ml-1.5">
                    {trackedOrder.trackingUpdates && trackedOrder.trackingUpdates.length > 0 ? (
                      trackedOrder.trackingUpdates.map((upd, uIdx) => (
                        <div key={uIdx} className="relative pl-4">
                          <div className="absolute -left-1.5 top-1 h-3 w-3 rounded-full bg-brand-pink" />
                          <span className="block text-[10px] text-zinc-400 font-bold">{upd.date}</span>
                          <span className="block text-xs font-bold text-zinc-800 dark:text-zinc-200 mt-0.5">{upd.status}</span>
                          <p className="text-[11px] text-zinc-500 mt-0.5">{upd.description}</p>
                        </div>
                      ))
                    ) : (
                      <div className="relative pl-4">
                        <div className="absolute -left-1.5 top-1 h-3 w-3 rounded-full bg-brand-pink" />
                        <span className="block text-[10px] text-zinc-400 font-bold">Today</span>
                        <span className="block text-xs font-bold text-zinc-800 dark:text-zinc-200 mt-0.5">Order Received</span>
                        <p className="text-[11px] text-zinc-500 mt-0.5">Your order is being processed and will be updated shortly.</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      );
    }

    if (subTab === 'address') {
      return (
        <div className="mx-auto max-w-md px-4 py-16 text-left relative" id="guest-address-notice">
          <div className="rounded-3xl border border-pink-100 bg-white p-8 shadow-xl dark:border-zinc-800 dark:bg-zinc-900 text-center space-y-4">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-pink-50 text-brand-pink dark:bg-zinc-800 dark:text-pink-400">
              <MapPin className="h-5 w-5" />
            </div>
            <h2 className="font-display text-lg font-bold text-zinc-900 dark:text-white">Saved Address</h2>
            <p className="text-xs text-zinc-500 leading-relaxed">
              Please sign in or create an account to view and update your saved delivery address.
            </p>
            <button
              onClick={() => {
                setSubTab('orders');
              }}
              className="w-full h-10 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark transition-all cursor-pointer"
            >
              Go to Sign In
            </button>
          </div>
        </div>
      );
    }

    return (
      <div className="mx-auto max-w-md px-4 py-16 text-left relative" id="auth-view-container">
        
        {/* Beautiful Centered Forms Card */}
        <div className="rounded-3xl border border-pink-100 bg-white p-7 shadow-xl dark:border-zinc-800 dark:bg-zinc-900 w-full">
          
          {/* Logo header */}
          <div className="text-center mb-6 relative">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-brand-pink text-white shadow-sm">
              <LogIn className="h-5 w-5" />
            </div>
            <h2 className="font-display text-xl font-extrabold text-zinc-900 dark:text-white mt-3">
              Selai Ghor Accounts
            </h2>
            <p className="text-[10px] text-zinc-400 mt-1 uppercase tracking-widest font-bold">
              Knit with Love, Track with Ease
            </p>

            {/* Subtle Admin Panel shortcut on the right side */}
            <div className="absolute right-0 top-1">
              <button 
                type="button"
                onClick={() => setCurrentTab && setCurrentTab('admin')}
                className="flex items-center space-x-1.5 rounded-full border border-purple-200 bg-purple-50/50 px-3 py-1.5 text-[9px] font-bold uppercase tracking-wider text-brand-purple hover:bg-brand-purple hover:text-white transition-all dark:border-zinc-800 dark:bg-zinc-900/50 dark:text-purple-400 dark:hover:bg-brand-purple dark:hover:text-white cursor-pointer shadow-sm"
                id="admin-shortcut-btn"
              >
                <ShieldAlert className="h-3.5 w-3.5 animate-pulse" />
                <span>Admin</span>
              </button>
            </div>
          </div>

          {/* Form Tabs */}
          <div className="flex border-b border-pink-50 mb-6 dark:border-zinc-800">
            <button
              id="auth-tab-login"
              onClick={() => setAuthTab('login')}
              className={`flex-1 pb-3 text-center text-xs font-bold uppercase tracking-wider cursor-pointer ${
                authTab === 'login' 
                  ? 'border-b-2 border-brand-pink text-brand-pink dark:text-pink-400' 
                  : 'text-zinc-400 hover:text-zinc-600'
              }`}
            >
              Sign In
            </button>
            <button
              id="auth-tab-register"
              onClick={() => setAuthTab('register')}
              className={`flex-1 pb-3 text-center text-xs font-bold uppercase tracking-wider cursor-pointer ${
                authTab === 'register' 
                  ? 'border-b-2 border-brand-pink text-brand-pink dark:text-pink-400' 
                  : 'text-zinc-400 hover:text-zinc-600'
              }`}
            >
              Register
            </button>
          </div>

          {/* Render forms depending on states */}
          {authTab === 'login' ? (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="e.g. rahul@example.com"
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                  id="login-email"
                />
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 dark:text-zinc-400">
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setAuthTab('forgot')}
                    className="text-[10px] font-bold text-brand-pink hover:underline"
                  >
                    Forgot Password?
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showLoginPass ? "text" : "password"}
                    placeholder="••••••••"
                    value={loginPass}
                    onChange={(e) => setLoginPass(e.target.value)}
                    required
                    className="h-10 w-full rounded-xl border border-zinc-200 pl-3 pr-10 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950/20 dark:text-white dark:focus:border-pink-500"
                    id="login-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowLoginPass(!showLoginPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300"
                  >
                    {showLoginPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {loginError && (
                <div className="text-[10px] font-bold text-red-500">{loginError}</div>
              )}

              <button
                type="submit"
                id="login-submit-btn"
                className="w-full h-11 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark transition-all cursor-pointer"
              >
                Sign In & Explore
              </button>
              
              <div className="text-center pt-2">
                <span className="text-[10px] text-zinc-400 italic">
                  *Tip: Any email/password will instantly sign in to a test account!
                </span>
              </div>
            </form>
          ) : authTab === 'register' ? (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                  Full Name
                </label>
                <input
                  type="text"
                  placeholder="e.g. Rahul Halder"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                  id="reg-name"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="e.g. rahul@example.com"
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                  id="reg-email"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                  Choose Password
                </label>
                <div className="relative">
                  <input
                    type={showRegPass ? "text" : "password"}
                    placeholder="••••••••"
                    value={regPass}
                    onChange={(e) => setRegPass(e.target.value)}
                    required
                    className="h-10 w-full rounded-xl border border-zinc-200 pl-3 pr-10 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950/20 dark:text-white dark:focus:border-pink-500"
                    id="reg-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowRegPass(!showRegPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300"
                  >
                    {showRegPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              {regError && (
                <div className="text-[10px] font-bold text-red-500">{regError}</div>
              )}

              {regSuccess && (
                <div className="p-2 text-center text-xs font-bold text-emerald-800 bg-emerald-100 rounded-xl">
                  🎉 Registration successful! Redirecting to login...
                </div>
              )}

              <button
                type="submit"
                id="register-submit-btn"
                className="w-full h-11 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark transition-all cursor-pointer"
              >
                Create Account
              </button>
            </form>
          ) : (
            // Forgot Password Form
            <form onSubmit={handleForgotSubmit} className="space-y-4">
              <p className="text-[11px] text-zinc-500 leading-relaxed">
                Enter your registered email address below. We will simulate sending a password reset linkage directly to your inbox.
              </p>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="e.g. rahul@example.com"
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  required
                  className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                  id="forgot-email"
                />
              </div>

              {forgotSuccess && (
                <div className="p-2.5 text-center text-xs font-bold text-emerald-800 bg-emerald-100 rounded-xl">
                  ✉️ Reset linkage successfully dispatched! Please check your spam folder too.
                </div>
              )}

              <div className="flex space-x-2">
                <button
                  type="button"
                  onClick={() => setAuthTab('login')}
                  className="flex-1 h-10 rounded-full border text-xs font-bold text-zinc-500 hover:bg-zinc-50 dark:hover:bg-zinc-800 dark:text-zinc-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  id="forgot-submit-btn"
                  className="flex-1 h-10 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark"
                >
                  Reset Password
                </button>
              </div>
            </form>
          )}

        </div>
      </div>
    );
  }

  // Logged-in Customer View Dashboard
  const userOrders = orders.filter(ord => 
    currentUser && (
      ord.userId === currentUser.id || 
      (ord.userEmail && ord.userEmail.toLowerCase() === currentUser.email.toLowerCase())
    )
  );

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 text-left" id="customer-profile-dashboard">
      
      {/* Welcome Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between mb-8 pb-6 border-b border-pink-50 dark:border-zinc-800">
        <div>
          <span className="text-xs font-bold uppercase tracking-widest text-brand-purple">Welcome Back!</span>
          <h1 className="font-display text-2xl font-extrabold sm:text-3xl text-zinc-900 dark:text-white mt-1">
            🌸 {currentUser.name}
          </h1>
          <p className="text-xs text-zinc-400">{currentUser.email}</p>
        </div>

        <button
          onClick={onLogout}
          className="rounded-full border border-pink-100 px-5 py-2 text-xs font-bold text-brand-pink hover:bg-brand-pink hover:text-white transition-colors dark:border-zinc-800"
        >
          Sign Out Account
        </button>
      </div>

      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
        
        {/* Navigation panel (lg:span-3) */}
        <nav className="lg:col-span-3 flex flex-col space-y-2" id="profile-subnav">
          <button
            onClick={() => setSubTab('orders')}
            className={`flex items-center space-x-3 rounded-2xl px-4 py-3.5 text-left text-xs font-bold uppercase tracking-wider transition-all ${
              subTab === 'orders'
                ? 'bg-brand-pink text-white shadow-sm'
                : 'text-zinc-600 hover:bg-zinc-50 dark:text-zinc-400 dark:hover:bg-zinc-800/40'
            }`}
          >
            <ShoppingBag className="h-4.5 w-4.5" />
            <span>My Orders ({userOrders.length})</span>
          </button>

          <button
            onClick={() => setSubTab('wishlist')}
            className={`flex items-center space-x-3 rounded-2xl px-4 py-3.5 text-left text-xs font-bold uppercase tracking-wider transition-all ${
              subTab === 'wishlist'
                ? 'bg-brand-pink text-white shadow-sm'
                : 'text-zinc-600 hover:bg-zinc-50 dark:text-zinc-400 dark:hover:bg-zinc-800/40'
            }`}
          >
            <Heart className="h-4.5 w-4.5" />
            <span>Wishlist ({wishlistedItems.length})</span>
          </button>

          <button
            onClick={() => setSubTab('address')}
            className={`flex items-center space-x-3 rounded-2xl px-4 py-3.5 text-left text-xs font-bold uppercase tracking-wider transition-all ${
              subTab === 'address'
                ? 'bg-brand-pink text-white shadow-sm'
                : 'text-zinc-600 hover:bg-zinc-50 dark:text-zinc-400 dark:hover:bg-zinc-800/40'
            }`}
          >
            <MapPin className="h-4.5 w-4.5" />
            <span>Saved Address</span>
          </button>

          <button
            onClick={() => setSubTab('tracking')}
            className={`flex items-center space-x-3 rounded-2xl px-4 py-3.5 text-left text-xs font-bold uppercase tracking-wider transition-all ${
              subTab === 'tracking'
                ? 'bg-brand-pink text-white shadow-sm'
                : 'text-zinc-600 hover:bg-zinc-50 dark:text-zinc-400 dark:hover:bg-zinc-800/40'
            }`}
          >
            <Truck className="h-4.5 w-4.5" />
            <span>Live Order Tracking</span>
          </button>
        </nav>

        {/* Contents area (lg:span-9) */}
        <div className="lg:col-span-9 p-6 rounded-3xl border border-pink-50 bg-white dark:border-zinc-800 dark:bg-zinc-900">
          
          {/* A. MY ORDERS */}
          {subTab === 'orders' && (
            <div className="space-y-6" id="orders-subtab">
              <h2 className="font-display text-base font-bold text-zinc-800 dark:text-white border-b border-zinc-100 pb-2 dark:border-zinc-800">
                Purchase History & Real-time Delivery Status
              </h2>

              {userOrders.length === 0 ? (
                <div className="text-center py-12">
                  <ShoppingBag className="h-10 w-10 text-zinc-300 mx-auto mb-2" />
                  <p className="text-xs text-zinc-500 italic">You have not placed any orders yet.</p>
                  <button
                    onClick={() => onSelectProduct(products[0])} // Quick fallback or shop
                    className="mt-4 rounded-full bg-brand-pink px-6 py-2 text-xs font-bold text-white"
                  >
                    Start Shopping
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  {userOrders.map((ord) => (
                    <div
                      key={ord.id}
                      id={`order-card-${ord.id}`}
                      className="rounded-2xl border border-pink-50 bg-zinc-50/50 p-5 space-y-4 dark:border-zinc-800 dark:bg-zinc-950/20"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-3 border-b border-zinc-100 dark:border-zinc-800 text-xs">
                        <div>
                          <span className="block font-bold text-zinc-800 dark:text-white">Order ID: {ord.id}</span>
                          <span className="block text-[10px] text-zinc-400">Placed on: {ord.orderDate}</span>
                        </div>
                        
                        <div className="text-right">
                          <span className="block font-bold text-brand-pink dark:text-pink-400">Total: ₹{ord.grandTotal}</span>
                          <span className="block text-[10px] text-zinc-400">Payment: {ord.paymentMethod}</span>
                        </div>
                      </div>

                      {/* Products in this order */}
                      <div className="space-y-2">
                        {ord.items.map((item, idx) => (
                          <div key={idx} className="flex items-center justify-between text-xs font-semibold">
                            <span className="text-zinc-600 dark:text-zinc-300 truncate max-w-[200px] sm:max-w-md">
                              • {item.product.name} ({item.selectedColor}) <strong className="text-zinc-400 font-normal">x {item.quantity}</strong>
                            </span>
                            <span className="text-zinc-800 dark:text-white">
                              ₹{(item.product.discountPrice || item.product.price) * item.quantity}
                            </span>
                          </div>
                        ))}
                      </div>

                      {/* Interactive Tracking Stepper inside the order details! */}
                      <div className="pt-4 border-t border-zinc-100 dark:border-zinc-800">
                        <span className="block text-[10px] font-bold uppercase tracking-wider text-zinc-400 mb-3">
                          Live Progress Tracker:
                        </span>
                        
                        <div className="relative flex items-center justify-between">
                          {/* Progress Line */}
                          <div className="absolute left-4 right-4 top-2.5 h-0.5 bg-zinc-200 dark:bg-zinc-800" />
                          
                          {/* Active filled line based on status */}
                          <div 
                            className="absolute left-4 top-2.5 h-0.5 bg-brand-pink transition-all duration-500" 
                            style={{
                              width: ord.status === 'Pending' ? '0%' : 
                                     ord.status === 'Confirmed' ? '33%' : 
                                     ord.status === 'Shipped' ? '66%' : 
                                     ord.status === 'Delivered' ? '100%' : '0%'
                            }}
                          />

                          {[
                            { label: 'Pending', icon: Clock },
                            { label: 'Confirmed', icon: ShieldCheck },
                            { label: 'Shipped', icon: Truck },
                            { label: 'Delivered', icon: Check }
                          ].map((step, sIdx) => {
                            const StepIcon = step.icon;
                            // check if active
                            const statuses = ['Pending', 'Confirmed', 'Shipped', 'Delivered'];
                            const currentStatusIdx = statuses.indexOf(ord.status);
                            const stepIdx = statuses.indexOf(step.label);
                            const isPastOrCurrent = stepIdx <= currentStatusIdx && ord.status !== 'Cancelled';

                            return (
                              <div key={step.label} className="relative z-10 flex flex-col items-center">
                                <div className={`flex h-6.5 w-6.5 items-center justify-center rounded-full text-xs font-bold shadow ${
                                  isPastOrCurrent 
                                    ? 'bg-brand-pink text-white ring-4 ring-pink-100 dark:ring-pink-950/40' 
                                    : 'bg-zinc-100 text-zinc-400 dark:bg-zinc-800'
                                }`}>
                                  <StepIcon className="h-3.5 w-3.5" />
                                </div>
                                <span className={`text-[9px] font-bold uppercase mt-1.5 ${
                                  isPastOrCurrent ? 'text-brand-pink' : 'text-zinc-400'
                                }`}>
                                  {step.label}
                                </span>
                              </div>
                            );
                          })}
                        </div>
                      </div>

                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* B. WISHLIST */}
          {subTab === 'wishlist' && (
            <div className="space-y-6" id="wishlist-subtab">
              <h2 className="font-display text-base font-bold text-zinc-800 dark:text-white border-b border-zinc-100 pb-2 dark:border-zinc-800">
                My Favorites & Saved Designs
              </h2>

              {wishlistedItems.length === 0 ? (
                <p className="text-xs text-zinc-500 italic py-10 text-center">Your wishlist is currently empty. Tap hearts on the shop page to save creations!</p>
              ) : (
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  {wishlistedItems.map((prod) => {
                    const price = prod.discountPrice || prod.price;
                    return (
                      <div
                        key={prod.id}
                        onClick={() => onSelectProduct(prod)}
                        className="group flex items-center justify-between p-3 rounded-2xl border border-zinc-100 bg-zinc-50/50 hover:bg-zinc-100/50 transition-all cursor-pointer dark:border-zinc-800 dark:bg-zinc-950/10"
                        id={`wishlist-item-${prod.id}`}
                      >
                        <div className="flex items-center space-x-3.5">
                          <div className="h-14 w-14 overflow-hidden rounded-xl bg-zinc-50 dark:bg-zinc-800">
                            <img
                              src={prod.images[0]}
                              alt={prod.name}
                              referrerPolicy="no-referrer"
                              className="h-full w-full object-cover"
                            />
                          </div>
                          <div className="text-left">
                            <span className="text-[8px] font-bold text-brand-purple uppercase">{prod.category}</span>
                            <h4 className="font-display text-xs font-bold text-zinc-800 dark:text-white truncate max-w-[120px] sm:max-w-[180px]">
                              {prod.name}
                            </h4>
                            <span className="block text-xs font-extrabold text-brand-pink mt-0.5">₹{price}</span>
                          </div>
                        </div>

                        <button
                          id={`wish-remove-${prod.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleWishlist(prod.id);
                          }}
                          className="text-xs font-bold text-red-500 hover:underline px-2.5"
                        >
                          Remove
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* C. SAVED ADDRESS */}
          {subTab === 'address' && (
            <div className="space-y-6" id="address-subtab">
              {/* Quick Navigation link to My Orders added above Saved Address */}
              <div 
                onClick={() => setSubTab('orders')}
                className="group flex items-center justify-between rounded-2xl border border-pink-100 bg-pink-50/20 p-4 transition-all duration-300 hover:bg-pink-50/50 hover:border-brand-pink/30 cursor-pointer dark:border-zinc-800 dark:bg-zinc-950/20 dark:hover:bg-zinc-900/40"
                id="saved-address-orders-shortcut"
              >
                <div className="flex items-center space-x-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-full bg-pink-100/80 text-brand-pink dark:bg-pink-950/40 dark:text-pink-400 group-hover:scale-105 transition-transform">
                    <ShoppingBag className="h-4.5 w-4.5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-extrabold text-zinc-800 dark:text-white uppercase tracking-wider">
                      My Orders Section
                    </h4>
                    <p className="text-[10px] text-zinc-400 dark:text-zinc-500 mt-0.5">
                      Click here to view your purchase history and live delivery tracking status
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-1.5 text-xs font-bold text-brand-pink group-hover:translate-x-1 transition-transform">
                  <span>Go to Orders</span>
                  <span>→</span>
                </div>
              </div>

              <div className="flex items-center justify-between border-b border-zinc-100 pb-2 dark:border-zinc-800">
                <h2 className="font-display text-base font-bold text-zinc-800 dark:text-white">
                  Default Billing & Shipping Location
                </h2>
                {!isEditingAddress && currentUser.savedAddress && (
                  <button
                    onClick={() => setIsEditingAddress(true)}
                    className="flex items-center space-x-1.5 text-xs font-bold text-brand-pink"
                  >
                    <Edit className="h-3.5 w-3.5" />
                    <span>Edit Location</span>
                  </button>
                )}
              </div>

              {isEditingAddress || !currentUser.savedAddress ? (
                <form onSubmit={handleAddressSubmit} className="space-y-4 max-w-xl">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                        Full Name
                      </label>
                      <input
                        type="text"
                        placeholder="Rahul Halder"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        required
                        className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
                        id="addr-fullname"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        placeholder="8100226410"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        required
                        className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
                        id="addr-phone"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="mb-1">
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                        Full Address
                      </label>
                    </div>
                    <textarea
                      rows={2}
                      placeholder="12, Garia Main Road"
                      value={fullAddress}
                      onChange={(e) => setFullAddress(e.target.value)}
                      required
                      className="w-full rounded-xl border border-zinc-200 p-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
                      id="addr-fulladdress"
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                        Landmark
                      </label>
                      <input
                        type="text"
                        placeholder="Near Garia Metro Station"
                        value={landmark}
                        onChange={(e) => setLandmark(e.target.value)}
                        required
                        className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800"
                        id="addr-landmark"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                        District
                      </label>
                      <input
                        type="text"
                        placeholder="Kolkata"
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        required
                        className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800"
                        id="addr-district"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                        State
                      </label>
                      <input
                        type="text"
                        placeholder="West Bengal"
                        value={state}
                        onChange={(e) => setState(e.target.value)}
                        required
                        className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800"
                        id="addr-state"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1">
                      PIN Code
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      placeholder="700084"
                      value={pinCode}
                      onChange={(e) => setPinCode(e.target.value)}
                      required
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800"
                      id="addr-pincode"
                    />
                  </div>

                  <div className="flex space-x-2 pt-2">
                    {currentUser.savedAddress && (
                      <button
                        type="button"
                        onClick={() => setIsEditingAddress(false)}
                        className="flex-1 h-10 rounded-full border text-xs font-bold text-zinc-500 hover:bg-zinc-50"
                      >
                        Cancel
                      </button>
                    )}
                    <button
                      type="submit"
                      id="addr-save-btn"
                      className="flex-1 h-10 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark"
                    >
                      Save Address
                    </button>
                  </div>
                </form>
              ) : (
                <div className="p-5 rounded-2xl border border-zinc-100 bg-zinc-50/50 space-y-2 max-w-md dark:border-zinc-800 dark:bg-zinc-950/20">
                  <span className="block text-xs font-bold text-zinc-800 dark:text-white">
                    {currentUser.savedAddress.fullName}
                  </span>
                  <span className="block text-xs text-zinc-500">
                    Phone: {currentUser.savedAddress.phoneNumber}
                  </span>
                  <p className="text-xs text-zinc-600 dark:text-zinc-300">
                    {currentUser.savedAddress.fullAddress}, Near {currentUser.savedAddress.landmark}, {currentUser.savedAddress.district}, {currentUser.savedAddress.state} - {currentUser.savedAddress.pinCode}
                  </p>
                  {currentUser.savedAddress.mapLocationUrl && (
                    <div className="pt-2 mt-2 border-t border-zinc-200/60 dark:border-zinc-800/60 flex items-center space-x-2">
                      <MapPin className="h-4 w-4 text-brand-pink shrink-0" />
                      <a
                        href={currentUser.savedAddress.mapLocationUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] font-bold text-brand-pink hover:underline"
                      >
                        Pinned GPS Location Link ↗
                      </a>
                    </div>
                  )}
                </div>
              )}

              {/* Another My Orders section added under Saved Address */}
              <div className="pt-6 border-t border-zinc-100 dark:border-zinc-800/60 max-w-xl" id="saved-address-orders-shortcut-bottom-wrapper">
                <h3 className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 dark:text-zinc-500 mb-3">
                  Quick Access to Purchases
                </h3>
                <div 
                  onClick={() => setSubTab('orders')}
                  className="group flex items-center justify-between rounded-2xl border border-zinc-100 bg-zinc-50/30 p-4 transition-all duration-300 hover:bg-zinc-50/80 hover:border-zinc-200 cursor-pointer dark:border-zinc-800 dark:bg-zinc-950/20 dark:hover:bg-zinc-900/30"
                  id="saved-address-orders-shortcut-bottom"
                >
                  <div className="flex items-center space-x-3">
                    <div className="flex h-9 w-9 items-center justify-center rounded-full bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300 group-hover:scale-105 transition-transform">
                      <ShoppingBag className="h-4.5 w-4.5 text-brand-pink" />
                    </div>
                    <div>
                      <h4 className="text-xs font-extrabold text-zinc-700 dark:text-zinc-200 uppercase tracking-wider">
                        My Orders History
                      </h4>
                      <p className="text-[10px] text-zinc-400 dark:text-zinc-500 mt-0.5">
                        Track current order delivery progress, view invoice, or request custom wool arts
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1.5 text-xs font-bold text-brand-pink group-hover:translate-x-1 transition-transform">
                    <span>View Orders</span>
                    <span>→</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* D. LIVE TRACKING SEARCH */}
          {subTab === 'tracking' && (
            <div className="space-y-6" id="tracking-subtab">
              <h2 className="font-display text-base font-bold text-zinc-800 dark:text-white border-b border-zinc-100 pb-2 dark:border-zinc-800">
                Track Ordered Shipments
              </h2>

              <form onSubmit={handleTrackInquirySubmit} className="flex gap-2 max-w-md">
                <input
                  type="text"
                  placeholder="Enter Order ID (e.g., SG-123456) or Tracking No"
                  value={trackingIdInput}
                  onChange={(e) => setTrackingIdInput(e.target.value)}
                  required
                  className="h-10 flex-1 rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white"
                  id="tracking-id-input"
                />
                <button
                  type="submit"
                  id="tracking-search-btn"
                  className="h-10 rounded-xl bg-brand-pink px-5 text-xs font-bold text-white hover:bg-brand-pink-dark"
                >
                  Locate Status
                </button>
              </form>

              {trackedOrder && (
                <div className="p-5 rounded-3xl border border-pink-100 bg-brand-pink-light/10 space-y-4 mt-6 dark:border-zinc-800 dark:bg-pink-950/10">
                  <div className="flex justify-between items-start text-xs border-b border-pink-50 pb-3 dark:border-zinc-800">
                    <div>
                      <span className="block font-bold text-zinc-800 dark:text-white">Order: {trackedOrder.id}</span>
                      <span className="block text-[10px] text-zinc-400">Tracking Number: {trackedOrder.trackingNumber || 'N/A'}</span>
                    </div>
                    
                    <span className="rounded-full bg-brand-pink px-2.5 py-1 text-[10px] font-bold text-white uppercase">
                      {trackedOrder.status}
                    </span>
                  </div>

                  {/* Tracking logs */}
                  <div className="space-y-4">
                    <span className="block text-[10px] font-bold uppercase tracking-wider text-zinc-400">Activity Updates logs:</span>
                    <div className="space-y-3.5 pl-2 relative border-l-2 border-pink-100 dark:border-zinc-800 ml-1.5">
                      {trackedOrder.trackingUpdates?.map((upd, uIdx) => (
                        <div key={uIdx} className="relative pl-4">
                          {/* Circle dot */}
                          <div className="absolute -left-1.5 top-1 h-3 w-3 rounded-full bg-brand-pink" />
                          <span className="block text-[10px] text-zinc-400 font-bold">{upd.date}</span>
                          <span className="block text-xs font-bold text-zinc-800 dark:text-zinc-200 mt-0.5">{upd.status}</span>
                          <p className="text-[11px] text-zinc-500 mt-0.5">{upd.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
