import React, { useState } from 'react';
import { ShoppingCart, Trash2, ArrowRight, ArrowLeft, Ticket, ShieldCheck, Truck, Clock, Sparkles, Eye, EyeOff } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { CartItem, ShippingAddress, Order, Coupon, User } from '../types';
import { COUPONS } from '../data';

interface CartProps {
  cart: CartItem[];
  onUpdateQuantity: (productId: string, color: string, newQty: number) => void;
  onRemoveItem: (productId: string, color: string) => void;
  onClearCart: () => void;
  setCurrentTab: (tab: string) => void;
  onPlaceOrder: (order: Order) => void;
  savedAddress?: ShippingAddress;
  currentUser: User | null;
  onLogin: (user: User) => void;
  coupons?: Coupon[];
  qrCodeUrl?: string;
}

export default function Cart({
  cart,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  setCurrentTab,
  onPlaceOrder,
  savedAddress,
  currentUser,
  onLogin,
  coupons = COUPONS,
  qrCodeUrl
}: CartProps) {
  const [step, setStep] = useState<'cart' | 'checkout'>('cart');
  
  // Coupon state
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState('');

  // Animation state
  const [showCouponSuccessAnim, setShowCouponSuccessAnim] = useState(false);
  const [justSavedAmount, setJustSavedAmount] = useState(0);

  // Shipping form state
  const [fullName, setFullName] = useState(savedAddress?.fullName || '');
  const [phoneNumber, setPhoneNumber] = useState(savedAddress?.phoneNumber || '');
  const [fullAddress, setFullAddress] = useState(savedAddress?.fullAddress || '');
  const [landmark, setLandmark] = useState(savedAddress?.landmark || '');
  const [district, setDistrict] = useState(savedAddress?.district || '');
  const [state, setState] = useState(savedAddress?.state || '');
  const [pinCode, setPinCode] = useState(savedAddress?.pinCode || '');
  const [deliveryNote, setDeliveryNote] = useState(savedAddress?.deliveryNote || '');
  
  // Payment state
  const [paymentMethod, setPaymentMethod] = useState<'COD' | 'UPI' | 'Google Pay' | 'PhonePe' | 'Paytm'>('COD');

  // Synchronize form states when saved address is updated/available
  React.useEffect(() => {
    if (savedAddress) {
      setFullName(savedAddress.fullName || '');
      setPhoneNumber(savedAddress.phoneNumber || '');
      setFullAddress(savedAddress.fullAddress || '');
      setLandmark(savedAddress.landmark || '');
      setDistrict(savedAddress.district || '');
      setState(savedAddress.state || '');
      setPinCode(savedAddress.pinCode || '');
      setDeliveryNote(savedAddress.deliveryNote || '');
    }
  }, [savedAddress]);

  // Cart Authentication forms
  const [cartAuthTab, setCartAuthTab] = useState<'login' | 'register'>('login');
  const [cartEmail, setCartEmail] = useState('');
  const [cartPassword, setCartPassword] = useState('');
  const [cartName, setCartName] = useState('');
  const [cartAuthError, setCartAuthError] = useState('');
  const [showCartLoginPass, setShowCartLoginPass] = useState(false);
  const [showCartRegPass, setShowCartRegPass] = useState(false);

  const handleCartLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCartAuthError('');

    const email = cartEmail.trim();
    const password = cartPassword.trim();

    if (!email || !password) {
      setCartAuthError('All fields are required.');
      return;
    }

    // Admin Credentials
    if (email.toLowerCase() === 'kalyanimajumdar1103@gmail.com') {
      if (password !== '11092007') {
        setCartAuthError('Incorrect password for admin account.');
        return;
      }

      const adminUser: User = {
        id: 'usr-admin',
        name: 'Kalyani Majumdar',
        email: 'kalyanimajumdar1103@gmail.com',
        wishlist: [],
        isAdmin: true,
        savedAddress: {
          fullName: 'Kalyani Majumdar',
          phoneNumber: '8100226410',
          fullAddress: 'Selai Ghor Workshop, Garia',
          landmark: 'Metro Station',
          district: 'Kolkata',
          state: 'West Bengal',
          pinCode: '700084'
        }
      };

      if (onLogin) {
        onLogin(adminUser);
      }
      return;
    }

    const localUsers: User[] = JSON.parse(localStorage.getItem('sg_users') || '[]');
    const matched = localUsers.find(u => u.email.toLowerCase() === email.toLowerCase());

    if (matched) {
       if (matched.password && matched.password !== password) {
         setCartAuthError('Incorrect password. Please try again.');
         return;
       }
       if (onLogin) {
         onLogin(matched);
       }
       return;
    }

    setCartAuthError('This email is not registered yet. Please click the register tab above to create an account.');
  };

  const handleCartRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setCartAuthError('');

    const email = cartEmail.trim();
    const password = cartPassword.trim();
    const name = cartName.trim();

    if (!name || !email || !password) {
      setCartAuthError('All fields are required.');
      return;
    }

    const localUsers: User[] = JSON.parse(localStorage.getItem('sg_users') || '[]');
    const exists = localUsers.some(u => u.email.toLowerCase() === email.toLowerCase());

    if (exists || email.toLowerCase() === 'kalyanimajumdar1103@gmail.com') {
      setCartAuthError('Email already registered! Try logging in.');
      return;
    }

    const newUser: User = {
      id: `usr-${Date.now()}`,
      name: name,
      email: email,
      password: password,
      wishlist: []
    };

    localUsers.push(newUser);
    localStorage.setItem('sg_users', JSON.stringify(localUsers));

    if (onLogin) {
      onLogin(newUser);
    }
  };

  // Calculations
  const getCartItemPrice = (item: CartItem) => {
    const colorPrices = item.product.colorPrices;
    const colorDiscountPrices = item.product.colorDiscountPrices;
    const selectedColor = item.selectedColor;

    const hasColorPrice = colorPrices && colorPrices[selectedColor] !== undefined;
    const hasColorDiscountPrice = colorDiscountPrices && colorDiscountPrices[selectedColor] !== undefined;

    const basePrice = hasColorPrice ? colorPrices![selectedColor] : item.product.price;
    const discountPrice = hasColorDiscountPrice 
      ? colorDiscountPrices![selectedColor] 
      : (hasColorPrice ? undefined : item.product.discountPrice);

    return discountPrice || basePrice;
  };

  const totalPrice = cart.reduce((sum, item) => {
    return sum + (getCartItemPrice(item) * item.quantity);
  }, 0);

  // Free delivery above ₹1000, else flat ₹60
  const deliveryCharge = totalPrice >= 1000 ? 0 : 60;

  // Coupon discount calculation
  let discountApplied = 0;
  if (appliedCoupon) {
    if (appliedCoupon.minPurchase && totalPrice < appliedCoupon.minPurchase) {
      // Coupon invalid due to min purchase
      setAppliedCoupon(null);
      setCouponError(`Min purchase of ₹${appliedCoupon.minPurchase} required for ${appliedCoupon.code}`);
    } else {
      const typeLower = appliedCoupon.discountType.toLowerCase().trim();
      if (typeLower.includes('percent') || typeLower === '%') {
        discountApplied = Math.round((totalPrice * appliedCoupon.discountValue) / 100);
      } else {
        discountApplied = appliedCoupon.discountValue;
      }
    }
  }

  const grandTotal = totalPrice + deliveryCharge - discountApplied;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    const couponList = coupons || COUPONS;
    const found = couponList.find(c => c.code.toUpperCase() === couponCode.trim().toUpperCase());

    if (!found) {
      setCouponError('Invalid coupon code!');
      return;
    }

    if (found.minPurchase && totalPrice < found.minPurchase) {
      setCouponError(`This coupon requires a minimum purchase of ₹${found.minPurchase}`);
      return;
    }

    let saved = 0;
    const typeLower = found.discountType.toLowerCase().trim();
    if (typeLower.includes('percent') || typeLower === '%') {
      saved = Math.round((totalPrice * found.discountValue) / 100);
    } else {
      saved = found.discountValue;
    }

    setAppliedCoupon(found);
    setCouponCode('');
    setJustSavedAmount(saved);
    setShowCouponSuccessAnim(true);

    // Auto-dismiss the celebration banner after 3.5 seconds
    setTimeout(() => {
      setShowCouponSuccessAnim(false);
    }, 3500);
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
  };

  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!fullName.trim() || !phoneNumber.trim() || !fullAddress.trim() || !landmark.trim() || !district.trim() || !state.trim() || !pinCode.trim()) {
      alert('Please fill out all required fields marked with *');
      return;
    }

    // Build Shipping address details
    const shippingDetails: ShippingAddress = {
      fullName,
      phoneNumber,
      fullAddress,
      landmark,
      district,
      state,
      pinCode,
      deliveryNote
    };

    // Construct local tracking ID & date
    const orderId = `SG-${Math.floor(100000 + Math.random() * 900000)}`;
    const orderDateFormatted = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });

    // Place local state order
    const completedOrder: Order = {
      id: orderId,
      userId: currentUser?.id,
      userEmail: currentUser?.email,
      items: cart,
      address: shippingDetails,
      paymentMethod,
      orderDate: orderDateFormatted,
      totalPrice,
      deliveryCharge,
      discountApplied,
      grandTotal,
      status: 'Pending',
      trackingNumber: `TRK-${Math.floor(1000000 + Math.random() * 9000000)}`,
      trackingUpdates: [
        { date: orderDateFormatted, status: 'Pending', description: 'Order submitted and awaiting verification.' }
      ]
    };

    onPlaceOrder(completedOrder);

    // Prepare WhatsApp Message according to specifications
    const formattedProducts = cart.map((item, idx) => {
      const price = getCartItemPrice(item);
      return `${idx + 1}. ${item.product.name} (${item.selectedColor}) x ${item.quantity} - ₹${price * item.quantity}`;
    }).join('\n');

    const waMessage = `*New Order - Selai Ghor* 🌸

*Order ID:* ${orderId}
*Date:* ${orderDateFormatted}

*Name:* ${fullName}
*Phone:* ${phoneNumber}
*Address:* ${fullAddress}, Landmark: ${landmark}, ${district}, ${state}
*PIN Code:* ${pinCode}
${deliveryNote ? `*Delivery Note:* ${deliveryNote}\n` : ''}
*Products:*
${formattedProducts}

*Subtotal:* ₹${totalPrice}
*Delivery Charge:* ${deliveryCharge === 0 ? 'FREE' : `₹${deliveryCharge}`}
${discountApplied > 0 ? `*Discount Applied:* -₹${discountApplied}\n` : ''}*Grand Total:* ₹${grandTotal}

*Payment Method:* ${paymentMethod}

Thank You for supporting handcrafted local wool art! ❤️`;

    const encodedMsg = encodeURIComponent(waMessage);
    const whatsappNum = '918100226410'; // +91 81002 26410
    const waUrl = `https://wa.me/${whatsappNum}?text=${encodedMsg}`;

    // Clear cart & open WhatsApp
    setTimeout(() => {
      onClearCart();
      window.open(waUrl, '_blank');
      setCurrentTab('account'); // Redirect user to check order tracking history
    }, 500);
  };

  // If cart is empty and we are on cart step
  if (cart.length === 0 && step === 'cart') {
    return (
      <div className="mx-auto max-w-xl px-4 py-16 text-center" id="empty-cart-view">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-pink-100 text-brand-pink mb-4 dark:bg-pink-950/20">
          <ShoppingCart className="h-8 w-8" />
        </div>
        <h2 className="font-display text-xl font-bold text-zinc-900 dark:text-white">Your Shopping Cart is Empty</h2>
        <p className="text-xs text-zinc-500 mt-2">
          Add beautiful handmade crochet and wool creations to your cart to begin supporting local artists!
        </p>
        <button
          onClick={() => setCurrentTab('shop')}
          className="mt-6 rounded-full bg-brand-pink px-8 py-3 text-xs font-bold text-white shadow-lg hover:bg-brand-pink-dark transition-colors cursor-pointer"
        >
          Explore Products
        </button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8 text-left" id="cart-parent-view">
      
      {/* Title Header */}
      <div className="mb-8">
        <h1 className="font-display text-2xl font-extrabold sm:text-3xl text-zinc-900 dark:text-white">
          {step === 'cart' ? 'Shopping Cart' : 'Secure Checkout'}
        </h1>
        <div className="flex items-center space-x-2 text-xs font-bold text-zinc-400 mt-1">
          <span className={step === 'cart' ? 'text-brand-pink' : ''}>1. Review Cart</span>
          <span>&gt;</span>
          <span className={step === 'checkout' ? 'text-brand-pink' : ''}>2. Delivery Information & Order</span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-10 lg:grid-cols-12 items-start">
        
        {/* Step 1: Review Cart List (lg:span-8) */}
        {step === 'cart' ? (
          <div className="lg:col-span-8 space-y-4">
            <div className="rounded-2xl border border-pink-50 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900">
              <div className="divide-y divide-zinc-100 dark:divide-zinc-800" id="cart-items-container">
                {cart.map((item) => {
                  const productPrice = getCartItemPrice(item);
                  return (
                    <div
                      key={`${item.product.id}-${item.selectedColor}`}
                      id={`cart-row-${item.product.id}`}
                      className="flex flex-col sm:flex-row sm:items-center justify-between py-4 first:pt-0 last:pb-0"
                    >
                      {/* Product Thumbnail & metadata */}
                      <div className="flex space-x-4 items-center">
                        <div className="h-16 w-16 overflow-hidden rounded-xl bg-zinc-50 dark:bg-zinc-800">
                          <img
                            src={item.product.images[0]}
                            alt={item.product.name}
                            referrerPolicy="no-referrer"
                            className="h-full w-full object-cover"
                          />
                        </div>
                        <div className="text-left">
                          <span className="text-[9px] font-bold text-brand-purple uppercase tracking-wider">
                            {item.product.category}
                          </span>
                          <h3 className="font-display text-xs font-bold text-zinc-800 dark:text-white leading-tight">
                            {item.product.name}
                          </h3>
                          <span className="block text-[10px] text-zinc-400 mt-0.5">
                            Color: <strong className="text-zinc-700 dark:text-zinc-200">{item.selectedColor}</strong>
                          </span>
                        </div>
                      </div>

                      {/* Quantity controllers & total price */}
                      <div className="flex items-center justify-between sm:space-x-8 mt-3 sm:mt-0">
                        {/* Qty incrementer */}
                        <div className="flex items-center rounded-xl border border-zinc-200 bg-zinc-50 p-0.5 dark:border-zinc-800 dark:bg-zinc-950">
                          <button
                            id={`qty-dec-${item.product.id}`}
                            onClick={() => onUpdateQuantity(item.product.id, item.selectedColor, Math.max(1, item.quantity - 1))}
                            className="p-1 text-zinc-500 hover:text-brand-pink"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                          <span className="w-8 text-center text-xs font-bold text-zinc-800 dark:text-white">
                            {item.quantity}
                          </span>
                          <button
                            id={`qty-inc-${item.product.id}`}
                            onClick={() => onUpdateQuantity(item.product.id, item.selectedColor, item.quantity + 1)}
                            className="p-1 text-zinc-500 hover:text-brand-pink"
                          >
                            <span className="text-xs font-bold px-1">+</span>
                          </button>
                        </div>

                        {/* Price computation */}
                        <div className="text-right min-w-[80px]">
                          <span className="block text-xs font-extrabold text-zinc-900 dark:text-white">
                            ₹{productPrice * item.quantity}
                          </span>
                          <span className="block text-[9px] text-zinc-400">
                            (₹{productPrice} each)
                          </span>
                        </div>

                        {/* Delete button */}
                        <button
                          id={`del-btn-${item.product.id}`}
                          onClick={() => onRemoveItem(item.product.id, item.selectedColor)}
                          className="text-zinc-400 hover:text-red-500 p-1"
                          title="Remove item"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>

                    </div>
                  );
                })}
              </div>
            </div>

            {/* Back action */}
            <button
              onClick={() => setCurrentTab('shop')}
              className="inline-flex items-center space-x-2 text-xs font-bold text-zinc-500 hover:text-brand-pink transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              <span>Continue Shopping</span>
            </button>
          </div>
        ) : !currentUser ? (
          /* Step 2 Secure Login Wall */
          <div className="lg:col-span-8">
            <div className="p-6 sm:p-8 rounded-3xl border border-pink-100 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900 text-left">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-pink-100 text-brand-pink mb-4 dark:bg-pink-950/20">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h2 className="font-display text-xl font-extrabold text-zinc-900 dark:text-white">
                Checkout Verification Required
              </h2>
              <p className="text-xs text-zinc-500 mt-2 leading-relaxed">
                To proceed with your purchase, please sign in to your Selai Ghor account first. This secures your handcrafted order, links it to your email address, and enables real-time tracking.
              </p>

              {/* Toggle tabs for Cart Auth */}
              <div className="flex border-b border-pink-50 my-6 dark:border-zinc-800">
                <button
                  type="button"
                  id="cart-auth-tab-login"
                  onClick={() => setCartAuthTab('login')}
                  className={`flex-1 pb-3 text-center text-xs font-bold uppercase tracking-wider ${
                    cartAuthTab === 'login' 
                      ? 'border-b-2 border-brand-pink text-brand-pink dark:text-pink-400' 
                      : 'text-zinc-400 hover:text-zinc-600'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  id="cart-auth-tab-register"
                  onClick={() => setCartAuthTab('register')}
                  className={`flex-1 pb-3 text-center text-xs font-bold uppercase tracking-wider ${
                    cartAuthTab === 'register' 
                      ? 'border-b-2 border-brand-pink text-brand-pink dark:text-pink-400' 
                      : 'text-zinc-400 hover:text-zinc-600'
                  }`}
                >
                  Register
                </button>
              </div>

              {cartAuthTab === 'login' ? (
                <form onSubmit={handleCartLoginSubmit} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="cart-login-email"
                      placeholder="e.g. rahul@example.com"
                      value={cartEmail}
                      onChange={(e) => setCartEmail(e.target.value)}
                      required
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      Password
                    </label>
                    <div className="relative">
                      <input
                        type={showCartLoginPass ? "text" : "password"}
                        id="cart-login-password"
                        placeholder="••••••••"
                        value={cartPassword}
                        onChange={(e) => setCartPassword(e.target.value)}
                        required
                        className="h-10 w-full rounded-xl border border-zinc-200 pl-3 pr-10 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCartLoginPass(!showCartLoginPass)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300"
                      >
                        {showCartLoginPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  {cartAuthError && (
                    <div className="text-[10px] font-bold text-red-500" id="cart-auth-error-msg-login">{cartAuthError}</div>
                  )}

                  <button
                    type="submit"
                    id="cart-login-submit-btn"
                    className="w-full h-11 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark transition-all cursor-pointer"
                  >
                    Sign In & Continue to Delivery
                  </button>

                  <div className="text-center pt-2.5 border-t border-zinc-100 dark:border-zinc-800/80 mt-2 flex flex-col items-center gap-1.5">
                    <span className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest">
                      Admin Login
                    </span>
                    <span className="text-[10px] text-zinc-500 leading-relaxed dark:text-zinc-400">
                      Enter authorized admin credentials to access the admin portal.
                    </span>
                  </div>
                </form>
              ) : (
                <form onSubmit={handleCartRegisterSubmit} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      Full Name
                    </label>
                    <input
                      type="text"
                      id="cart-reg-name"
                      placeholder="e.g. Rahul Halder"
                      value={cartName}
                      onChange={(e) => setCartName(e.target.value)}
                      required
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      Email Address
                    </label>
                    <input
                      type="email"
                      id="cart-reg-email"
                      placeholder="e.g. rahul@example.com"
                      value={cartEmail}
                      onChange={(e) => setCartEmail(e.target.value)}
                      required
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      Password
                    </label>
                    <div className="relative">
                      <input
                        type={showCartRegPass ? "text" : "password"}
                        id="cart-reg-password"
                        placeholder="••••••••"
                        value={cartPassword}
                        onChange={(e) => setCartPassword(e.target.value)}
                        required
                        className="h-10 w-full rounded-xl border border-zinc-200 pl-3 pr-10 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                      />
                      <button
                        type="button"
                        onClick={() => setShowCartRegPass(!showCartRegPass)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600 dark:hover:text-zinc-300"
                      >
                        {showCartRegPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                  </div>

                  {cartAuthError && (
                    <div className="text-[10px] font-bold text-red-500" id="cart-auth-error-msg-reg">{cartAuthError}</div>
                  )}

                  <button
                    type="submit"
                    id="cart-reg-submit-btn"
                    className="w-full h-11 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark transition-all cursor-pointer"
                  >
                    Register & Continue
                  </button>
                </form>
              )}

              <div className="mt-6 pt-4 border-t border-zinc-100 dark:border-zinc-800">
                <button
                  type="button"
                  id="cart-auth-back-btn"
                  onClick={() => setStep('cart')}
                  className="inline-flex items-center space-x-2 text-xs font-bold text-zinc-500 hover:text-brand-pink transition-colors"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span>Back to Review Cart</span>
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* Step 2: Shipping Details Form (lg:span-8) */
          <div className="lg:col-span-8">
            <form onSubmit={handleCheckoutSubmit} className="space-y-6">
              
              <div className="p-6 rounded-3xl border border-pink-50 bg-white space-y-4 dark:border-zinc-800 dark:bg-zinc-900">
                <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white border-b border-zinc-100 pb-2 dark:border-zinc-800">
                  Delivery Details (All fields except Delivery Note are required)
                </h3>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      Full Name <span className="text-brand-pink">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Rahul Halder"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      required
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                      id="shipping-fullname"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      Phone Number <span className="text-brand-pink">*</span>
                    </label>
                    <input
                      type="tel"
                      placeholder="10-digit mobile number"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      required
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                      id="shipping-phone"
                    />
                  </div>
                </div>

                <div>
                  <div className="mb-1">
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      Full Address <span className="text-brand-pink">*</span>
                    </label>
                  </div>
                  <textarea
                    rows={3}
                    placeholder="House/Flat No, Apartment/Street Name, City/Town"
                    value={fullAddress}
                    onChange={(e) => setFullAddress(e.target.value)}
                    required
                    className="w-full rounded-xl border border-zinc-200 p-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                    id="shipping-address"
                  />
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      Landmark <span className="text-brand-pink">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Near Big Bazaar"
                      value={landmark}
                      onChange={(e) => setLandmark(e.target.value)}
                      required
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                      id="shipping-landmark"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      District <span className="text-brand-pink">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. South 24 Parganas"
                      value={district}
                      onChange={(e) => setDistrict(e.target.value)}
                      required
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                      id="shipping-district"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      State <span className="text-brand-pink">*</span>
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. West Bengal"
                      value={state}
                      onChange={(e) => setState(e.target.value)}
                      required
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                      id="shipping-state"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      PIN Code <span className="text-brand-pink">*</span>
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      placeholder="6-digit PIN"
                      value={pinCode}
                      onChange={(e) => setPinCode(e.target.value)}
                      required
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                      id="shipping-pincode"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500 mb-1 dark:text-zinc-400">
                      Delivery Note (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. Deliver on weekends, call before delivery"
                      value={deliveryNote}
                      onChange={(e) => setDeliveryNote(e.target.value)}
                      className="h-10 w-full rounded-xl border border-zinc-200 px-3 text-xs outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                      id="shipping-note"
                    />
                  </div>
                </div>
              </div>

              {/* Payment Methods */}
              <div className="p-6 rounded-3xl border border-pink-50 bg-white space-y-4 dark:border-zinc-800 dark:bg-zinc-900">
                <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white border-b border-zinc-100 pb-2 dark:border-zinc-800">
                  Select Payment Method
                </h3>

                <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2" id="payment-methods-grid">
                  {[
                    { id: 'COD', label: 'Cash on Delivery (COD)' },
                    { id: 'UPI', label: 'UPI / NetBanking' },
                    { id: 'Google Pay', label: 'Google Pay' },
                    { id: 'PhonePe', label: 'PhonePe' },
                    { id: 'Paytm', label: 'Paytm' }
                  ].map((pay) => (
                    <label
                      key={pay.id}
                      className={`flex items-center space-x-3 rounded-2xl border p-4 cursor-pointer transition-all ${
                        paymentMethod === pay.id
                          ? 'border-brand-pink bg-brand-pink-light/35 text-brand-pink dark:border-pink-500 dark:bg-pink-950/20 dark:text-pink-400'
                          : 'border-zinc-100 hover:bg-zinc-50 dark:border-zinc-800 dark:hover:bg-zinc-800/30'
                      }`}
                    >
                      <input
                        type="radio"
                        name="payment_method"
                        checked={paymentMethod === pay.id}
                        onChange={() => setPaymentMethod(pay.id as any)}
                        className="h-4 w-4 text-brand-pink focus:ring-brand-pink"
                      />
                      <span className="text-xs font-bold text-zinc-700 dark:text-zinc-200">{pay.label}</span>
                    </label>
                  ))}
                </div>

                {paymentMethod !== 'COD' && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="p-5 rounded-2xl bg-zinc-50 border border-zinc-200 text-left space-y-4 dark:bg-zinc-950/20 dark:border-zinc-800 mt-4"
                  >
                    <span className="block text-[10px] font-extrabold uppercase tracking-widest text-zinc-500 dark:text-zinc-400">Scan & Pay Securely</span>
                    
                    <div className="flex flex-col md:flex-row items-center gap-6">
                      {/* Branded UPI QR Card mimicking Fampay/Trio style */}
                      <div className="bg-[#e6e6e6] text-zinc-900 border border-zinc-300 rounded-3xl p-5 shadow-inner w-full max-w-[240px] flex flex-col items-center justify-center space-y-3 font-sans relative">
                        {/* Top UPI ID */}
                        <div className="text-sm font-black text-zinc-800 tracking-wide font-sans text-center">
                          {qrCodeUrl ? 'Custom Store Payment' : '9339483660@fam'}
                        </div>
                        
                        {/* QR Code Container */}
                        <div className="relative bg-white p-3 rounded-2xl border border-zinc-200 shadow-md flex items-center justify-center shrink-0">
                          <img
                            src={qrCodeUrl || `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=upi://pay?pa=9339483660@fam%26pn=Selai%20Ghor%26am=${grandTotal}%26cu=INR%26tn=Selai%20Ghor%20Order`}
                            alt="Payment QR Code"
                            referrerPolicy="no-referrer"
                            className="h-28 w-28 object-contain rounded-lg"
                          />
                          {/* Absolute center logo matching the black circle + orange X */}
                          {!qrCodeUrl && (
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-zinc-900 h-6.5 w-6.5 rounded-full flex items-center justify-center border-2 border-white shadow-md">
                              <span className="text-amber-500 font-extrabold text-xs tracking-tighter leading-none select-none">X</span>
                            </div>
                          )}
                        </div>

                        {/* Bottom Branding */}
                        <div className="flex items-center justify-between w-full pt-1.5 px-1 border-t border-zinc-300">
                          <span className="text-zinc-800 font-black text-[11px] tracking-tight lowercase">triö</span>
                          <span className="text-[10px] tracking-widest uppercase font-black flex items-center">
                            <span className="text-blue-600">U</span>
                            <span className="text-orange-500">P</span>
                            <span className="text-green-600">I</span>
                          </span>
                        </div>
                      </div>

                      {/* Explanation and WhatsApp note */}
                      <div className="flex-1 space-y-3">
                        <p className="text-zinc-700 dark:text-zinc-300 text-xs leading-relaxed">
                          Please scan the QR code using any UPI app (GPay, PhonePe, Paytm, BHIM, FamPay) to complete your payment of <strong className="text-brand-pink dark:text-pink-400 text-sm font-black">₹{grandTotal}</strong>.
                        </p>
                        <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-100 dark:bg-amber-950/10 dark:border-amber-900/20 text-[11px] text-amber-800 dark:text-amber-300 space-y-1">
                          <p className="font-bold flex items-center gap-1.5">
                            <span>💡 Important Step / গুরুত্বপূর্ণ ধাপ:</span>
                          </p>
                          <p className="leading-relaxed">
                            After successful payment, please take a screenshot and send it to our official WhatsApp along with your order details to confirm your order.
                          </p>
                          <p className="italic text-[10px] text-amber-600 dark:text-amber-400/80 mt-1">
                            পেমেন্ট করার পর স্ক্রিনশটটি অবশ্যই হোয়াটসঅ্যাপে পাঠিয়ে অর্ডার নিশ্চিত করুন।
                          </p>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </div>

              {/* Actions row */}
              <div className="flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => setStep('cart')}
                  className="inline-flex items-center space-x-2 text-xs font-bold text-zinc-500 hover:text-brand-pink transition-colors"
                >
                  <ArrowLeft className="h-4 w-4" />
                  <span>Back to Cart Review</span>
                </button>

                <button
                  type="submit"
                  id="checkout-submit-btn"
                  className="inline-flex items-center space-x-2 rounded-full bg-brand-pink px-8 py-4 text-sm font-bold text-white shadow-lg shadow-pink-200 hover:bg-brand-pink-dark hover:shadow-pink-300 dark:shadow-none transition-all cursor-pointer animate-pulse"
                >
                  <span>Place Order via WhatsApp</span>
                  <ArrowRight className="h-4.5 w-4.5" />
                </button>
              </div>

            </form>
          </div>
        )}

        {/* Column Right: Billing Summary (lg:span-4) */}
        <div className="lg:col-span-4 space-y-4 md:sticky md:top-24" id="billing-summary-column">
          <div className="rounded-3xl border border-pink-100 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-900 text-left">
            <h3 className="font-display text-sm font-bold text-zinc-800 dark:text-white mb-4 pb-2 border-b border-zinc-100 dark:border-zinc-800">
              Order Summary
            </h3>

            {/* Price lines */}
            <div className="space-y-3 text-xs font-medium text-zinc-600 dark:text-zinc-300">
              <div className="flex justify-between">
                <span>Subtotal ({cart.reduce((sum, item) => sum + item.quantity, 0)} items)</span>
                <span className="font-bold text-zinc-900 dark:text-white">₹{totalPrice}</span>
              </div>
              
              <div className="flex justify-between">
                <span>Delivery Charge</span>
                <span className={deliveryCharge === 0 ? 'text-brand-green font-bold' : 'font-bold text-zinc-900 dark:text-white'}>
                  {deliveryCharge === 0 ? 'FREE' : `₹${deliveryCharge}`}
                </span>
              </div>

              {discountApplied > 0 && (
                <div className="flex justify-between text-brand-pink">
                  <span>Coupon Discount</span>
                  <span className="font-bold">-₹{discountApplied}</span>
                </div>
              )}

              <hr className="border-pink-50 dark:border-zinc-800" />

              <div className="flex justify-between text-base font-bold text-zinc-900 dark:text-white">
                <span>Grand Total</span>
                <span className="text-brand-pink font-extrabold dark:text-pink-400">₹{grandTotal}</span>
              </div>
            </div>

            {/* Coupons Form */}
            {step === 'cart' && (
              <div className="mt-6 pt-6 border-t border-zinc-100 dark:border-zinc-800">
                <span className="block text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-2 dark:text-zinc-500">
                  Promo / Coupon Code
                </span>
                
                {appliedCoupon ? (
                  <div className="flex items-center justify-between rounded-xl bg-brand-pink-light/50 p-2 text-xs border border-pink-100 dark:bg-pink-950/20 dark:border-zinc-800">
                    <div className="flex items-center space-x-1.5 text-brand-pink font-bold">
                      <Ticket className="h-4 w-4" />
                      <span>{appliedCoupon.code} applied!</span>
                    </div>
                    <button
                      onClick={handleRemoveCoupon}
                      className="text-xs font-extrabold text-zinc-400 hover:text-brand-pink"
                    >
                      Remove
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleApplyCoupon} className="flex gap-2">
                    <input
                      type="text"
                      placeholder="e.g. SALE20"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      className="h-10 flex-1 rounded-xl border border-zinc-200 px-3 text-xs font-bold uppercase outline-none focus:border-brand-pink dark:border-zinc-800 dark:bg-zinc-950 dark:text-white dark:focus:border-pink-500"
                      id="coupon-apply-input"
                    />
                    <button
                      type="submit"
                      id="coupon-apply-btn"
                      className="h-10 rounded-xl bg-zinc-800 px-4 text-xs font-bold text-white hover:bg-zinc-950 transition-colors"
                    >
                      Apply
                    </button>
                  </form>
                )}

                {/* Coupons tips list */}
                <div className="mt-3 space-y-1">
                  <span className="block text-[9px] font-bold uppercase tracking-wide text-zinc-400">Available Coupons to try:</span>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {['WELCOME10', 'SALE20', 'FESTIVAL50'].map(code => (
                      <button
                        key={code}
                        type="button"
                        onClick={() => setCouponCode(code)}
                        className="text-[10px] font-bold text-zinc-500 bg-zinc-50 border px-1.5 py-0.5 rounded hover:border-brand-pink hover:text-brand-pink dark:bg-zinc-800 dark:text-zinc-300 dark:border-zinc-700"
                      >
                        {code}
                      </button>
                    ))}
                  </div>
                </div>

                {couponError && (
                  <span className="block text-[10px] text-red-500 font-semibold mt-1.5">{couponError}</span>
                )}
              </div>
            )}

            {/* Quick checkouts trigger on Cart step */}
            {step === 'cart' && (
              <button
                id="cart-checkout-proceed-btn"
                onClick={() => setStep('checkout')}
                className="w-full h-12 rounded-full bg-brand-pink text-xs font-bold text-white shadow-md hover:bg-brand-pink-dark transition-colors mt-6 flex items-center justify-center space-x-2 cursor-pointer"
              >
                <span>Proceed to Checkout</span>
                <ArrowRight className="h-4.5 w-4.5" />
              </button>
            )}
          </div>

          {/* Secure Trust items */}
          <div className="rounded-3xl border border-zinc-100 bg-zinc-50/50 p-4 space-y-3 dark:border-zinc-800 dark:bg-zinc-950/40 text-left">
            <div className="flex items-center space-x-2.5 text-xs font-semibold text-zinc-700 dark:text-zinc-300">
              <ShieldCheck className="h-5 w-5 text-brand-pink" />
              <span>Direct WhatsApp Verification</span>
            </div>
            
            <div className="flex items-center space-x-2.5 text-xs font-semibold text-zinc-700 dark:text-zinc-300">
              <Truck className="h-5 w-5 text-brand-purple" />
              <span>Fast local express shipping (3-5 days)</span>
            </div>

            <div className="flex items-center space-x-2.5 text-xs font-semibold text-zinc-700 dark:text-zinc-300">
              <Clock className="h-5 w-5 text-brand-green" />
              <span>Safe COD & online payments</span>
            </div>
          </div>
        </div>

      </div>

      {/* Coupon Celebration Success Animation Overlay */}
      <AnimatePresence>
        {showCouponSuccessAnim && appliedCoupon && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center pointer-events-none">
            {/* Backdrop filter effect */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/40 backdrop-blur-xs pointer-events-auto"
              onClick={() => setShowCouponSuccessAnim(false)}
            />
            
            {/* Celebration Dialog */}
            <motion.div
              initial={{ scale: 0.3, opacity: 0, rotate: -8 }}
              animate={{ scale: 1, opacity: 1, rotate: 0 }}
              exit={{ scale: 0.8, opacity: 0, y: 40 }}
              transition={{ type: 'spring', damping: 15, stiffness: 180 }}
              className="relative mx-4 w-full max-w-sm overflow-hidden rounded-3xl border border-pink-100 bg-white/95 p-6 text-center shadow-2xl backdrop-blur-md dark:border-zinc-800 dark:bg-zinc-950/95 pointer-events-auto"
            >
              {/* Confetti yarn shapes using simple elements and keyframes */}
              <div className="absolute inset-0 overflow-hidden pointer-events-none opacity-40">
                {Array.from({ length: 15 }).map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{
                      x: Math.random() * 300 - 150,
                      y: -50,
                      scale: Math.random() * 0.5 + 0.5,
                      rotate: 0,
                    }}
                    animate={{
                      y: 350,
                      rotate: 360,
                    }}
                    transition={{
                      duration: Math.random() * 2 + 1.5,
                      repeat: Infinity,
                      ease: 'linear',
                    }}
                    className={`absolute h-3 w-3 rounded-full ${
                      i % 3 === 0 ? 'bg-pink-400' : i % 3 === 1 ? 'bg-purple-400' : 'bg-amber-400'
                    }`}
                  />
                ))}
              </div>

              {/* Sparkles, tickets, and discount stars */}
              <div className="relative mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-pink-100 dark:bg-pink-950/40 text-brand-pink">
                <motion.div
                  animate={{ rotate: [0, 15, -15, 0], scale: [1, 1.1, 0.9, 1] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                >
                  <Ticket className="h-10 w-10 text-brand-pink" />
                </motion.div>
                <motion.div
                  animate={{ scale: [1, 1.3, 1] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                  className="absolute -top-1 -right-1 text-amber-500"
                >
                  <Sparkles className="h-5 w-5 fill-current" />
                </motion.div>
              </div>

              <span className="inline-block rounded-full bg-brand-pink/10 px-3.5 py-1 text-[10px] font-black uppercase tracking-widest text-brand-pink dark:text-pink-400">
                {appliedCoupon.code} Activated!
              </span>

              <h3 className="font-display text-lg font-black text-zinc-900 dark:text-white mt-3.5">
                🎉 Congratulations!
              </h3>
              
              <p className="text-xs text-zinc-500 dark:text-zinc-400 mt-2 leading-relaxed">
                You just unlocked a discount of
              </p>
              
              <div className="my-3 flex items-center justify-center space-x-1">
                <span className="text-3xl font-black text-brand-pink dark:text-pink-400">
                  ₹{justSavedAmount}
                </span>
                <span className="text-xs font-bold text-zinc-400 uppercase tracking-widest self-end pb-1">
                  OFF
                </span>
              </div>

              <p className="text-[10px] text-zinc-400 font-semibold leading-normal border-t border-zinc-100 dark:border-zinc-800/80 pt-3">
                {appliedCoupon.discountType === 'percentage' 
                  ? `${appliedCoupon.discountValue}% discount applied to your wool collection!` 
                  : `Flat ₹${appliedCoupon.discountValue} discount deducted from your invoice total.`
                }
              </p>

              <button
                onClick={() => setShowCouponSuccessAnim(false)}
                className="mt-5 w-full h-10 rounded-full bg-zinc-900 text-xs font-bold text-white hover:bg-zinc-950 dark:bg-white dark:text-zinc-950 dark:hover:bg-zinc-100 transition-colors cursor-pointer"
              >
                Awesome, thank you!
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
