import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, X, Sparkles, MessageCircle, ShoppingBag, Palette, User, HelpCircle, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Product, CartItem, Order, User as UserType } from '../types';

interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

interface AiBotProps {
  onNavigate?: (tab: string) => void;
  currentUser?: UserType | null;
  products?: Product[];
  cart?: CartItem[];
  orders?: Order[];
}

export default function AiBot({ onNavigate, currentUser, products, cart, orders }: AiBotProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [history, setHistory] = useState<ChatMessage[]>([
    {
      role: 'model',
      text: "Hi! I'm **Dipa**, your Selai Ghor companion. 🌸 I can help you browse our premium hand-stitched crochet collections, custom orders, delivery times, or help you track an order! Ask me anything."
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [history, isLoading]);

  const handleSend = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed) return;

    setMessage('');
    setHistory(prev => [...prev, { role: 'user', text: trimmed }]);
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: trimmed,
          history: history.slice(1), // omit initial greeting
          userContext: currentUser ? {
            fullName: currentUser.name,
            email: currentUser.email,
            phoneNumber: currentUser.savedAddress?.phoneNumber || 'Not provided',
            address: currentUser.savedAddress ? `${currentUser.savedAddress.fullName}, ${currentUser.savedAddress.phoneNumber}, ${currentUser.savedAddress.fullAddress}, ${currentUser.savedAddress.district}, ${currentUser.savedAddress.state} - ${currentUser.savedAddress.pinCode}` : 'Not provided'
          } : null,
          cartContext: cart && cart.length > 0 ? cart.map(item => ({
            productName: item.product.name,
            category: item.product.category,
            color: item.selectedColor,
            quantity: item.quantity,
            price: item.product.discountPrice || item.product.price
          })) : [],
          ordersContext: orders && orders.length > 0 ? orders.map(o => ({
            orderId: o.id,
            date: o.orderDate,
            total: o.grandTotal,
            status: o.status,
            trackingNumber: o.trackingNumber || 'Not assigned yet',
            items: o.items.map(item => `${item.product.name} (${item.selectedColor}) x${item.quantity}`)
          })) : [],
          productsContext: products ? products.map(p => ({
            id: p.id,
            name: p.name,
            category: p.category,
            price: p.price,
            discountPrice: p.discountPrice,
            availability: p.availability
          })) : []
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get response');
      }

      const data = await response.json();
      let responseText = data.text || 'Sorry, I encountered an issue. Please try again.';

      // Support automatic tab routing/navigation (e.g. [NAVIGATE:shop])
      const navMatch = responseText.match(/\[NAVIGATE:([a-zA-Z-]+)\]/);
      if (navMatch && onNavigate) {
        const targetTab = navMatch[1];
        onNavigate(targetTab);
        // Strip out the navigation tag so it isn't visible in the bubble
        responseText = responseText.replace(/\[NAVIGATE:[a-zA-Z-]+\]/g, '').trim();
      }

      setHistory(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error) {
      console.error('Chat error:', error);
      setHistory(prev => [...prev, { role: 'model', text: "I'm having trouble connecting right now. Please ensure your `GEMINI_API_KEY` is configured in your Settings secrets." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const suggestions = currentUser 
    ? [
        `Hi Dipa, what is in my cart?`,
        "Show me my previous orders",
        "How do I customize a Portrait Doll?",
        "Do you have delivery charges?"
      ]
    : [
        "Tell me about Selai Ghor",
        "How to order a custom doll?",
        "What wool do you use?",
        "Do you offer free delivery?"
      ];

  return (
    <>
      {/* Floating Toggle Button */}
      <motion.button
        id="ai-bot-toggle"
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-brand-pink text-white shadow-xl hover:scale-105 transition-transform cursor-pointer"
        whileTap={{ scale: 0.95 }}
        title="Chat with Dipa"
      >
        {isOpen ? <X className="h-6 w-6 animate-spin-once" /> : (
          <div className="relative">
            <Bot className="h-6 w-6 animate-pulse" />
            <span className="absolute -top-1.5 -right-1.5 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-brand-purple text-[8px] font-bold text-white animate-bounce">
              <Sparkles className="h-2 w-2" />
            </span>
          </div>
        )}
      </motion.button>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="ai-bot-panel"
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            className="fixed bottom-24 right-6 z-50 flex h-[520px] w-96 max-w-[calc(100vw-2rem)] flex-col rounded-3xl border border-pink-100 bg-white/95 backdrop-blur-md shadow-2xl dark:border-zinc-800 dark:bg-zinc-950/95"
          >
            {/* Header */}
            <div className="flex items-center justify-between border-b border-pink-50 p-4 dark:border-zinc-800/80">
              <div className="flex items-center space-x-3 text-left">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-brand-pink text-white">
                  <Bot className="h-5 w-5" />
                </div>
                <div>
                  <h3 className="font-display text-sm font-bold text-zinc-900 dark:text-white flex items-center space-x-1.5">
                    <span>Dipa</span>
                    <span className="inline-block h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                  </h3>
                  <p className="text-[10px] text-zinc-400">Selai Ghor AI Assistant</p>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="rounded-full p-1.5 text-zinc-400 hover:bg-zinc-50 hover:text-zinc-600 dark:hover:bg-zinc-800"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {/* Quick Actions Navigation Row */}
            <div className="flex items-center gap-1.5 overflow-x-auto px-4 py-2 bg-pink-50/20 dark:bg-zinc-900/30 border-b border-pink-50/50 dark:border-zinc-800/40 no-scrollbar">
              <button
                onClick={() => { onNavigate && onNavigate('shop'); }}
                className="flex items-center gap-1 shrink-0 px-2.5 py-1 rounded-full bg-white dark:bg-zinc-900 border border-pink-100 dark:border-zinc-850 text-[10px] font-bold text-zinc-700 dark:text-zinc-300 hover:text-brand-pink hover:border-brand-pink transition-colors cursor-pointer shadow-xs"
              >
                <ShoppingBag className="h-3 w-3 text-brand-pink" />
                <span>Shop</span>
              </button>
              <button
                onClick={() => { onNavigate && onNavigate('custom-order'); }}
                className="flex items-center gap-1 shrink-0 px-2.5 py-1 rounded-full bg-white dark:bg-zinc-900 border border-pink-100 dark:border-zinc-850 text-[10px] font-bold text-zinc-700 dark:text-zinc-300 hover:text-brand-pink hover:border-brand-pink transition-colors cursor-pointer shadow-xs"
              >
                <Palette className="h-3 w-3 text-brand-pink" />
                <span>Custom Order</span>
              </button>
              <button
                onClick={() => { onNavigate && onNavigate('cart'); }}
                className="flex items-center gap-1 shrink-0 px-2.5 py-1 rounded-full bg-white dark:bg-zinc-900 border border-pink-100 dark:border-zinc-850 text-[10px] font-bold text-zinc-700 dark:text-zinc-300 hover:text-brand-pink hover:border-brand-pink transition-colors cursor-pointer shadow-xs"
              >
                <ShoppingBag className="h-3 w-3 text-brand-pink" />
                <span>Cart</span>
              </button>
              <button
                onClick={() => { onNavigate && onNavigate('account'); }}
                className="flex items-center gap-1 shrink-0 px-2.5 py-1 rounded-full bg-white dark:bg-zinc-900 border border-pink-100 dark:border-zinc-850 text-[10px] font-bold text-zinc-700 dark:text-zinc-300 hover:text-brand-pink hover:border-brand-pink transition-colors cursor-pointer shadow-xs"
              >
                <User className="h-3 w-3 text-brand-pink" />
                <span>My Account</span>
              </button>
              <button
                onClick={() => { onNavigate && onNavigate('about-us'); }}
                className="flex items-center gap-1 shrink-0 px-2.5 py-1 rounded-full bg-white dark:bg-zinc-900 border border-pink-100 dark:border-zinc-850 text-[10px] font-bold text-zinc-700 dark:text-zinc-300 hover:text-brand-pink hover:border-brand-pink transition-colors cursor-pointer shadow-xs"
              >
                <HelpCircle className="h-3 w-3 text-brand-pink" />
                <span>About Us</span>
              </button>
            </div>

            {/* Scrollable Message History */}
            <div
              ref={scrollRef}
              className="flex-1 overflow-y-auto p-4 space-y-4"
              id="ai-chat-history"
            >
              {history.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 text-xs text-left leading-relaxed shadow-xs ${
                      msg.role === 'user'
                        ? 'bg-brand-pink text-white rounded-tr-none'
                        : 'bg-zinc-100 text-zinc-800 dark:bg-zinc-900 dark:text-zinc-100 rounded-tl-none'
                    }`}
                  >
                    {/* Render basic custom bullet points or markdown bolding */}
                    {msg.text.split('\n').map((line, lIdx) => {
                      let content: React.ReactNode = line;
                      // Support basic bold text like **Dipa**
                      if (line.includes('**')) {
                        const parts = line.split('**');
                        content = parts.map((part, pIdx) => pIdx % 2 === 1 ? <strong key={pIdx} className="font-extrabold text-brand-pink dark:text-pink-400">{part}</strong> : part);
                      }
                      return (
                        <p key={lIdx} className={lIdx > 0 ? 'mt-1' : ''}>
                          {content}
                        </p>
                      );
                    })}

                    {/* Inline Quick Action Buttons depending on the response content */}
                    {msg.role === 'model' && (
                      <div className="mt-3 flex flex-wrap gap-1.5 border-t border-zinc-200/50 dark:border-zinc-800/50 pt-2">
                        {(msg.text.toLowerCase().includes('shop') || msg.text.toLowerCase().includes('product') || msg.text.toLowerCase().includes('browse') || msg.text.toLowerCase().includes('categories') || msg.text.toLowerCase().includes('collection')) && (
                          <button
                            onClick={() => onNavigate && onNavigate('shop')}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white dark:bg-zinc-800 hover:scale-102 hover:border-brand-pink active:scale-98 text-[9px] font-bold text-brand-pink border border-pink-100 dark:border-zinc-700 transition-all cursor-pointer shadow-xs"
                          >
                            <span>Browse Shop 🛒</span>
                            <ArrowRight className="h-2.5 w-2.5" />
                          </button>
                        )}
                        {(msg.text.toLowerCase().includes('custom') || msg.text.toLowerCase().includes('doll') || msg.text.toLowerCase().includes('amigurumi') || msg.text.toLowerCase().includes('caricature')) && (
                          <button
                            onClick={() => onNavigate && onNavigate('custom-order')}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white dark:bg-zinc-800 hover:scale-102 hover:border-brand-pink active:scale-98 text-[9px] font-bold text-brand-pink border border-pink-100 dark:border-zinc-700 transition-all cursor-pointer shadow-xs"
                          >
                            <span>Order Custom 🎨</span>
                            <ArrowRight className="h-2.5 w-2.5" />
                          </button>
                        )}
                        {(msg.text.toLowerCase().includes('cart') || msg.text.toLowerCase().includes('basket') || msg.text.toLowerCase().includes('checkout') || msg.text.toLowerCase().includes('buy')) && (
                          <button
                            onClick={() => onNavigate && onNavigate('cart')}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white dark:bg-zinc-800 hover:scale-102 hover:border-brand-pink active:scale-98 text-[9px] font-bold text-brand-pink border border-pink-100 dark:border-zinc-700 transition-all cursor-pointer shadow-xs"
                          >
                            <span>My Cart 🛍️</span>
                            <ArrowRight className="h-2.5 w-2.5" />
                          </button>
                        )}
                        {(msg.text.toLowerCase().includes('order') || msg.text.toLowerCase().includes('track') || msg.text.toLowerCase().includes('history') || msg.text.toLowerCase().includes('account') || msg.text.toLowerCase().includes('address')) && (
                          <button
                            onClick={() => onNavigate && onNavigate('account')}
                            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white dark:bg-zinc-800 hover:scale-102 hover:border-brand-pink active:scale-98 text-[9px] font-bold text-brand-pink border border-pink-100 dark:border-zinc-700 transition-all cursor-pointer shadow-xs"
                          >
                            <span>My Account 👤</span>
                            <ArrowRight className="h-2.5 w-2.5" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-zinc-100 text-zinc-400 dark:bg-zinc-900 rounded-2xl rounded-tl-none px-3.5 py-3 text-xs flex items-center space-x-1.5 shadow-sm">
                    <span className="h-2 w-2 rounded-full bg-zinc-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="h-2 w-2 rounded-full bg-zinc-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="h-2 w-2 rounded-full bg-zinc-400 animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}
            </div>

            {/* Suggestions list when history has just greeting or user prompts */}
            {history.length <= 4 && (
              <div className="px-4 pb-2.5 pt-1.5 flex flex-wrap gap-1.5 justify-start border-t border-pink-50/50 dark:border-zinc-800/20">
                {suggestions.map((sug, sIdx) => (
                  <button
                    key={sIdx}
                    onClick={() => handleSend(sug)}
                    className="rounded-full border border-pink-100/80 bg-pink-50/20 px-2.5 py-1 text-[10px] font-semibold text-brand-pink hover:bg-brand-pink hover:text-white transition-all dark:border-zinc-800 dark:bg-zinc-900/30 cursor-pointer"
                  >
                    {sug}
                  </button>
                ))}
              </div>
            )}

            {/* Input form */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend(message);
              }}
              className="border-t border-zinc-100 p-3.5 flex items-center gap-2 dark:border-zinc-800"
            >
              <input
                type="text"
                placeholder={currentUser ? `Ask Dipa anything, ${currentUser.name.split(' ')[0]}...` : "Ask Dipa anything..."}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                disabled={isLoading}
                className="flex-1 h-9 rounded-full border border-zinc-200 bg-zinc-50 px-4 text-xs font-medium text-zinc-800 outline-none focus:border-brand-pink focus:bg-white dark:border-zinc-800 dark:bg-zinc-900 dark:text-white dark:focus:border-pink-500"
                id="ai-chat-input"
              />
              <button
                type="submit"
                disabled={isLoading || !message.trim()}
                className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-pink text-white hover:bg-brand-pink-dark transition-colors disabled:opacity-50 cursor-pointer"
              >
                <Send className="h-3.5 w-3.5" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
