export interface Product {
  id: string;
  name: string;
  price: number;
  discountPrice?: number;
  category: string;
  images: string[]; // multiple images
  availability: 'In Stock' | 'Out of Stock' | 'Pre-order';
  shortDescription: string;
  description: string;
  materialsUsed: string;
  size: string;
  weight: string;
  estimatedDelivery: string;
  colorOptions: string[]; // name or hex colors
  colorImages?: { [color: string]: string[] }; // color-specific images
  colorPrices?: { [color: string]: number }; // color-specific original prices
  colorDiscountPrices?: { [color: string]: number }; // color-specific discount prices
  rating: number;
}

export interface Review {
  id: string;
  productId: string;
  customerName: string;
  rating: number;
  comment: string;
  image?: string;
  date: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedColor: string;
}

export interface Coupon {
  code: string;
  discountType: string;
  discountValue: number;
  minPurchase?: number;
}

export interface ShippingAddress {
  fullName: string;
  phoneNumber: string;
  fullAddress: string;
  landmark: string;
  district: string;
  state: string;
  pinCode: string;
  deliveryNote?: string;
  mapLocationUrl?: string;
}

export interface Order {
  id: string;
  userId?: string;
  userEmail?: string;
  items: CartItem[];
  address: ShippingAddress;
  paymentMethod: 'COD' | 'UPI' | 'Google Pay' | 'PhonePe' | 'Paytm';
  orderDate: string;
  totalPrice: number;
  deliveryCharge: number;
  discountApplied: number;
  grandTotal: number;
  status: 'Pending' | 'Confirmed' | 'Shipped' | 'Delivered' | 'Cancelled';
  trackingNumber?: string;
  trackingUpdates?: { date: string; status: string; description: string }[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string; // in simulation
  savedAddress?: ShippingAddress;
  wishlist: string[]; // product IDs
  isAdmin?: boolean;
}

export interface Poster {
  id: string;
  image: string;
  title: string;
  subtitle: string;
  description: string;
  linkTab: string;
  buttonText: string;
  isCustom?: boolean;
  layout?: 'split' | 'full';
}

