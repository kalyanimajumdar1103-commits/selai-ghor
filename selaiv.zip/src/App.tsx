import React, { useState, useEffect } from 'react';
import { ArrowUp, MessageCircle, X, ShieldCheck, ShoppingBag, HelpCircle, Star, Heart, ShieldAlert } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Types & Data
import { Product, CartItem, Order, User, Coupon, ShippingAddress, Review, Poster } from './types';
import { INITIAL_PRODUCTS, INITIAL_REVIEWS, COUPONS, CATEGORIES } from './data';
import { sendOrderToSheet } from './utils/googleSheets';
import { getAccessToken } from './utils/firebase';

// Custom Components
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductDetails from './components/ProductDetails';
import Shop from './components/Shop';
import CustomOrder from './components/CustomOrder';
import Cart from './components/Cart';
import CustomerAccount from './components/CustomerAccount';
import AdminPanel from './components/AdminPanel';
import AboutContact from './components/AboutContact';
import Footer from './components/Footer';
import AiBot from './components/AiBot';

// Unified Reusable Product Card Component
interface ProductCardProps {
  key?: React.Key;
  product: Product;
  onSelectProduct: (product: Product) => void;
  onToggleWishlist: (productId: string) => void;
  isWishlisted: boolean;
  reviews: Review[];
}

function ProductCard({
  product,
  onSelectProduct,
  onToggleWishlist,
  isWishlisted,
  reviews
}: ProductCardProps) {
  const currentPrice = product.discountPrice || product.price;
  const hasDiscount = !!product.discountPrice;
  const savingPercentage = hasDiscount ? Math.round(((product.price - product.discountPrice!) / product.price) * 100) : 0;

  // Calculate dynamic average rating from reviews array
  const prodReviews = reviews.filter(r => r.productId === product.id);
  const avgRating = prodReviews.length > 0
    ? (prodReviews.reduce((sum, r) => sum + r.rating, 0) / prodReviews.length)
    : product.rating;

  return (
    <div
      onClick={() => onSelectProduct(product)}
      className="group relative flex flex-col justify-between overflow-hidden rounded-3xl border border-zinc-200/80 bg-white p-3.5 shadow-sm hover:shadow-md dark:border-zinc-800 dark:bg-zinc-900 transition-all cursor-pointer"
      id={`prod-card-${product.id}`}
    >
      <div className="relative aspect-square w-full overflow-hidden rounded-2xl bg-zinc-50 dark:bg-zinc-800 transform-gpu">
        <img
          src={product.images[0]}
          alt={product.name}
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300 transform-gpu will-change-transform"
        />

        {hasDiscount && (
          <span className="absolute top-3.5 left-3.5 rounded-full bg-red-500 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-wider text-white">
            {savingPercentage}% OFF
          </span>
        )}

        {product.availability === 'Pre-order' && (
          <span className="absolute top-3.5 left-3.5 rounded-full bg-zinc-950 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-wider text-white dark:bg-white dark:text-zinc-950">
            Pre-order
          </span>
        )}

        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product.id);
          }}
          className="absolute top-3.5 right-3.5 flex h-9 w-9 items-center justify-center rounded-full bg-white text-zinc-400 shadow-sm hover:text-brand-pink dark:bg-zinc-800 dark:text-zinc-500 transition-colors"
          title="Add to Wishlist"
          id={`wishlist-toggle-app-${product.id}`}
        >
          <Heart className={`h-4.5 w-4.5 ${isWishlisted ? 'fill-brand-pink text-brand-pink' : ''}`} />
        </button>
      </div>

      <div className="flex flex-col p-2 text-left mt-3.5 flex-1 justify-between">
        <div>
          <span className="text-[9px] font-bold uppercase tracking-widest text-brand-pink">
            {product.category}
          </span>
          
          <h3 className="font-sans text-sm font-bold text-zinc-950 dark:text-white mt-1 mb-1 group-hover:text-brand-pink transition-colors line-clamp-1">
            {product.name}
          </h3>

          <div className="flex items-center space-x-1.5 mb-2">
            <div className="flex text-amber-400">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`h-3 w-3 ${i < Math.round(avgRating) ? 'fill-current' : 'text-zinc-200 dark:text-zinc-700'}`}
                />
              ))}
            </div>
            <span className="text-[10px] font-bold text-zinc-500">
              ({avgRating.toFixed(1)})
            </span>
          </div>

          <p className="text-xs text-zinc-500 dark:text-zinc-400 line-clamp-2 mb-4 leading-relaxed">
            {product.shortDescription}
          </p>
        </div>

        <div className="flex items-center justify-between pt-3 border-t border-zinc-150 dark:border-zinc-800">
          <div>
            <span className="text-sm font-extrabold text-zinc-950 dark:text-white">
              ₹{currentPrice}
            </span>
            {hasDiscount && (
              <span className="text-xs text-zinc-400 line-through ml-2">
                ₹{product.price}
              </span>
            )}
          </div>
          
          <div className="flex h-7.5 px-3.5 items-center justify-center rounded-full bg-zinc-50 text-zinc-700 text-[10px] font-bold uppercase tracking-wider border border-zinc-200 group-hover:bg-zinc-950 group-hover:text-white group-hover:border-zinc-950 transition-all dark:bg-zinc-800 dark:text-zinc-300 dark:border-zinc-700 dark:group-hover:bg-white dark:group-hover:text-zinc-950 dark:group-hover:border-white">
            <span>Details</span>
          </div>
        </div>
      </div>
    </div>
  );
}

const DEFAULT_POSTERS: Poster[] = [
  {
    id: 'bun-ring-slide',
    image: 'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?q=80&w=600',
    title: 'Aparajita Hair Bun Ring',
    subtitle: 'Signature Crochet Collection',
    description: 'Elevate your hairstyle with our handmade white & blue crochet bun ring adorned with cascading Aparajita flower tassels and wooden stick.',
    linkTab: 'shop',
    buttonText: 'ORDER NOW'
  },
  {
    id: 'crochet-slide',
    image: 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=600',
    title: 'Beautiful Crochet Treasures for your Home',
    subtitle: 'Handmade with Love',
    description: 'Explore our collection of premium wool products, meticulously crafted to bring warmth and color to your life.',
    linkTab: 'shop',
    buttonText: 'Shop Now'
  },
  {
    id: 'sunflower-slide',
    image: 'https://images.unsplash.com/photo-1508780709619-795624c7ac40?q=80&w=600',
    title: 'Vibrant Sunflower Collection',
    subtitle: 'Bright & Cheerful Accessories',
    description: 'Bring warm sunshine vibes to your hair with our handmade crochet sunflower hair clips and bun accessories made from premium soft wool.',
    linkTab: 'shop',
    buttonText: 'SHOP SUNFLOWERS'
  }
];

export default function App() {
  // --- Persistent State Hooks ---
  const [posters, setPosters] = useState<Poster[]>(() => {
    const saved = localStorage.getItem('sg_posters_v2');
    return saved ? JSON.parse(saved) : DEFAULT_POSTERS;
  });

  const handleAddPoster = (newPoster: Poster) => {
    setPosters(prev => [...prev, newPoster]);
  };

  const handleDeletePoster = (posterId: string) => {
    setPosters(prev => prev.filter(p => p.id !== posterId));
  };

  // --- Brand & Payment Settings States ---
  const [logoUrl, setLogoUrl] = useState<string>(() => {
    return localStorage.getItem('sg_logo_url') || '';
  });

  const [qrCodeUrl, setQrCodeUrl] = useState<string>(() => {
    return localStorage.getItem('sg_qr_code_url') || '';
  });

  const handleUpdateLogo = (url: string) => {
    setLogoUrl(url);
    localStorage.setItem('sg_logo_url', url);
  };

  const handleUpdateQrCode = (url: string) => {
    setQrCodeUrl(url);
    localStorage.setItem('sg_qr_code_url', url);
  };

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('sg_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [categories, setCategories] = useState<string[]>(() => {
    const saved = localStorage.getItem('sg_categories');
    return saved ? JSON.parse(saved) : CATEGORIES;
  });

  const [categoryImages, setCategoryImages] = useState<{[key: string]: string}>(() => {
    const saved = localStorage.getItem('sg_category_images');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // ignore
      }
    }
    return {
      'Crochet Bags': 'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?q=80&w=150',
      'Crochet Flowers': 'https://images.unsplash.com/photo-1561181286-d3fee7d55364?q=80&w=150',
      'Hair Bands': 'https://images.unsplash.com/photo-1576243345690-4e4b79b63288?q=80&w=150',
      'Home Decoration': 'https://images.unsplash.com/photo-1513201099495-a636c5e5a59e?q=80&w=150',
      'Key Rings': 'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?q=80&w=150',
      'Hair Accessories': 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?q=80&w=150',
      'Bags & Pouches': 'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?q=80&w=150',
      'Mobile Covers': 'https://images.unsplash.com/photo-1607522370275-f14206abe5d3?q=80&w=150',
      'Dolls & Soft Toys': 'https://images.unsplash.com/photo-1559251606-c623743a6d76?q=80&w=150',
      'Devotional Collection': 'https://images.unsplash.com/photo-1609137144813-91b5c92878bf?q=80&w=150',
      'Home Decor': 'https://images.unsplash.com/photo-1513201099495-a636c5e5a59e?q=80&w=150',
      'Shuddh Swad': 'https://images.unsplash.com/photo-1603532648955-039310d9ed75?q=80&w=150'
    };
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('sg_orders');
    return saved ? JSON.parse(saved) : [];
  });

  const [coupons, setCoupons] = useState<Coupon[]>(() => {
    const saved = localStorage.getItem('sg_coupons');
    return saved ? JSON.parse(saved) : COUPONS;
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem('sg_reviews');
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  const [registeredUsers, setRegisteredUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('sg_users');
    return saved ? JSON.parse(saved) : [];
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('sg_current_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('sg_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('sg_wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  const [recentlyViewed, setRecentlyViewed] = useState<Product[]>(() => {
    const saved = localStorage.getItem('sg_recently_viewed');
    return saved ? JSON.parse(saved) : [];
  });

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('sg_theme');
    return saved === 'dark';
  });

  // --- UI Control State ---
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [accountSubTab, setAccountSubTab] = useState<'orders' | 'wishlist' | 'address' | 'tracking'>('orders');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [showScrollTop, setShowScrollTop] = useState<boolean>(false);
  const [policyModalId, setPolicyModalId] = useState<string | null>(null);

  // --- Sync State to LocalStorage ---
  useEffect(() => {
    localStorage.setItem('sg_products', JSON.stringify(products));
  }, [products]);

  // Fix cached duplicate images from older sessions automatically on mount
  useEffect(() => {
    const hasDuplicates = products.some((p, index) => {
      if (!p.id || !p.id.startsWith('prod-')) return false;
      return products.some((other, otherIdx) => {
        if (otherIdx === index || !other.id || !other.id.startsWith('prod-')) return false;
        return other.images[0] === p.images[0];
      });
    });

    if (hasDuplicates) {
      const fixed = products.map(p => {
        if (p.id && p.id.startsWith('prod-')) {
          const original = INITIAL_PRODUCTS.find(op => op.id === p.id);
          if (original) {
            return {
              ...p,
              images: original.images,
              colorImages: original.colorImages
            };
          }
        }
        return p;
      });
      setProducts(fixed);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('sg_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('sg_category_images', JSON.stringify(categoryImages));
  }, [categoryImages]);

  useEffect(() => {
    localStorage.setItem('sg_posters_v2', JSON.stringify(posters));
  }, [posters]);

  useEffect(() => {
    localStorage.setItem('sg_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('sg_coupons', JSON.stringify(coupons));
  }, [coupons]);

  useEffect(() => {
    localStorage.setItem('sg_reviews', JSON.stringify(reviews));
  }, [reviews]);

  useEffect(() => {
    localStorage.setItem('sg_users', JSON.stringify(registeredUsers));
  }, [registeredUsers]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('sg_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('sg_current_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('sg_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('sg_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('sg_recently_viewed', JSON.stringify(recentlyViewed));
  }, [recentlyViewed]);

  // Dark/Light Theme applying
  useEffect(() => {
    const root = window.document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      localStorage.setItem('sg_theme', 'dark');
    } else {
      root.classList.remove('dark');
      localStorage.setItem('sg_theme', 'light');
    }
  }, [isDarkMode]);

  // Handle Scroll to Top visual trigger
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // --- Business Logic functions ---

  // Select a product & append to recently viewed
  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
    setCurrentTab('product-details');
    
    // Add to recently viewed (prevent duplicates, limit to 5)
    setRecentlyViewed(prev => {
      const filtered = prev.filter(p => p.id !== product.id);
      return [product, ...filtered].slice(0, 5);
    });
  };

  // Toggle wishlist items
  const handleToggleWishlist = (productId: string) => {
    if (!currentUser) {
      alert('Please sign in to add items to your wishlist.');
      setCurrentTab('account');
      setAccountSubTab('orders');
      return;
    }
    setWishlist(prev =>
      prev.includes(productId) ? prev.filter(id => id !== productId) : [...prev, productId]
    );
  };

  // Add to cart operations
  const handleAddToCart = (product: Product, quantity: number, color: string) => {
    if (!currentUser) {
      alert('Please sign in to add items to your cart.');
      setCurrentTab('account');
      setAccountSubTab('orders');
      return;
    }
    setCart(prev => {
      const existingIdx = prev.findIndex(
        item => item.product.id === product.id && item.selectedColor === color
      );

      if (existingIdx > -1) {
        const nextCart = [...prev];
        nextCart[existingIdx].quantity += quantity;
        return nextCart;
      }

      return [...prev, { product, quantity, selectedColor: color }];
    });
  };

  // Direct buy (Go directly to checkout step in Cart)
  const handleDirectBuy = (product: Product, quantity: number, color: string) => {
    if (!currentUser) {
      alert('Please sign in to buy items.');
      setCurrentTab('account');
      setAccountSubTab('orders');
      return;
    }
    // Add to cart first
    handleAddToCart(product, quantity, color);
    // Switch to cart page
    setCurrentTab('cart');
    // Open the Cart view directly
    setIsCartOpen(false);
  };

  // Update Cart Quantities
  const handleUpdateCartQuantity = (productId: string, color: string, newQty: number) => {
    setCart(prev =>
      prev.map(item =>
        item.product.id === productId && item.selectedColor === color
          ? { ...item, quantity: newQty }
          : item
      )
    );
  };

  // Remove individual item
  const handleRemoveCartItem = (productId: string, color: string) => {
    setCart(prev =>
      prev.filter(item => !(item.product.id === productId && item.selectedColor === color))
    );
  };

  // Submit Order Details
  const handlePlaceOrder = async (completedOrder: Order) => {
    setOrders(prev => [completedOrder, ...prev]);

    // Attempt real-time auto-sync to Google Sheets via the backend server proxy
    try {
      console.log('Syncing order to connected Google Sheet in real-time via proxy...', completedOrder.id);
      const response = await fetch('/api/sheets/append', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ order: completedOrder }),
      });

      if (response.ok) {
        const data = await response.json().catch(() => ({}));
        if (data.success) {
          const savedSynced = localStorage.getItem('sg_synced_order_ids');
          const currentSynced: string[] = savedSynced ? JSON.parse(savedSynced) : [];
          if (!currentSynced.includes(completedOrder.id)) {
            currentSynced.push(completedOrder.id);
            localStorage.setItem('sg_synced_order_ids', JSON.stringify(currentSynced));
            // Trigger storage event or sync state in case Admin Panel is open in another view
            window.dispatchEvent(new Event('storage'));
          }
          console.log('Order auto-synced to Google Sheet successfully!');
        } else {
          console.warn('Real-time sync to Google Sheet via server proxy completed with warning:', data.message || data.error);
        }
      } else {
        console.warn('Real-time sync to Google Sheet via server proxy failed (Integration might not be configured by admin).');
      }
    } catch (err) {
      console.error('Error during real-time Google Sheets sync:', err);
    }
  };

  // User auth hooks
  const handleLogin = (user: User) => {
    setCurrentUser(user);
    
    // Auto-login session bypass for Admin is removed so that entering the Admin Panel
    // always requires entering the secure password, as requested by the user.
    
    // Sync to registeredUsers database if not there
    setRegisteredUsers(prev => {
      if (prev.some(u => u.id === user.id)) return prev;
      return [...prev, user];
    });
  };

  const handleLogout = () => {
    setCurrentUser(null);
    sessionStorage.removeItem('sg_admin_token');
  };

  const handleUpdateAddress = (address: ShippingAddress) => {
    if (currentUser) {
      const updated = { ...currentUser, savedAddress: address };
      setCurrentUser(updated);
      setRegisteredUsers(prev => prev.map(u => u.id === currentUser.id ? updated : u));
    }
  };

  // Admin adjustments
  const handleAddProduct = (newProd: Product) => {
    setProducts(prev => [newProd, ...prev]);
  };

  const handleEditProduct = (editedProd: Product) => {
    setProducts(prev => prev.map(p => p.id === editedProd.id ? editedProd : p));
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
  };

  const handleUpdateOrderStatus = (orderId: string, nextStatus: Order['status'], logDesc: string) => {
    setOrders(prev =>
      prev.map(ord => {
        if (ord.id === orderId) {
          const dateNow = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
          const updatedLogs = [...(ord.trackingUpdates || [])];
          updatedLogs.push({ date: dateNow, status: nextStatus, description: logDesc });
          return { ...ord, status: nextStatus, trackingUpdates: updatedLogs };
        }
        return ord;
      })
    );
  };

  const handleAddCoupon = (newCoupon: Coupon) => {
    setCoupons(prev => [...prev, newCoupon]);
  };

  const handleDeleteCoupon = (code: string) => {
    setCoupons(prev => prev.filter(c => c.code !== code));
  };

  const handleAddCategory = (cat: string) => {
    setCategories(prev => [...prev, cat]);
  };

  const handleDeleteCategory = (cat: string) => {
    setCategories(prev => prev.filter(c => c !== cat));
    setCategoryImages(prev => {
      const updated = { ...prev };
      delete updated[cat];
      return updated;
    });
  };

  const handleUpdateCategoryImage = (cat: string, img: string) => {
    setCategoryImages(prev => ({
      ...prev,
      [cat]: img
    }));
  };

  const handleAddReview = (newRev: Omit<Review, 'id' | 'date'>) => {
    const formattedReview: Review = {
      ...newRev,
      id: `rev-${Date.now()}`,
      date: new Date().toISOString().split('T')[0]
    };
    setReviews(prev => [formattedReview, ...prev]);
  };

  // --- Policy modal descriptors ---
  const POLICIES: { [key: string]: { title: string; text: string } } = {
    privacy: {
      title: 'Privacy Policy',
      text: `Your privacy is extremely critical to us. Selai Ghor only collects your Name, Phone, and shipping address details to process and fulfill your handmade orders securely via WhatsApp. We never share, rent, or trade your contact parameters with third-party analytical networks or advertisers. All transactions are logged securely inside your client-side session storage.`
    },
    return: {
      title: 'Return Policy',
      text: `Every single item on Selai Ghor is hand-knitted with organic combed cotton yarn and intense artisan effort. As every piece is personalized and unique, we DO NOT accept general returns or aesthetic changes. If you received a wrong product or if it was damaged during courier transit, please contact us on WhatsApp with an unboxing video within 24 hours of delivery for support.`
    },
    refund: {
      title: 'Refund Policy',
      text: `Refunds are eligible ONLY for products verified to be damaged during transport, or custom amigurumi caricature doll orders which could not be finalized. Once your damage unboxing video is verified on WhatsApp (+91 81002 26410), your refund will be processed directly into your UPI or GPay source account within 3 business days.`
    },
    shipping: {
      title: 'Shipping & Delivery Policy',
      text: `We ship all in-stock creations within 1-2 days. Standard shipping delivers in 3-5 business days across West Bengal and 5-7 business days throughout India. Custom-designed orders (such as custom portrait dolls) are crafted on-demand and can take 10-15 business days to build and deliver. Delivery is completely FREE for orders above ₹1000!`
    },
    terms: {
      title: 'Terms & Conditions',
      text: `By browsing Selai Ghor, you acknowledge that all products are 100% handmade; hence, minor variations in stitches, colors, and shape are natural and represent authentic handcrafted charm. Orders placed on this website are compiled and verified on WhatsApp before final dispatch. Any disputes shall be subject to the exclusive jurisdiction of the courts in Kolkata, West Bengal.`
    }
  };

  return (
    <div className={`min-h-screen bg-zinc-50 font-sans text-zinc-900 transition-colors duration-300 dark:bg-zinc-950 dark:text-zinc-50`}>
      
      {/* 1. Sticky Navigation Navbar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          setCurrentTab(tab);
          setSelectedProduct(null); // Reset detail page
        }}
        setAccountSubTab={setAccountSubTab}
        cart={cart}
        setIsCartOpen={(open) => {
          if (open && !currentUser) {
            alert('Please sign in to view your shopping cart.');
            setCurrentTab('account');
            setAccountSubTab('orders');
          } else {
            setIsCartOpen(open);
          }
        }}
        wishlistCount={wishlist.length}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        currentUser={currentUser}
        onSearch={setSearchQuery}
        searchQuery={searchQuery}
        onLogout={handleLogout}
        logoUrl={logoUrl}
      />

      {/* 2. Primary Layout Render */}
      <main className="pb-16 min-h-[70vh]">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentTab + (selectedProduct?.id || '')}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.25 }}
          >
            {currentTab === 'home' && (
              <Hero
                products={products}
                setCurrentTab={setCurrentTab}
                onSelectProduct={handleSelectProduct}
                onAddToCart={handleAddToCart}
                onToggleWishlist={handleToggleWishlist}
                wishlist={wishlist}
                posters={posters}
                categories={categories}
                categoryImages={categoryImages}
                onFilterCategory={(catName) => {
                  setSearchQuery(catName);
                  setCurrentTab('shop');
                }}
              />
            )}

            {currentTab === 'shop' && (
              <Shop
                products={products}
                onSelectProduct={handleSelectProduct}
                onToggleWishlist={handleToggleWishlist}
                wishlist={wishlist}
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                recentlyViewed={recentlyViewed}
              />
            )}

            {currentTab === 'categories' && (
              <div className="mx-auto max-w-7xl px-4 py-12 text-left">
                <span className="text-xs font-bold uppercase tracking-widest text-brand-pink">Explore Collections</span>
                <h1 className="font-display text-3xl font-extrabold text-zinc-900 dark:text-white mt-1">Product Categories</h1>
                
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3 mt-8">
                  {categories.map((cat, idx) => {
                    // Find a sample product in this category to use as visual
                    const sample = products.find(p => p.category === cat) || products[0];
                    return (
                      <div
                        key={idx}
                        onClick={() => {
                          setSearchQuery(cat);
                          setCurrentTab('shop');
                        }}
                        className="group relative h-48 overflow-hidden rounded-3xl border shadow-sm cursor-pointer dark:border-zinc-800"
                      >
                        <img
                          src={sample?.images[0] || 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=400'}
                          alt={cat}
                          referrerPolicy="no-referrer"
                          className="absolute inset-0 h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                        
                        <div className="absolute bottom-4 left-4 text-left">
                          <h3 className="font-display text-base font-bold text-white uppercase tracking-wider">{cat}</h3>
                          <span className="block text-[10px] text-pink-200 mt-1 uppercase font-semibold">
                            View {products.filter(p => p.category === cat).length} items &gt;
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {currentTab === 'new-arrivals' && (
              <div className="mx-auto max-w-7xl px-4 py-12 text-left" id="new-arrivals-tab-view">
                <span className="text-xs font-bold uppercase tracking-widest text-brand-pink">Freshly Stitched</span>
                <h1 className="font-display text-3xl font-extrabold text-zinc-900 dark:text-white mt-1">New Arrivals</h1>
                <p className="text-xs text-zinc-500 mt-2 max-w-xl">Browse our newest wool designs freshly completed from the loom. Expertly hand-stitched with love and care.</p>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mt-8">
                  {products.slice(0, 8).map((prod) => (
                    <ProductCard
                      key={prod.id}
                      product={prod}
                      onSelectProduct={handleSelectProduct}
                      onToggleWishlist={handleToggleWishlist}
                      isWishlisted={wishlist.includes(prod.id)}
                      reviews={reviews}
                    />
                  ))}
                </div>
              </div>
            )}

            {currentTab === 'best-sellers' && (
              <div className="mx-auto max-w-7xl px-4 py-12 text-left" id="best-sellers-tab-view">
                <span className="text-xs font-bold uppercase tracking-widest text-brand-purple">Artisan Classics</span>
                <h1 className="font-display text-3xl font-extrabold text-zinc-900 dark:text-white mt-1">Best Sellers</h1>
                <p className="text-xs text-zinc-500 mt-2 max-w-xl">Our most ordered and highly loved handcrafted creations. Loved and recommended by customers.</p>
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mt-8">
                  {products.slice(2, 10).map((prod) => (
                    <ProductCard
                      key={prod.id}
                      product={prod}
                      onSelectProduct={handleSelectProduct}
                      onToggleWishlist={handleToggleWishlist}
                      isWishlisted={wishlist.includes(prod.id)}
                      reviews={reviews}
                    />
                  ))}
                </div>
              </div>
            )}

            {currentTab === 'custom-order' && (
              <CustomOrder 
                currentUser={currentUser} 
                setCurrentTab={(tab) => {
                  setCurrentTab(tab);
                  setSelectedProduct(null);
                }} 
              />
            )}

            {currentTab === 'about-us' && <AboutContact />}
            {currentTab === 'contact' && <AboutContact />}

            {currentTab === 'product-details' && selectedProduct && (
              <ProductDetails
                product={selectedProduct}
                onBack={() => {
                  setCurrentTab('shop');
                  setSelectedProduct(null);
                }}
                onAddToCart={handleAddToCart}
                onToggleWishlist={handleToggleWishlist}
                isWishlisted={wishlist.includes(selectedProduct.id)}
                reviews={reviews}
                onAddReview={handleAddReview}
                relatedProducts={products.filter(p => p.category === selectedProduct.category && p.id !== selectedProduct.id)}
                onSelectProduct={handleSelectProduct}
                onDirectBuy={handleDirectBuy}
                orders={orders}
                currentUser={currentUser}
                setCurrentTab={setCurrentTab}
              />
            )}

            {currentTab === 'cart' && (
              <Cart
                cart={cart}
                onUpdateQuantity={handleUpdateCartQuantity}
                onRemoveItem={handleRemoveCartItem}
                onClearCart={() => setCart([])}
                setCurrentTab={setCurrentTab}
                onPlaceOrder={handlePlaceOrder}
                savedAddress={currentUser?.savedAddress}
                currentUser={currentUser}
                onLogin={handleLogin}
                coupons={coupons}
                qrCodeUrl={qrCodeUrl}
              />
            )}

            {currentTab === 'account' && (
              <CustomerAccount
                products={products}
                currentUser={currentUser}
                onLogin={handleLogin}
                onLogout={handleLogout}
                onUpdateAddress={handleUpdateAddress}
                orders={orders}
                onSelectProduct={handleSelectProduct}
                wishlist={wishlist}
                onToggleWishlist={handleToggleWishlist}
                subTab={accountSubTab}
                setSubTab={setAccountSubTab}
                setCurrentTab={setCurrentTab}
                onRegister={(newUser) => {
                  setRegisteredUsers(prev => {
                    if (prev.some(u => u.id === newUser.id || u.email.toLowerCase() === newUser.email.toLowerCase())) return prev;
                    return [...prev, newUser];
                  });
                }}
              />
            )}

            {currentTab === 'admin' && (
              <AdminPanel
                products={products}
                onAddProduct={handleAddProduct}
                onEditProduct={handleEditProduct}
                onDeleteProduct={handleDeleteProduct}
                orders={orders}
                onUpdateOrderStatus={handleUpdateOrderStatus}
                users={registeredUsers}
                coupons={coupons}
                onAddCoupon={handleAddCoupon}
                onDeleteCoupon={handleDeleteCoupon}
                categories={categories}
                categoryImages={categoryImages}
                onUpdateCategoryImage={handleUpdateCategoryImage}
                onAddCategory={handleAddCategory}
                onDeleteCategory={handleDeleteCategory}
                onClose={() => setCurrentTab('home')}
                posters={posters}
                onAddPoster={handleAddPoster}
                onDeletePoster={handleDeletePoster}
                logoUrl={logoUrl}
                onUpdateLogo={handleUpdateLogo}
                qrCodeUrl={qrCodeUrl}
                onUpdateQrCode={handleUpdateQrCode}
              />
            )}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* 3. Footer Segment */}
      <Footer
        setCurrentTab={(tab) => {
          setCurrentTab(tab);
          setSelectedProduct(null);
        }}
        openPolicyModal={setPolicyModalId}
      />

      {/* 4. Sliding Quick Cart Drawer Overlay */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 z-50 bg-black"
            />
            
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', duration: 0.25 }}
              className="fixed inset-y-0 right-0 z-50 w-full max-w-md bg-white p-6 shadow-xl dark:bg-zinc-900 text-left flex flex-col justify-between"
              id="sidebar-cart-drawer"
            >
              <div>
                <div className="flex items-center justify-between border-b pb-4 border-zinc-100 dark:border-zinc-800">
                  <h3 className="font-display text-base font-bold text-zinc-900 dark:text-white flex items-center space-x-2">
                    <ShoppingBag className="h-5 w-5 text-brand-pink" />
                    <span>My Cart ({cart.reduce((sum, item) => sum + item.quantity, 0)} items)</span>
                  </h3>
                  <button
                    onClick={() => setIsCartOpen(false)}
                    className="p-1 text-zinc-400 hover:text-brand-pink"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>

                {/* Items container */}
                {cart.length === 0 ? (
                  <div className="text-center py-20 space-y-4">
                    <ShoppingBag className="h-10 w-10 text-zinc-300 mx-auto" />
                    <p className="text-xs text-zinc-400 italic">Your cart is currently empty.</p>
                  </div>
                ) : (
                  <div className="space-y-4 overflow-y-auto max-h-[55vh] mt-4 pr-1">
                    {cart.map((item, idx) => (
                      <div key={idx} className="flex items-center justify-between border-b pb-3 border-zinc-50 dark:border-zinc-800">
                        <div className="flex space-x-3 items-center min-w-0">
                          <img src={item.product.images[0]} alt="" referrerPolicy="no-referrer" className="h-12 w-12 rounded-lg object-cover" />
                          <div className="text-left">
                            <h4 className="font-display text-xs font-bold text-zinc-800 truncate max-w-[150px] dark:text-white">{item.product.name}</h4>
                            <span className="block text-[10px] text-zinc-400 mt-0.5">Color: {item.selectedColor} • Qty: {item.quantity}</span>
                          </div>
                        </div>
                        <div className="text-right flex items-center space-x-3">
                          <span className="text-xs font-bold text-zinc-900 dark:text-white">
                            ₹{(item.product.discountPrice || item.product.price) * item.quantity}
                          </span>
                          <button
                            onClick={() => handleRemoveCartItem(item.product.id, item.selectedColor)}
                            className="text-red-400 hover:text-red-600 p-1"
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Drawer footer controls */}
              {cart.length > 0 && (
                <div className="border-t pt-4 border-zinc-100 dark:border-zinc-800">
                  <div className="flex justify-between text-sm font-bold text-zinc-800 dark:text-white mb-4">
                    <span>Subtotal Price:</span>
                    <span className="text-brand-pink font-extrabold">
                      ₹{cart.reduce((sum, item) => sum + ((item.product.discountPrice || item.product.price) * item.quantity), 0)}
                    </span>
                  </div>
                  
                  <button
                    onClick={() => {
                      setIsCartOpen(false);
                      setCurrentTab('cart');
                    }}
                    className="w-full h-11 rounded-full bg-brand-pink text-xs font-bold text-white hover:bg-brand-pink-dark transition-colors flex items-center justify-center space-x-2"
                  >
                    <span>Proceed to Checkout</span>
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* 5. FLOATING AI BOT */}
      <AiBot
        onNavigate={(tab) => {
          setCurrentTab(tab);
          setSelectedProduct(null);
        }}
        currentUser={currentUser}
        products={products}
        cart={cart}
        orders={orders}
      />

      {/* 6. SCROLL TO TOP BUTTON */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-22 right-6 z-40 flex h-11 w-11 items-center justify-center rounded-full bg-zinc-800 text-white shadow-lg hover:bg-zinc-900 transition-colors"
            title="Scroll to Top"
            id="scroll-to-top-btn"
          >
            <ArrowUp className="h-5 w-5" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* 7. POLICY MODAL DIALOG */}
      <AnimatePresence>
        {policyModalId && POLICIES[policyModalId] && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setPolicyModalId(null)}
              className="fixed inset-0 z-50 bg-black"
            />
            
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="fixed inset-x-4 top-1/4 md:top-1/3 mx-auto z-50 max-w-md rounded-3xl border border-pink-100 bg-white p-6 shadow-2xl dark:border-zinc-800 dark:bg-zinc-900 text-left"
              id="policy-modal"
            >
              <div className="flex items-center justify-between border-b pb-3 mb-4 border-zinc-100 dark:border-zinc-800">
                <h3 className="font-display text-sm font-bold text-zinc-900 dark:text-white flex items-center space-x-2">
                  <ShieldCheck className="h-5 w-5 text-brand-pink" />
                  <span>{POLICIES[policyModalId].title}</span>
                </h3>
                <button
                  onClick={() => setPolicyModalId(null)}
                  className="rounded-full p-1 text-zinc-400 hover:text-brand-pink"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <p className="text-xs text-zinc-600 dark:text-zinc-300 leading-relaxed">
                {POLICIES[policyModalId].text}
              </p>

              <button
                onClick={() => setPolicyModalId(null)}
                className="w-full h-10 rounded-full bg-zinc-800 text-xs font-bold text-white hover:bg-zinc-950 transition-colors mt-6"
              >
                Acknowledge & Close
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

    </div>
  );
}
