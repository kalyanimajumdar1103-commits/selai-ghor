import { Product, Review, Coupon } from './types';

export const CATEGORIES = [
  'Shuddh Swad',
  'Hair Accessories',
  'Bags & Pouches',
  'Mobile Covers',
  'Dolls & Soft Toys',
  'Crochet Flowers',
  'Devotional Collection',
  'Home Decor'
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'prod-thekua-jaggery',
    name: 'Shuddh Swad TheKua (Coconut Jaggery Magic)',
    price: 350,
    discountPrice: 249,
    category: 'Shuddh Swad',
    images: [
      'https://images.unsplash.com/photo-1603532648955-039310d9ed75?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1621303837174-89787a7d4729?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Authentic crispy-fried Thekua biscuits sweetened with premium organic jaggery and rich grated coconut.',
    description: 'Experience the pristine traditional taste of Bihar and Eastern India with Shuddh Swad Thekua. Crafted completely by hand using pure wheat flour, nutrient-rich organic jaggery (gur), high-grade desiccated coconut, crunchy fennel seeds, and freshly crushed green cardamom. Fried in hygienic, small batches to deliver that signature melt-in-mouth crunchy texture. 100% vegetarian, eggless, with no artificial preservatives, colors, or flavors.',
    materialsUsed: 'Pure Wheat Flour, Organic Jaggery, Desiccated Coconut, Fennel Seeds, Cardamom, Refined Oil/Ghee',
    size: 'Pack of 12 pieces (approx. 350g)',
    weight: '350g',
    estimatedDelivery: '2 - 4 business days',
    colorOptions: ['Traditional Style'],
    rating: 5.0
  },
  {
    id: 'prod-thekua-suji',
    name: 'Shuddh Swad TheKua (Coconut Suji Magic)',
    price: 350,
    discountPrice: 249,
    category: 'Shuddh Swad',
    images: [
      'https://images.unsplash.com/photo-1548365328-8c6db3220e4c?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1603532648955-039310d9ed75?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Crispy semolina (suji) sweet biscuits made with pure sugar, rich coconut grates, and ghee.',
    description: 'Indulge in our delicate Suji (Semolina) variant of the classic Thekua. Made with high-quality fine semolina, premium sugar, pure dairy ghee, and generous amounts of freshly grated coconut. The addition of suji gives it a unique, extra-crumbly crispness that perfectly complements your evening tea. Hand-molded using authentic wooden blocks (sancha) and packaged in fresh food-grade stand-up pouches to lock in original crispness.',
    materialsUsed: 'Fine Semolina (Suji), Wheat Flour, Pure Sugar, Grated Coconut, Premium Ghee, Cardamom',
    size: 'Pack of 12 pieces (approx. 350g)',
    weight: '350g',
    estimatedDelivery: '2 - 4 business days',
    colorOptions: ['Premium Suji Style'],
    rating: 4.9
  },
  {
    id: 'prod-1',
    name: 'Aesthetic Pastel Daisy Tote Bag',
    price: 1250,
    discountPrice: 999,
    category: 'Bags & Pouches',
    images: [
      'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1544816155-12df9643f363?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1590156221122-c7b390df12e0?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Charming hand-knitted tote bag adorned with pastel yellow and white daisies. Spelled with love.',
    description: 'Carry your essentials in style with this intricately hand-crocheted daisy tote bag. Modeled with high-quality premium milk cotton yarn, it features comfortable shoulder straps, a sturdy knit pattern to prevent stretching, and a charming floral aesthetic that goes with any cottagecore or modern outfit.',
    materialsUsed: '80% Milk Cotton Yarn, 20% Acrylic Blend',
    size: '12" x 14" (Straps: 10")',
    weight: '250g',
    estimatedDelivery: '3 - 5 business days',
    colorOptions: ['Lavender Purple', 'Sakura Pink', 'Mint Green', 'Soft Cream'],
    colorImages: {
      'Lavender Purple': [
        'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?q=80&w=600&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?q=80&w=600&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?q=80&w=600&auto=format&fit=crop'
      ],
      'Sakura Pink': [
        'https://images.unsplash.com/photo-1516617442634-75371039cb3a?q=80&w=600&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=600&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1490750967868-88aa4486c946?q=80&w=600&auto=format&fit=crop'
      ],
      'Mint Green': [
        'https://images.unsplash.com/photo-1543157148-f68f214f33db?q=80&w=600&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1502082553048-f009c37129b9?q=80&w=600&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1535262412227-85541e910204?q=80&w=600&auto=format&fit=crop'
      ],
      'Soft Cream': [
        'https://images.unsplash.com/photo-1544816155-12df9643f363?q=80&w=600&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1590156221122-c7b390df12e0?q=80&w=600&auto=format&fit=crop',
        'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?q=80&w=600&auto=format&fit=crop'
      ]
    },
    rating: 4.8
  },
  {
    id: 'prod-2',
    name: 'Elegant Rose Crochet Flower Bouquet',
    price: 850,
    discountPrice: 699,
    category: 'Crochet Flowers',
    images: [
      'https://images.unsplash.com/photo-1561181286-d3fee7d55364?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1525310072745-f49212b5ac6d?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1490750967868-88aa4486c946?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1444492412393-a3e041593306?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Everlasting hand-knitted roses bouquet in premium wrapping. The perfect romantic gift.',
    description: 'Flowers that never fade! Each rose petal is individually hand-stitched by skilled artisans using premium non-pilling cotton yarn. Comes elegantly wrapped in florist-grade paper with a pastel ribbon. Ideal for anniversaries, birthdays, or decorating your vanity.',
    materialsUsed: '100% Organic Milk Cotton Yarn, Steel Stem Wire',
    size: '15" Height, 8" Diameter',
    weight: '180g',
    estimatedDelivery: '4 - 6 business days',
    colorOptions: ['Crimson Red', 'Blush Pink', 'Lilac', 'Sunset Yellow'],
    rating: 4.9
  },
  {
    id: 'prod-3',
    name: 'Boho Tulip Hair Band / Headband',
    price: 350,
    discountPrice: 249,
    category: 'Hair Accessories',
    images: [
      'https://images.unsplash.com/photo-1565808229224-264b6fcc5052?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1590156221122-c7b390df12e0?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Delightful vintage headwrap featuring delicate mini crocheted tulips and leaf design.',
    description: 'Add a vintage, natural touch to your hair. This band features hand-woven green leaves with popping red and pink tulips on an adjustable band that ties behind the neck. Light, soft, and extremely comfortable without causing headaches.',
    materialsUsed: 'Super Soft Combed Cotton Yarn',
    size: 'One Size (Adjustable ties)',
    weight: '45g',
    estimatedDelivery: '2 - 4 business days',
    colorOptions: ['Sage Green Tulips', 'Pink Tulip Blossom', 'Cream & Honey'],
    rating: 4.7
  },
  {
    id: 'prod-4',
    name: 'Strawberry Fields Crochet Key Ring',
    price: 199,
    category: 'Home Decor',
    images: [
      'https://images.unsplash.com/photo-1591084728795-1149f32d9866?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1601004890684-d8cbf643f5cf?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Extremely adorable chunky strawberry key charm with green leaf accents.',
    description: 'This cute strawberry charm is filled with soft hypoallergenic polyfill. Perfect to attach to your keys, backpacks, or hand bags for an instant pop of color and handmade cuteness. Sturdy metal ring included.',
    materialsUsed: 'Cotton Thread, Premium Polyfill, Stainless Keyring',
    size: '2.5" x 2"',
    weight: '20g',
    estimatedDelivery: '3 - 5 business days',
    colorOptions: ['Classic Red', 'Sweet Pink', 'Golden Yellow'],
    rating: 5.0
  },
  {
    id: 'prod-5',
    name: 'Handmade Crochet Sunflower Hair Clip',
    price: 250,
    discountPrice: 99,
    category: 'Hair Accessories',
    images: [
      'https://images.unsplash.com/photo-1597848212624-a19eb35e2651?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1470058869855-412f56c393be?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Handmade crochet sunflower hair clip in Yellow & Brown colors made from soft wool yarn.',
    description: 'Dress up your hair with these beautiful sunflower clips. Each clip features a dark brown center surrounded by vibrant hand-knit yellow petals. Sturdily mounted on high-grip slip-resistant metal snap clips lined with soft wool yarn.',
    materialsUsed: 'Soft Wool Yarn, Metal Snap Clips',
    size: '3" Diameter',
    weight: '15g',
    estimatedDelivery: '2 - 4 business days',
    colorOptions: ['Yellow & Brown'],
    rating: 4.9
  },
  {
    id: 'prod-6',
    name: 'Aesthetic Sunflower Coasters (Set of 4)',
    price: 599,
    discountPrice: 450,
    category: 'Home Decor',
    images: [
      'https://images.unsplash.com/photo-1617050318658-a9a3175e34cd?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1502082553048-f009c37129b9?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Sprightly sunflower mug rugs to bring warmth and protection to your dining table.',
    description: 'Bring the sunshine indoors! This set of 4 sunflower coasters is hand-made with water-absorbent thick cotton yarn. Protects your wood and glass surfaces from hot mugs, cups, and condensation. They look absolutely gorgeous as decorative desk accessories too.',
    materialsUsed: '100% Coarse Absorbent Cotton Yarn',
    size: '5" Diameter',
    weight: '110g (Set)',
    estimatedDelivery: '3 - 5 business days',
    colorOptions: ['Sunshine Yellow', 'Vintage Ochre', 'Terracotta Orange'],
    rating: 4.9
  },
  {
    id: 'prod-7',
    name: 'Handmade Crochet Strawberry Mobile Cover',
    price: 399,
    discountPrice: 299,
    category: 'Mobile Covers',
    images: [
      'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1563206767-5b18f218e8de?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Super protective, colorful hand-crocheted milk cotton sleeve with 3D strawberry button closure.',
    description: 'A stylish and cozy protection sleeve for your smartphone. Hand-made using soft, dense cotton stitches to provide shock absorption. Comes with a cute crocheted 3D strawberry charm that acts as a secure loop button closure. Fits all standard iPhone and Android sizes.',
    materialsUsed: '100% Premium Milk Cotton Yarn',
    size: '6.7" x 3.5"',
    weight: '40g',
    estimatedDelivery: '3 - 5 business days',
    colorOptions: ['Pastel Pink', 'Creamy White', 'Lilac Violet'],
    rating: 4.8
  },
  {
    id: 'prod-8',
    name: 'Custom Crochet Portrait Doll (Amigurumi)',
    price: 2499,
    category: 'Dolls & Soft Toys',
    images: [
      'https://images.unsplash.com/photo-1559251606-c623743a6d76?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1580748141549-71748d60bd96?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1608248597481-496100c80836?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1579783900882-c0d3dad7b119?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'Pre-order',
    shortDescription: 'Send us a photo and we will hand-craft a custom mini crochet amigurumi doll of you or your loved ones.',
    description: 'An exceptionally unique and thoughtful gift! Send us a photo of yourself, a friend, or a pet, and our expert crochet artists will craft a custom amigurumi figure mimicking the clothing, hair, and style. Please allow 10-12 days for crafting.',
    materialsUsed: '100% Fine Combed Cotton, Safety Eyes, Soft Fiberfill',
    size: '8" Height',
    weight: '150g',
    estimatedDelivery: '10 - 15 business days',
    colorOptions: ['Custom (Based on Photo)'],
    rating: 5.0
  },
  {
    id: 'prod-9',
    name: 'Handcrafted Lavender Dreamcatcher',
    price: 950,
    discountPrice: 799,
    category: 'Home Decor',
    images: [
      'https://images.unsplash.com/photo-1506126613408-eca07ce68773?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1518241353330-0f7941c2d9b5?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Intricate crocheted dreamcatcher with soft feathers, wool tassels, and lavender hues.',
    description: 'Adorn your bedroom with peaceful vibes. This stunning dreamcatcher features a hand-crocheted intricate mandalic center web in lavender and cream colors, dangling wool tassels, and beautiful beads. Designed to bring good dreams and beautiful aesthetics to your wall.',
    materialsUsed: 'Wooden Hoop, Milk Cotton, Feathers, Beads',
    size: '10" Hoop, 24" Total Length',
    weight: '120g',
    estimatedDelivery: '4 - 6 business days',
    colorOptions: ['Lavender & Cream', 'Rose Pink & Soft White'],
    rating: 4.9
  },
  {
    id: 'prod-10',
    name: 'Aparajita Crochet Flower Brooch / Hair Clip',
    price: 199,
    discountPrice: 149,
    category: 'Hair Accessories',
    images: [
      'https://images.unsplash.com/photo-1526047932273-341f2a7631f9?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1562184552-997c461abbe6?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Delicate handmade blue Aparajita flower brooch with realistic details and dual clip backing.',
    description: 'A charming hand-crocheted Aparajita (Clitoria ternatea / Blue Pea) flower brooch. Expertly made using premium fine-gauge cotton threads, it features realistic concentric double petals in rich violet-blue, a soft white-green heart, and durable leaf-base backing. Features a dual safety pin and spring clip for multi-way styling as a saree pin or hair clip.',
    materialsUsed: '100% Combed Cotton Thread, Dual Pin-Clip backer',
    size: '2.5" x 2.2"',
    weight: '12g',
    estimatedDelivery: '3 - 5 business days',
    colorOptions: ['Aparajita Blue', 'Pure White'],
    rating: 5.0
  },
  {
    id: 'prod-11',
    name: 'Aparajita Hair Bun Ring with Wooden Pin',
    price: 550,
    discountPrice: 420,
    category: 'Hair Accessories',
    images: [
      'https://images.unsplash.com/photo-1513519245088-0e12902e5a38?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1595079676339-1534801ad6cf?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Stunning white and blue crochet bun ring adorned with cascading Aparajita flower tassels and a wooden stick.',
    description: 'The signature piece from Salai Ghor! This beautiful hair accessory features a robust, hand-knitted circular bun ring in white and deep blue, complete with a polished wooden hair stick. Two delicate green stems cascade down with hand-stitched dangling Aparajita flower buds, giving a modern, elegant, ethnic touch to your bun hairstyle.',
    materialsUsed: 'Soft Milk Cotton Yarn, Natural Polished Wood Stick',
    size: 'Ring: 3.5" Diameter, Stick: 6.5" Length',
    weight: '35g',
    estimatedDelivery: '3 - 5 business days',
    colorOptions: ['Midnight Blue & White', 'Crimson & Cream'],
    rating: 4.9
  },
  {
    id: 'prod-12',
    name: 'Vibrant Sunflower Crochet Hair Clip',
    price: 250,
    discountPrice: 180,
    category: 'Hair Accessories',
    images: [
      'https://images.unsplash.com/photo-1470058869855-412f56c393be?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1508780709619-795624c7ac40?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Cheerful, brightly colored crochet sunflower hair clip with detailed brown seed-center and vibrant yellow petals.',
    description: 'Bring warm sunshine vibes to your hairdo! This cheerful sunflower clip features a deep brown stitched center textured with seed-patterns, bordered by ten bright yellow pointy petals. Sturdily mounted on a high-grip, slip-resistant metal snap hair clip lined with soft yarn, ensuring comfortable all-day wear.',
    materialsUsed: '100% Milk Cotton Yarn, Steel Slip-Resistant Snap Clip',
    size: '3.2" Diameter',
    weight: '15g',
    estimatedDelivery: '2 - 4 business days',
    colorOptions: ['Sunshine Yellow', 'Ochre Gold'],
    rating: 5.0
  },
  {
    id: 'prod-13',
    name: 'Handmade Crochet Krishna Doll',
    price: 499,
    category: 'Dolls & Soft Toys',
    images: [
      'https://images.unsplash.com/photo-1584551246679-0daf3d275d0f?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1513201099495-a636c5e5a59e?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Handmade Crochet Krishna Doll in premium wool yarn. Highly detailed Bal Gopal amigurumi doll with crown and flute.',
    description: 'A gorgeous amigurumi representation of young Lord Krishna. Carefully hand-knitted stitch-by-stitch using premium, itch-free non-pilling wool yarn. The doll features safety eyes, a beautiful miniature peacock feather crown, a golden-threaded sash, and a tiny handcrafted wooden flute. Handmade with absolute love and perfect for home temples, kids play, or holy gifts.',
    materialsUsed: 'Premium Wool Yarn, Safety Eyes, Soft Polyfill',
    size: '7.5" Height',
    weight: '120g',
    estimatedDelivery: '3 - 5 business days',
    colorOptions: ['Sky Blue & Yellow'],
    rating: 5.0
  },
  {
    id: 'prod-14',
    name: 'Sri Jagannath Crochet Hanging Ornament',
    price: 350,
    discountPrice: 249,
    category: 'Devotional Collection',
    images: [
      'https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=600&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1566842633055-8c88b7f3b2f6?q=80&w=600&auto=format&fit=crop'
    ],
    availability: 'In Stock',
    shortDescription: 'Beautiful circular crochet Jagannath wall hanging/car hanging ornament with iconic big eyes and smile.',
    description: 'Invite divine, protective vibes with this beautiful handmade Sri Jagannath hanging ornament. Expertly crocheted in a solid black disk with iconic hand-stitched big white-red eyes, yellow tilak/nose, and an expressive red stitched smile. Finished with a white necklace border and a durable top loop for hanging in your car, room, or as a key ring.',
    materialsUsed: 'Super Soft Cotton Thread, Sturdy Hanging Loop',
    size: '3.5" Diameter (Total Length: 7" with loop)',
    weight: '25g',
    estimatedDelivery: '3 - 5 business days',
    colorOptions: ['Classic Black Face'],
    rating: 5.0
  }
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    productId: 'prod-1',
    customerName: 'Ananya Sharma',
    rating: 5,
    comment: 'Absolutely in love with this tote! The daisy patterns are so pretty and the stitching is super firm. It does not stretch down even when I put my heavy iPad and books. Highly recommend Salai Ghor!',
    date: '2026-06-20'
  },
  {
    id: 'rev-2',
    productId: 'prod-1',
    customerName: 'Meghna Roy',
    rating: 4,
    comment: 'Very cute bag, perfect for summer outings. The color is exactly like the picture. Took about 4 days to deliver in Kolkata.',
    date: '2026-07-02'
  },
  {
    id: 'rev-3',
    productId: 'prod-2',
    customerName: 'Rohan Gupta',
    rating: 5,
    comment: 'I gifted this crochet bouquet to my girlfriend for our anniversary, and she was so happy! She loved that these flowers will stay with her forever. The wrapping is so premium and neat.',
    date: '2026-07-10'
  }
];

export const COUPONS: Coupon[] = [
  { code: 'WELCOME10', discountType: 'percentage', discountValue: 10 },
  { code: 'SALE20', discountType: 'percentage', discountValue: 20 },
  { code: 'FESTIVAL50', discountType: 'fixed', discountValue: 50, minPurchase: 500 }
];

export const FAQ_ITEMS = [
  {
    question: 'How do I care for and wash crochet products?',
    answer: 'We recommend gentle hand-washing in cold water with mild liquid detergent. Do not wring or twist. Lay flat on a clean dry towel in the shade to dry. Do not hang crochet items when wet as they can lose their shape.'
  },
  {
    question: 'How do I place a custom order?',
    answer: 'Simply select "Custom Order" from our navigation, fill in the custom requirements, or select "Custom Crochet Portrait Doll" from the shop. You can also directly contact us on WhatsApp (+91 81002 26410) with your pictures or design ideas!'
  },
  {
    question: 'What is the estimated delivery time?',
    answer: 'For in-stock products, we ship within 1-2 days and they deliver in 3-5 business days. Custom handmade orders can take 10-15 business days to craft and deliver.'
  },
  {
    question: 'Do you offer cash on delivery (COD)?',
    answer: 'Yes, we provide Cash on Delivery (COD) alongside secure online payments like UPI, Google Pay, PhonePe, and Paytm.'
  },
  {
    question: 'What is your return/refund policy?',
    answer: 'Since every item is hand-made with a lot of effort, we do not accept returns unless the item is damaged during transit. In case of damage, please contact us on WhatsApp with an unboxing video within 24 hours of delivery for a replacement or full refund.'
  }
];
