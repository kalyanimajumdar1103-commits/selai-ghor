import { Order } from '../types';

/**
 * Creates a new Google Spreadsheet for Selai Ghor orders and returns its ID
 */
export async function createOrdersSpreadsheet(accessToken: string): Promise<string> {
  const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: 'Selai Ghor Orders & Customer Leads',
      },
      sheets: [
        {
          properties: {
            title: 'Orders',
            gridProperties: {
              frozenRowCount: 1,
            },
          },
        },
      ],
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const message = errorData.error?.message || `HTTP ${response.status}: Failed to create spreadsheet`;
    console.error('Google Sheets create spreadsheet failed:', errorData);
    throw new Error(message);
  }

  const data = await response.json();
  const spreadsheetId = data.spreadsheetId;

  // Sync spreadsheetId and token with server
  try {
    await fetch('/api/sheets/config', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ spreadsheetId, accessToken }),
    });
  } catch (err) {
    console.warn('Failed to sync spreadsheet config to backend:', err);
  }

  // Initialize with headers
  await initializeHeaders(spreadsheetId, accessToken);

  return spreadsheetId;
}

/**
 * Initializes the header row of the spreadsheet
 */
export async function initializeHeaders(spreadsheetId: string, accessToken: string): Promise<void> {
  const headers = [
    'Order ID',
    'Date & Time',
    'Customer Name',
    'Phone Number',
    'Email',
    'Full Address',
    'Landmark',
    'District & State',
    'PIN Code',
    'Products Ordered',
    'Subtotal (₹)',
    'Delivery Charge (₹)',
    'Discount Applied (₹)',
    'Grand Total (₹)',
    'Payment Method',
    'Status',
    'Tracking Number'
  ];

  const range = 'Orders!A1:Q1';
  const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}?valueInputOption=USER_ENTERED`, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      range,
      majorDimension: 'ROWS',
      values: [headers],
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    const message = errorData.error?.message || `HTTP ${response.status}: Failed to initialize headers`;
    console.error('Google Sheets initialize headers failed:', errorData);
    throw new Error(message);
  }
}

/**
 * Appends an order as a new row to the specified Google Spreadsheet
 */
export async function sendOrderToSheet(order: Order, spreadsheetId: string, accessToken: string): Promise<boolean> {
  // Sync the latest credentials and spreadsheet ID to the server config
  try {
    await fetch('/api/sheets/config', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ spreadsheetId, accessToken }),
    });
  } catch (err) {
    console.warn('Failed to sync spreadsheet config to backend:', err);
  }

  // Execute append via the backend proxy to ensure consistency and store-wide availability
  const response = await fetch('/api/sheets/append', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ order }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    console.warn('Google Sheets backend proxy append failed with HTTP status:', response.status, errorData);
    throw new Error(`Google Sheets proxy request failed with HTTP ${response.status}`);
  }

  const data = await response.json().catch(() => ({}));
  if (data.success === false) {
    if (data.error === 'auth_expired') {
      throw new Error('Google authorization has expired. Please disconnect and authorize Google Sheets again in the Admin Panel.');
    } else if (data.error === 'not_configured') {
      throw new Error('Spreadsheet integration is not configured. Please link a Google Spreadsheet in the Admin Panel.');
    } else {
      throw new Error(data.message || `Google Sheets error: ${data.error}`);
    }
  }

  return true;
}
