import { initializeApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

const provider = new GoogleAuthProvider();
// Add required Google Workspace scopes for Sheets and Drive
provider.addScope('https://www.googleapis.com/auth/spreadsheets');
provider.addScope('https://www.googleapis.com/auth/drive.file');
provider.addScope('https://www.googleapis.com/auth/drive');

// Flag to indicate if we are in the middle of a sign-in flow
let isSigningIn = false;
// Cache the access token in memory
let cachedAccessToken: string | null = localStorage.getItem('sg_google_access_token');

export const isTokenValid = (): boolean => {
  if (!cachedAccessToken) return false;
  const expiry = localStorage.getItem('sg_google_token_expiry');
  if (!expiry) return false;
  return Date.now() < Number(expiry);
};

// Initialize auth state listener
export const initAuth = (
  onAuthSuccess?: (user: FirebaseUser, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user) => {
    if (user) {
      if (isTokenValid()) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken!);
      } else {
        cachedAccessToken = null;
        localStorage.removeItem('sg_google_access_token');
        localStorage.removeItem('sg_google_token_expiry');
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      localStorage.removeItem('sg_google_access_token');
      localStorage.removeItem('sg_google_token_expiry');
      if (onAuthFailure) onAuthFailure();
    }
  });
};

// Must be called from a button click or user interaction
export const googleSignIn = async (): Promise<{ user: FirebaseUser; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get access token from Google Auth');
    }

    cachedAccessToken = credential.accessToken;
    // We can cache it in localStorage for convenience between reloads (though in-memory is preferred,
    // storing it temporarily here helps survive Vite hot-reloads during preview and dev)
    localStorage.setItem('sg_google_access_token', cachedAccessToken);
    
    // Set expiry to 1 hour from now (3600 seconds)
    const expiryTime = Date.now() + 3600 * 1000;
    localStorage.setItem('sg_google_token_expiry', expiryTime.toString());
    
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Sign-In error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = (): string | null => {
  if (!isTokenValid()) {
    return null;
  }
  return cachedAccessToken;
};

export const googleSignOut = async () => {
  await auth.signOut();
  cachedAccessToken = null;
  localStorage.removeItem('sg_google_access_token');
  localStorage.removeItem('sg_google_token_expiry');
};
